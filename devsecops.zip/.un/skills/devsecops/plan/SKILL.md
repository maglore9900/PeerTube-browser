---
name: plan
description: Explores an idea with the operator until its requirements and a high-level plan are agreed, then writes them as a feature file under docs/project/plans/ in the plan_template shape for a build to start from.
---

<objective>
An idea has arrived and is not yet a build. This skill explores it with the operator — the purpose behind it, what it must do, the routes to it — until the requirements are confirmed and a high-level plan is approved, then writes both into a feature file at `docs/project/plans/<NN>-<slug>.md`. The output is decisions and a plan; the build that follows is `/workflows:dev-flow` or `/devsecops:build`.
</objective>

<quick_start>
1. Orient on what already exists — `<orient>`.
2. Explore the idea with the operator — `<explore>`.
3. Lay out the routes and let the operator draw the scope — `<routes>`.
4. Confirm the requirements, then approve the high-level plan — `<agree>`.
5. Write the feature file and hand it off — `<write_the_plan>`.

An idea too big for one session resumes from its notes file — `<across_sessions>`.
</quick_start>

<orient>
- Restate the idea in one or two sentences, so the operator can correct the reading before anything is built on it.
- Search `docs/project/plans/` and `docs/project/plans/archive/` for the subject. Where a plan already covers it, work from that plan and revise it in place, so the subject keeps one record.
- Read `CONTEXT.md` for the domain terms and the ADRs in `docs/project/adr/` touching the area. Where the idea contradicts an ADR, say so to the operator.
</orient>

<explore>
Ask the operator one question at a time and wait for the answer. The operator speaks for themselves; every answer on their side comes from them. `AskUser` suits a question with clear options; a plain question in the turn suits an open one. When the operator asks for an explanation, answer in prose.

Go breadth-first: cover the whole idea before going deep on any thread. Aim at:
- the purpose — if the ask is X and the goal is Y, capture Y;
- what it must do, and how the operator would tell it is done;
- the constraints it must match — existing code style, args, CLI shape, config.

Raise the fidelity of the discussion where it helps:
- **Verify every premise about current code** against the source — read the module, run it, probe it — and name what was checked and what could not be. A claim reasoned from memory, a comment or an old plan is a prediction.
- **Research** a fact outside the tree (third-party APIs, documentation) with a Task subagent, its prompt carrying the question and every piece of context it needs, since it cannot see this conversation.
- **Prototype** when "how should it look" or "how should it behave" is the question: a cheap, rough artifact under `.scratch/<slug>/` for the operator to react to. A prototype that needs a build has become the build.

Sharpen domain terms as you go, updating `CONTEXT.md` and adding an ADR as a decision lands, and report each by path.
</explore>

<routes>
List every route to the goal you found, each with its evidence, cost and risk, and recommend one. The operator sets the scope: what is built now, what later, what not at all. Record their line under Requirements as they drew it.
</routes>

<agree>
**Requirements.** Draft them in the shape `templates/plan_template.md` gives under `## Requirements`: what was asked for, the underlying purpose, acceptance criteria, scope as the operator drew it, consistency constraints, and conflicts — any requirement contradicting another or the tree, naming both sides and how the operator resolved it. Put the draft to the operator and revise until they confirm it. Backwards compatibility is a requirement only when the operator asks for it.

**High-level plan.** Against the confirmed requirements, draft in prose, no code:
- the approach, and how it satisfies each requirement in turn;
- the alternatives considered and why the chosen one won — an approach with no rejected alternative was assumed, not chosen;
- gotchas, risks, and current and future limitations;
- the tradeoffs the operator is being asked to accept.

Where the plan cannot satisfy a requirement, put that conflict to the operator rather than bending either side. Revise until they approve it.
</agree>

<write_the_plan>
Read `.un/skills/devsecops/templates/plan_template.md`, then write `docs/project/plans/<NN>-<slug>.md`, `<NN>` the next number unused in `docs/project/plans/` and `docs/project/plans/archive/`:

- `# <change name>` — a short title for the build.
- `## Requirements` — the confirmed requirements, with `###` subheadings. Test trees and baseline suite state are the build's to fill at its Step 0.
- `## High-level plan` — the approved plan, with `###` subheadings for approach, alternatives, risks and tradeoffs.

State each requirement once, in full; a build starts from this file and has only what it says. The sections from `## Impacts` down belong to the build.

Hand it off in the REPL form: `/workflows:dev-flow docs/project/plans/<NN>-<slug>.md`, or `/devsecops:build` for the manual flow.
</write_the_plan>

<across_sessions>
When the exploration will not finish in one session, keep `.scratch/<slug>/notes.md` with two sections: **Decisions so far** (one line per settled decision, with its reason) and **Open questions**. A later session reads it first and continues from the open questions. Once the feature file is written, the notes stay in `.scratch/` as the record of how the decisions were reached.
</across_sessions>

<success_criteria>
- The operator confirmed the requirements and approved the high-level plan.
- `docs/project/plans/<NN>-<slug>.md` exists with Requirements and High-level plan filled, or an existing plan on the subject was revised in place.
- Every premise about current code was checked against the source, and the plan says what was checked.
- Any `CONTEXT.md` or ADR change was reported by path.
- The operator was given the hand-off command.
- No source file or test was edited.
</success_criteria>
