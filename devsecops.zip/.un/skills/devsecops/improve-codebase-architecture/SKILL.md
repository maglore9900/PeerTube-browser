---
name: improve-codebase-architecture
description: Scans a codebase for deepening opportunities, presents them as a markdown report, then works through whichever one the operator picks, a round of questions at a time. Proposes builds; it does not perform them.
---

<objective>
Surface architectural friction and propose **deepening opportunities**: refactors that turn shallow modules into deep ones. The aim is testability and AI-navigability.

This skill proposes. Deciding an interface is where it stops — the build itself is `/devsecops:build`, and a deepening too big for one session goes to `/devsecops:plan` to be explored into a feature file.
</objective>

<quick_start>
Run `/devsecops:improve-architecture [direction]`. With a direction (a module, a subsystem, a pain point), scan there. Without one, let the commit history pick the scope. Then: explore, write the report, ask which candidate to open, and work that one candidate in a question loop.
</quick_start>

<vocabulary>
The seven terms this skill reasons in, and the three principles that use them. Shared reference: `rules/testing.md <seams>` points here when the shape of an interface is the question. Use these words exactly in every suggestion, and don't drift into "component", "service", "API" or "boundary" — each of those names a thing without saying how much it hides, which is the only property this skill is about.

- **module** — a unit with an inside and an outside: some implementation, plus the interface through which everything else reaches it. The unit of this skill's attention, whatever the language calls it (file, class, package).
- **interface** — everything a caller must know to use a module: its signatures, yes, and also its ordering requirements, its error modes, and what a caller has to remember not to do. Bigger than the signature list, which is why a module can have a small API and a large interface.
- **depth** — the ratio between what a module hides and what its interface costs to learn. A **DEEP** module hides a lot behind a little. A **SHALLOW** one's interface is nearly as complex as its implementation, so it earns nothing: the caller pays the learning cost twice. Deepening is this skill's whole output.
- **seam** — the public boundary you observe behavior at without reaching inside. Defined in full in `rules/testing.md <seams>`, which is its authority; it appears here because a proposed interface IS a proposed seam.
- **adapter** — a module whose job is translating between this codebase and something outside it, or between two subsystems that must not know each other's shapes.
- **leverage** — how much a change to one module buys across the codebase. High leverage is what makes a deepening worth doing: the same edit makes many future changes easier. Low leverage is a tidy-up.
- **locality** — related behavior living close enough together that a bug is visible where it is caused. Splitting a module into pure functions for testability trades locality away, and the real defect moves into how they are called, where no test is looking.

**The three principles:**

- **The deletion test.** Would deleting this module concentrate complexity, or just move it? "Concentrates" means it was earning its place. "Moves it" means it was shallow.
- **The interface is the test surface.** A module's interface and the seam its tests are written at are the same line. An interface that is hard to test is the finding, not the test's problem.
- **One adapter is a hypothetical seam; two are a real one.** A boundary with a single implementation behind it is a guess about the future. Wait for the second before treating it as a seam worth designing.

The project's own domain language is separate and lives in `CONTEXT.md` — it names the NOUNS a good seam is drawn around, where this block names the PROPERTIES a seam is judged by. ADRs in `docs/project/adr/` record decisions this skill should not re-litigate.
</vocabulary>

<explore>
**Scope before you scan: YAGNI.** Deepening a module pays off by making future changes to it easier, so put extra weight on the parts of the codebase that have recently changed. Decide *where* to look before you look:

- If the user named a direction (a module, a subsystem, a pain point), take it, and skip the inference below.
- Otherwise, walk back a good stretch of the commit history (`git_ro log --oneline`) to find the codebase's hot spots, the files and areas that keep coming up, and let those paths pull your attention first. If the changes are scattered with no clear hot spot, widen the net.

Read the project's domain glossary (`CONTEXT.md`) and any ADRs in the area you're touching first.

Then spawn a sub-agent to walk the codebase. Don't follow rigid heuristics; explore organically and note where you experience friction:

- Where does understanding one concept require bouncing between many small modules?
- Where are modules **shallow**, with an interface nearly as complex as the implementation?
- Where have pure functions been extracted just for testability, but the real bugs hide in how they're called (no **locality**)?
- Where do tightly-coupled modules leak across their seams?
- Which parts of the codebase are untested, or hard to test through their current interface?

Apply the **deletion test** to anything you suspect is shallow: would deleting it concentrate complexity, or just move it? A "yes, concentrates" is the signal you want.
</explore>

<report>
Write the candidates to `.scratch/architecture-review-<timestamp>.md`, using the shape in `.un/skills/devsecops/templates/improve-codebase-architecture/architecture_report.md`. Read that template before writing. It carries one `##` section per candidate — files, problem, deletion test, solution, benefits, before/after diagram, recommendation strength — and closes with a top recommendation.

`.scratch/` keeps the report out of tracked work while leaving it readable in place and in `git status`. Create the directory if it is not there. Tell the user the path when the file is written.

Diagrams are mermaid fenced blocks, and only where a graph genuinely communicates the structure — call graphs, dependencies, sequences. Where it does not, cut the diagram and describe the shape in prose. An empty or decorative diagram is worse than none.

**Use CONTEXT.md vocabulary for the domain, and the architecture vocabulary in `<vocabulary>`.** If `CONTEXT.md` defines "Order," talk about "the Order intake module," not "the FooBarHandler," and not "the Order service."

**ADR conflicts**: if a candidate contradicts an existing ADR, only surface it when the friction is real enough to warrant revisiting the ADR. Name the ADR in the candidate's section and say why it is worth reopening. Don't list every theoretical refactor an ADR forbids.

**Done when** the file exists at the path you reported, every candidate carries a strength badge, and the top recommendation names one. Do NOT propose interfaces yet. Then ask the user: "Which of these would you like to explore?"
</report>

<question_loop>
Once the user picks a candidate, work it into shape by ASKING THEM, one round of questions at a time. Ask about constraints, dependencies, the shape of the deepened module, what sits behind the seam, and which tests survive the change. Put one question at a time and wait for the answer; a round of five guesses presented as a summary is not this step.

Side effects happen inline as decisions crystallize. Keep the domain model current as you go, and tell the user the path and the change each time one lands:

- **Naming a deepened module after a concept not in `CONTEXT.md`?** Add the term to `CONTEXT.md`. Create the file lazily if it doesn't exist.
- **Sharpening a fuzzy term during the conversation?** Update `CONTEXT.md` right there.
- **User rejects the candidate for a reason a future reviewer would need?** Offer an ADR, framed as: _"Want me to record this as an ADR so future architecture reviews don't re-suggest it?"_ Only offer when the reason would actually stop someone re-suggesting the same thing; skip ephemeral reasons ("not worth it right now") and self-evident ones.
- **Want to explore alternative interfaces for the deepened module?** Design it twice: draft two interfaces that differ in what they hide, put both to the user, and let the comparison decide rather than the first draft.
</question_loop>

<success_criteria>
The run is done when the module's interface is decided and the user agrees it is the one to build. That decision is the handoff, not the build.

- Report exists at the reported `.scratch/` path, in the template's shape.
- One candidate was worked to a decided interface through a question round the user answered.
- Every `CONTEXT.md` edit and every ADR written was reported to the user by path.
- Where the deepening turned out to be larger than one session can decide, it was handed to `/devsecops:plan` instead.

Nothing here writes production code, edits a source file, or authors a test.
</success_criteria>
