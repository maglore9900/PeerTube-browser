#!/usr/bin/env -S pixi run python
"""Run a project's tests in parallel lanes, and record the result.

Wraps pytest so a later session can read the record instead of re-running a suite
already known green, and so the test groups that DO have to run finish sooner.

Every stale test group runs in its own pytest subprocess, at most MAX_LANES at a
time, longest-known-duration first. Each lane parses its own junit report and
returns in memory; only the PARENT writes the record, which is what keeps
concurrent lanes from contending over it.

stdout carries a summary — one row per test group that ran, then a total. The
whole captured output goes to last_test_output.txt beside the record, every run,
with no flag to ask for it. Read or grep that file for detail.

A bare run whose recorded result is green and still describes the tree prints
that result and exits 0 without invoking pytest.

Every run that invokes pytest banks what it learned, with no flag to opt in.
Banking is per test group and only for the ones that produced results, which is
what makes it safe to do unconditionally: a test group nothing ran for keeps the
entry it already had, so a filtered or path-targeted run records exactly what it
exercised and leaves the rest of the record untouched.

ONLY A GREEN TEST GROUP BANKS A FINGERPRINT, and it banks one whatever arguments
reached it — full, partial, `-k`-filtered, it makes no difference. A red one banks
`None`, so it has nothing to match and runs again on the digest comparison alone.
That is why `stale_reason` asks no question about a banked exit code: the digest
means exactly one thing, that this test group was green against this code.

A run that selected WITHIN a test group — `-k`, `--deselect`, or a `::` node id —
reported on only part of it, so that test group is merged over what was carried
rather than replaced. Naming a path is not that: it selects whole test groups.

Config resolution fails CLOSED. `DEVSECOPS_CONFIG` is a caller asserting that
THIS project is described THERE, so a variable naming a file that is absent, or
one that cannot be read as a JSON object, exits non-zero naming that file. It
banks nothing on that exit: the guard runs while the config is resolved, which is
before pytest is reached. An UNNAMED absence is not an assertion and still falls
back to the defaults below — as does an empty `DEVSECOPS_CONFIG`, which names
nothing.

Usage:
    ./validate_tests.py                        # every tier, configured test path
    ./validate_tests.py --tier fast            # -m "not integration"
    ./validate_tests.py --tier integration     # -m integration
    ./validate_tests.py tests/browser -k env   # extra args pass through
    ./validate_tests.py --timeout 120          # kill the BATCH after 2 minutes
    ./validate_tests.py --show-config          # print the resolved config and exit

Naming no tier runs every test. A tier is a SUBSET a caller asks for, so running
everything is the default rather than a third choice — there is no `--tier all`,
and it is refused as an unrecognised choice so a workflow still naming it is told
rather than quietly given something else.

Keeping the group map honest:
    ./validate_tests.py --suggest-map          # proposed test_groups, to stdout
    ./validate_tests.py --audit-map            # check the map against the tests

`test_groups` is hand-authored, and an entry that under-lists what its test file
exercises costs a SILENT SKIP: the group digests to less than it depends on, so
it is deselected while the code it drives changes underneath it and the record
still reports green. `map_health` cannot see that — it compares the map to the
filesystem, never to what the tests reference.

`--suggest-map` derives, per group, the project files its test file NAMES, and
prints them as a `test_groups` fragment. It never writes the config: an entry
asserts that a test exercises a file, which is a human judgement.

`--audit-map` compares each entry against that derivation and reports four
classes. Only UNCLAIMED — an entry that is `[]` while its test file names project
files — affects the exit code. MISSING, UNRESOLVABLE and BARREN are advisory,
because the map names what a test TESTS and never what it shells to build a
fixture, and nothing in an AST distinguishes those two. See `audit_map`.

Triaging a large failure set:
    ./validate_tests.py --failures-by-cause    # one line per distinct cause, with counts
    ./validate_tests.py --compare              # only what moved against the last record

Neither takes a number, because both are computed over the merged RECORD rather
than over the captured lines: one collapses the whole suite's failures to their
distinct causes, the other reports only what moved. That is also why they describe
test groups this run never re-executed.

Any argument other than the flags above is forwarded to pytest untouched, in any
position. Exits with pytest's exit code — or, across lanes, with the most severe
one: a usage or internal error outranks a test failure, since it says the lane did
not describe its tests at all.

NO OUTPUT FLAG TAKES A SIZE. `--tail`, `--head`, `--failures` and `--json` are
gone, with the `--grep` family. Each asked the caller to guess how much would be
enough, and a guess that fell short cost the run it was trying to save. They are
refused BY NAME rather than forwarded to pytest, and the message says where to
look instead — see `RETIRED`.

NOTHING IS ECHOED WHILE THE RUN IS IN FLIGHT, and nothing raw reaches stdout at
all. Interleaved lines from concurrent lanes are unreadable, so every line is
captured, held, and written to `last_test_output.txt` when the batch finishes. The
one exception is a BARREN run — no per-test results, so nothing to summarise —
which prints its capture whole, because answering a crashed run with a file path
would be worse than the output it replaced.

What is captured is stripped of ANSI, so every consumer reads plain text: the
output file is grepped by hand, and the record is read by machines.

A run with failures names every failing test after the summary. That listing
answers "which tests failed", which is the wrong question after a mechanical
sweep: 242 failures collapsing to four causes produce 242 lines of it.
`--failures-by-cause` answers the question actually being asked — how many
distinct reasons are there, and is any of them a surprise — and replaces the
listing rather than joining it. `--compare` likewise prints only what moved
against the last record, which is the comparison a baseline check wants and the
one a hand count gets wrong, since transcribed numbers describe only the test
groups that happened to run.

The record sits at the root of the configured test tree — `tests/` when `active`
is `tests/active` — and never inside it, since a record written under the tree it
digests would invalidate its own entry on every run. See `record_path()`.

It carries two kinds of field. One describes THIS INVOCATION — the timestamp,
the resolved pytest argv, the target, whether it timed out, the duration, that
run's own counts and an output tail — and a skip carries every one of them
forward, having run no pytest to describe. The other describes the SUITE, and
every one of those is computed over the group entries: the exit code, the summary
counts, the per-test outcomes, and the entries themselves. Nothing in the second
kind is taken from `args` or from the process exit code, so the header cannot
contradict the body it sits on — which it did while `exit_code` was stamped from
the invocation, most visibly after a build's working-tree checkpoint run, whose
results are dropped at attribution and whose red exit code therefore described
nothing in the record at all.

NO TIER IS RECORDED, anywhere. A tier is a SELECTION the caller makes, not a
property of a result: every test file and every file it depends on is
fingerprinted, so a digest that still matches means the test group was validated
against exactly this code, and that is the whole question `stale_reason` asks. A
workflow that needs a particular tier names it in the workflow.

Each entry also carries `duration_s`, summed from junit's per-test `time` for that
test group's OWN cases rather than read off the suite element, which also charges
collection. It orders lanes and nothing else: longest first, so the slowest test
groups start in the first wave instead of the last. A test group with no banked
duration sorts last, which costs one run to learn.

Each group carries its own PER-GROUP digest. A group's digest is
its own test file and the files `test_groups` assigns it — and nothing else. No
test-tree helper is fingerprinted; see `claimed()`. There is no whole-tree term,
so editing a file no group claims invalidates nothing and the map is the whole
story about what a group costs. A group with no map entry always runs, because
its digest would otherwise cover its own file alone while the code it exercises
moved underneath it. `--show-config` reports those under
`map_health.unmapped_groups`, and an entry that is present but empty under
`map_health.declares_no_dependencies` — a claim rather than a fault, and one
`--audit-map` is what judges.

A later session compares each digest against the tree: where it matches, that
group's passing record still holds and it is carried forward rather than re-run.
The digest covers each file's path and executable bit as well as its content, so
a deleted or renamed test invalidates it — which an mtime cannot see, because
removing a file moves no surviving file's mtime.

This tool ships with the devsecops skill and is not tied to one project.
Per-project settings live in `../config.json` beside the skill (see
DEFAULT_CONFIG for the shape and defaults). The runner is discovered, not
hardcoded: a project with a pixi manifest is driven through `pixi run`,
anything else through the interpreter running this script.

`--show-config` is also how the WORKFLOWS resolve where things go. Four of the
config's keys — `project_dir`, `plans`, `delete_me`, `archive` — are read by
them and never by this script, and are reported alongside three derived fields:
`record`, the path this run banks to, `output`, where the whole captured output
lands, and `defaulted`, the keys the project has not set. `defaulted` is what the skill's bootstrap gate reads: while a key is
listed there, its value is this file's guess about a project it has never seen.

Paths resolve from the current working directory, so run from the project root.
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from pathlib import Path, PurePosixPath
from typing import NamedTuple

# The config travels with the skill, so it is anchored to this file rather than
# to the working directory. DEVSECOPS_CONFIG overrides that: one file beside a
# portable skill cannot describe two projects at once, and a throwaway project
# has no other way to be handed its own group map — which would leave the map
# with no reachable external endpoint to test it through.
SKILL_CONFIG = Path(__file__).resolve().parents[1] / "config.json"

CONFIG = Path(os.environ.get("DEVSECOPS_CONFIG") or SKILL_CONFIG)

DEFAULT_CONFIG = {
    # The DURABLE suite: tests that have earned a permanent place, filed by the
    # subject they exercise. Used when no path is given on the command line, and
    # the only tree the group/digest model below describes. Set during the
    # dev-flow bootstrap; see the skill's SKILL.md.
    #
    # `tests/active` rather than `tests`, so that the default pairs with the
    # `working` default as SIBLINGS. A bare `tests` would contain `tests/tmp`,
    # and `groups()` rglobs `active` — see `conflicts()` for what that costs.
    "active": "tests/active",
    # The WORKING tree a build writes into while it runs — checkpoints and inner
    # unit tests. Deliberately outside `active`, and
    # deliberately unmapped: a scratch test that is about to be merged or deleted
    # should not cost anyone a map entry, and an unmapped group always runs.
    # A separate workflow harvests what has lasting value into `active` when the
    # build closes, so a build never files phase-named leftovers in the suite.
    "working": "tests/tmp",
    # Per-group dependency map: group name -> the project files that group
    # exercises. Groups themselves are discovered from the filesystem, so this
    # only ever says what a group DEPENDS ON, never what a group IS. This is the
    # WHOLE story about what a group's digest covers. An empty map is a valid
    # state, not a broken one: every group is then unmapped and always runs.
    "test_groups": {},
    # The four keys below are read by the WORKFLOWS, never by this script. They
    # live here anyway because `--show-config` is the one place a workflow can
    # ask the project where something goes, and a directory a workflow invents
    # for itself is a directory the next workflow invents somewhere else.
    #
    # The project root. This script resolves paths from the working directory
    # and never reads this key; `workflows/harvest.md` substitutes it for
    # `<PROJECT_DIR>` in the commands it prints, so a harvest does not depend on
    # where the shell happens to be. `.` is a default that works and an answer
    # the bootstrap should replace with an absolute path.
    "project_dir": ".",
    # Where the WORKING_FILE a dev-flow build writes, and the HARVEST_FILE a
    # harvest writes, are filed.
    "plans": "docs/plans",
    # The disposal directory. `rm` is not assumed to be available — a workflow
    # that is done with a file MOVES it here and tells the user, so removal
    # stays the user's decision and stays visible in `git status`.
    "delete_me": "delete_me",
    # Where a harvest retires a durable test that a harvested one replaces.
    # Distinct from `delete_me` on purpose: a retired test gated something real
    # and stays readable, where nothing in `working` was ever durable.
    "archive": "tests/archive",
    # Where the bootstrap INSTALLS the auditor agents and the slash commands the
    # skill vendors under `agents/` and `commands/`. Claude Code discovers
    # neither from inside a skill directory, so a skill that only carried them
    # would ship five auditors nothing can invoke; the bootstrap copies them out
    # to where discovery actually looks.
    #
    # Configurable because there are two real answers, not because there are
    # many: the project (the default) or `~/.claude/...` for someone who wants
    # one copy across every project they run the flow in.
    "agents": ".claude/agents",
    "commands": ".claude/commands",
}

# Junit results matching no group's module prefix — a test file outside
# `active`, most often a dev-flow checkpoint run out of the WORKING tree. A
# pseudo-group with no file of its own, so it claims nothing, digests to None and
# always runs: a failure of attribution degrades to always-run rather than to a
# silent skip. `merge_groups` drops it as soon as a selection run sweeps `active`
# without reproducing it.
UNATTRIBUTED = "_unattributed"

# Conventional pixi manifest locations, checked in order. `pixienv/` is not
# standard pixi layout but is what some projects use.
PIXI_MANIFESTS = ("pixi.toml", "pixienv/pixi.toml")

# Directories no map entry could legitimately name, pruned when indexing the
# project for reference resolution. Everything else is a candidate INCLUDING
# dot-directories — `.claude/` is where this project keeps every file its tests
# exercise, so the `startswith(".")` rule `walk()` applies would empty the index.
#
# Git-tracking was measured as the filter instead and rejected: `.owork_dir/` and
# `tests/runs/` hold 1,306 TRACKED files here, so tracking separates a source
# file from a run artifact not at all.
INDEX_PRUNE = frozenset({
    ".git", "__pycache__", ".pytest_cache", "node_modules", ".venv", ".pixi",
    ".mypy_cache",
})

# `--audit-map`'s finding classes. Exactly one of them carries an exit code, and
# which one is the whole design:
#
#   UNCLAIMED     the entry is `[]` while the test file NAMES project files.
#                 `[]` asserts "nothing outside my own test file", and that is
#                 false however the tests-vs-fixture question is settled — so
#                 this is the one class that can be judged without deciding
#                 which reference is the subject. FAILS.
#   MISSING       the entry omits a resolved reference. ADVISORY, because the map
#                 names what a test TESTS and never what it shells to build a
#                 fixture, and nothing in an AST distinguishes those. Thirteen
#                 groups in this project name `write_task.py` only to build one.
#   UNRESOLVABLE  a basename several project files share. ADVISORY, and reported
#                 rather than dropped so a blind spot in the rule is visible
#                 instead of passing as coverage.
#   BARREN        the test file names nothing file-like at all. ADVISORY — `[]`
#                 is TRUE for such a group.
UNCLAIMED, MISSING, UNRESOLVABLE, BARREN = (
    "UNCLAIMED", "MISSING", "UNRESOLVABLE", "BARREN",
)

# A project's pytest config may already set `-m` via addopts. A command-line -m
# is applied after addopts and wins, so every tier passes one explicitly rather
# than relying on what the default happens to be.
TIERS = {
    "fast": ["-m", "not integration"],
    "integration": ["-m", "integration"],
}

# What a run selects when the caller names no tier: everything. A tier is a
# SUBSET a caller asks for, so running every test is the default rather than a
# third choice — `--tier all` named the default's only value, which is a choice
# that does not exist, and it is refused as unrecognised so a caller or an unswept
# workflow file is told rather than quietly given something else.
#
# Spelled as a marker expression rather than omitted, for the reason above: a
# project's pytest config may already set `-m` through addopts, and only a
# command-line `-m` — applied afterwards — is guaranteed to win.
EVERY_TIER = ["-m", "integration or not integration"]

SUMMARY_RE = re.compile(r"(\d+) (passed|failed|skipped|deselected|errors?|xfailed|xpassed)")

# A hung suite should fail rather than block a session indefinitely. The value
# bounds the whole BATCH rather than any one lane, so a run of thirty test groups
# over five lanes is held to the same wall clock as a run of one.
DEFAULT_TIMEOUT_S = 900.0

# How many test groups run at once. Each lane spawns subprocesses of its own, so this
# would thrash a two-core box; ten is measured on a twelve-core one. Edit it here:
# there is deliberately no flag and no config key, because a knob costs a `defaulted`
# entry and a bootstrap question in every project that installs this skill, to answer
# a question nobody has needed to answer twice.
#
# The wall clock is `max(slowest group, total / MAX_LANES)`, so this is the binding
# term until the second one is. Raised from five once the split plans it was set for
# had landed and left the suite lane-bound: 52 groups, 587s serial, slowest group
# 40.3s, so `587/5 = 117s` bound a suite whose group ceiling was a third of that.
# Splitting a group further cannot help while that holds — it leaves `total` alone
# and adds a pytest start. Group size becomes binding again above roughly sixteen.
MAX_LANES = 10

# The outcomes that mean a test did not pass. Named because three separate
# reporters ask the same question and a fourth spelling of the tuple is how they
# drift apart.
RED = ("failed", "error")

# pytest decorates its output whenever markup is enabled — a tty, or FORCE_COLOR
# / PY_COLORS in the environment. Every consumer of the captured lines expects
# plain text: the two rules above are ANCHORED, so a decorated `=== FAILURES ===`
# matches neither and `--failures` reports nothing on a run full of them; `grep`
# matches patterns a caller wrote against undecorated output; and the record and
# the --json artifact are read by machines. So capture is stripped, and only the
# live echo stays raw — the one surface a human reads.
# rat-tail: CSI only. An OSC hyperlink (\x1b]8;;...) would survive it and pytest
# emits none; widen the pattern if a plugin starts emitting them.
ANSI_RE = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")

# A failing test carried forward from a record banked before causes were
# captured has nothing to bucket under. Named rather than left blank so it reads
# as a gap in the record instead of as a cause of its own.
NO_MESSAGE = "(no cause recorded)"

# argparse lists flags alphabetically with no sense of which belong together, so
# the triage set is spelled out here as well. A flag nobody knows about is a flag
# nobody uses, and these exist to be reached for at the moment a sweep has just
# produced hundreds of failures.
TRIAGE_HELP = """\
output:
  stdout carries a summary — one row per test group that ran, then a total. The
  whole captured pytest output goes to last_test_output.txt beside the record,
  every run, with no flag to ask for it. Read or grep that file for detail.

triaging a large failure set:
  --failures-by-cause   one line per distinct cause, with a count and an example
                        node id, over the whole suite — 242 failures become 4 lines
  --compare             only what moved against the last record: new reds, reds
                        that went green, appeared, gone

Both are computed over the merged RECORD rather than over the captured lines,
which is why neither takes a number: one collapses the whole suite's failures to
their distinct causes, the other reports only what moved.

Any other argument is passed through to pytest unchanged."""

# Record fields that describe one invocation of pytest rather than the state of
# the suite. A skip invokes nothing, so it carries these forward unchanged
# instead of restamping them onto a run that never happened.
RUN_FIELDS = (
    "timestamp",
    "argv",
    "target",
    "timed_out",
    "duration_s",
    "run_summary",
    "output_tail",
)


def _read_config() -> dict:
    """The config file's own contents, or `{}` when there legitimately is none.

    A missing file is a fallback only when NOBODY NAMED ONE. `DEVSECOPS_CONFIG`
    is a caller asserting that THIS project is described THERE, so a named file
    that is not there makes the assertion false — and carrying on then runs a
    DIFFERENT tree and banks a record that reports itself healthy at exit 0. An
    empty variable names nothing and is falsy at `CONFIG`'s `or`, so it keeps
    resolving to the skill's own file.

    Failing closed here rather than in `main` is deliberate: `RECORD` is resolved
    from this at import, so this is the last point before a wrong `active`
    decides where the record gets written.
    """
    if not CONFIG.is_file():
        if os.environ.get("DEVSECOPS_CONFIG"):
            raise SystemExit(f"DEVSECOPS_CONFIG names no readable file: {CONFIG}")
        return {}
    try:
        data = json.loads(CONFIG.read_text())
    except json.JSONDecodeError as exc:
        raise SystemExit(f"bad config JSON in {CONFIG}: {exc}")
    # A file holding `[]`, `null` or a bare scalar parses and then dies in the
    # merge with `'list' object is not a mapping`, naming neither the file nor
    # the cause. Same class of unusable config as unparseable text, so it gets
    # the same usage error rather than a traceback from two frames away.
    if not isinstance(data, dict):
        raise SystemExit(
            f"config is not a JSON object in {CONFIG}: {type(data).__name__}"
        )
    return data


def load_config() -> dict:
    """Skill config merged over the defaults."""
    return {**DEFAULT_CONFIG, **_read_config()}


def defaulted() -> list[str]:
    """The keys this project has NOT set, so they carry DEFAULT_CONFIG's value.

    A merged config cannot tell a chosen value from an assumed one, and that is
    the single question the skill's bootstrap has to answer: `docs/plans` is a
    plausible default and an equally plausible deliberate choice, and only the
    presence of the key in the file says which it was. Reported rather than
    inferred, so the bootstrap gate is mechanical instead of a judgement about
    whether a value "looks configured".
    """
    return sorted(k for k in DEFAULT_CONFIG if k not in _read_config())


def record_path(config: dict) -> Path:
    """Where the run record lives: the root of the configured test tree.

    Derived from `active` rather than taken relative to the working
    directory, which scattered a copy wherever the script happened to be
    invoked from and left readers unsure which one was current.

    It sits at the test tree's ROOT and deliberately not inside it. Nothing
    claims it today, so nothing invalidates on it — but a map entry naming a
    directory under `active` would sweep it in, and a record written where its
    own writing moves a digest can never match on the next read.
    """
    return Path(Path(config["active"]).parts[0]) / "last_test_validation.json"


def output_path(config: dict) -> Path:
    """Where the whole captured output goes: beside the record.

    Derived from `record_path` rather than spelled out, so a project whose `active`
    tree does not sit under `tests/` finds it in the same place its record is.

    Overwritten every run, and one run deep on purpose: a file per run leaves a
    directory nobody prunes, and what has to outlive the next run is the record's
    own `output_tail`, which is deliberately narrower.
    """
    return record_path(config).with_name("last_test_output.txt")


RECORD = record_path(load_config())
OUTPUT = output_path(load_config())


def target(config: dict, passthrough: list[str]) -> list[str]:
    """What to point pytest at — explicit arguments win, else the configured path.

    This is the whole reason the config exists: a bare invocation should run the
    project's suite without the caller having to remember where it lives.
    """
    return passthrough or [config["active"]]


def runner(project: Path) -> list[str]:
    """The pytest invocation for this project.

    devsecops is a portable skill, so the runner is discovered rather than
    hardcoded: a project with a pixi manifest is driven through `pixi run`,
    anything else through the interpreter already running this script.
    """
    if shutil.which("pixi"):
        for candidate in PIXI_MANIFESTS:
            manifest = project / candidate
            if manifest.is_file():
                return [
                    "pixi",
                    "run",
                    "--manifest-path",
                    str(manifest),
                    "python",
                    "-m",
                    "pytest",
                ]
    return [sys.executable, "-m", "pytest"]


def walk(project: Path, roots: list[str]) -> list[Path]:
    """Every file under roots.

    A root may name a file as well as a directory — pytest.ini changes test
    outcomes and lives in no directory root. A missing root contributes nothing.

    Dot-directories and __pycache__ are pruned: .pytest_cache and *.pyc are
    written by the very run being fingerprinted, so hashing them would move the
    digest on every run and no recorded result could ever be reused.

    Split out from the hashing so a group can be digested over an explicit file
    set rather than over a root list, which is what per-group selection needs.
    """
    paths: list[Path] = []
    for root in roots:
        base = project / root
        if base.is_file():
            paths.append(base)
        elif base.is_dir():
            for dirpath, dirnames, filenames in os.walk(base):
                dirnames[:] = [
                    d for d in dirnames if d != "__pycache__" and not d.startswith(".")
                ]
                paths.extend(Path(dirpath) / name for name in filenames)
    return paths


def digest_paths(project: Path, paths: list[Path]) -> tuple[str | None, int]:
    """SHA-256 over an explicit set of files, and how many were hashed.

    Each file contributes its project-relative path, its executable bit, and its
    bytes, length-delimited so no filename can be confused with content. The
    path is a term because a deletion or a rename is otherwise invisible:
    removing a file moves no surviving file's mtime, so an mtime walk reports a
    tree as unchanged after its contents have demonstrably changed. The
    executable bit is a term because a project that invokes its scripts directly
    breaks when `+x` is lost, with content byte-identical.

    Paths are deduplicated, so a group naming the same file through two map
    entries, or naming its own test file, pays for it once. One re-run is one
    re-run.

    (None, 0) when nothing resolves. A digest over the empty set is a stable
    real value, so returning one would let a misconfigured project fast-track
    its suite forever. Absent must be distinguishable from unchanged.
    """
    digest = hashlib.sha256()
    hashed = 0
    for path in sorted(set(paths)):
        try:
            data = path.read_bytes()
            executable = path.stat().st_mode & 0o111
        except OSError:
            continue  # raced or dangling symlink
        digest.update(
            f"{path.relative_to(project)}\0{executable:o}\0{len(data)}\0".encode()
        )
        digest.update(data)
        hashed += 1

    return (digest.hexdigest(), hashed) if hashed else (None, 0)


def groups(project: Path, config: dict) -> list[str]:
    """The test groups, discovered from the filesystem: one per test FILE.

    Paths relative to `active`, e.g. `evidence/test_gate.py`.
    Deliberately not read from the config: a new test file is a group the moment
    it exists, so there is no second place to update it and no way to forget
    one. The config only ever says what a group DEPENDS ON.

    A file rather than a directory because a directory is not how this suite is
    coupled. Measured over this project, grouping by bundle re-ran a median 24%
    of the suite per edited source file against 3% per file — one test file
    naming `recon.md` dragged its nine siblings along, taking that one file from
    3% to 85%. A file is also the unit junit reports, so attribution becomes an
    exact lookup instead of a prefix match.

    Dot-directories and `__pycache__` are pruned for the same reason `walk` does
    it, and names starting with an underscore are skipped: `_claim.py` and
    `_paths.py` are helpers, and the underscore namespace is reserved for
    pseudo-groups like UNATTRIBUTED, which must never collide with a real file.
    """
    base = project / config["active"]
    if not base.is_dir():
        return []
    found = []
    for path in base.rglob("test_*.py"):
        relative = path.relative_to(base)
        if any(part.startswith((".", "_")) or part == "__pycache__" for part in relative.parts):
            continue
        found.append(relative.as_posix())
    return sorted(found)


def claimed(project: Path, config: dict) -> dict[str, list[Path]]:
    """The files each group claims: its own test file, and the ones its map names.

    NOTHING IS FINGERPRINTED UNLESS AN ENTRY NAMES IT. The map is the whole
    story, and that cuts both ways for files inside the test trees.

    A shared HELPER stays out: `conftest.py`, `_paths.py`, `_claim.py`,
    `_fixtures/`. A helper is shared by everything importing it, so claiming it
    from each of them charges every one for an edit to a fixture — the cost this
    model exists to remove, and the largest single source of it. `proposable()`
    will not propose one, so a suggestion cannot reintroduce the charge.

    A test-tree file that is a SUBJECT is named like any other. A bundle's own
    `check_acceptance.py`, `stage.py`, `preflight.py`, `capture_fixtures.py` and
    `stub_abrowser.py` are what the `simulation_tooling` groups exist to test, so
    the groups testing them claim them. The rule being applied is one claimant
    per subject, not "no path under the test tree" — the distinction is what a
    group DOES with the file, which no path prefix can express.

    What the helper exclusion gives up: a broken helper invalidates no group, so
    it can sit until something re-runs for another reason. It breaks loudly when
    it breaks — a helper that does not import takes collection down for
    everything that imports it — just not immediately.

    The map is therefore the entire story about what a group's digest covers, and
    `map_health` is what reports a group that has not told it anything.
    """
    mapped = config.get("test_groups", {})
    base = Path(config["active"])
    return {
        name: [project / base / name] + walk(project, mapped.get(name, []))
        for name in groups(project, config)
    }


def group_digests(
    project: Path, config: dict, extra: tuple[str, ...] = ()
) -> dict[str, str | None]:
    """One digest per group: its own files and its mapped files, and nothing else.

        digest(g) = sha256(g's own test file + the files test_groups assigns it)

    There is no whole-tree term. A file no group claims is UNTRACKED — editing it
    invalidates nothing — which is the trade this model makes deliberately: the
    map is the whole story, and a group's cost is exactly what its entry names.

    What that gives up is a fail-safe. Nothing charges the suite for a file the
    map forgot, so an omission is silent rather than expensive. `map_health`
    REPORTS an unmapped group instead of charging everyone for it, and it is the
    only signal there is.

    `extra` names groups that exist only in a record — UNATTRIBUTED — which claim
    no files and so digest to None. `stale_reason` reads that as nothing to
    fingerprint and always runs them, which is what an unattributed result wants.
    """
    digests = {
        name: digest_paths(project, paths)[0]
        for name, paths in claimed(project, config).items()
    }
    for name in extra:
        digests.setdefault(name, None)
    return digests


def load_record() -> dict:
    """The last recorded run, or {} when there is none to read.

    A record written before this file grew a content digest simply lacks one, so
    `still_valid` rejects it and the suite runs once.
    """
    try:
        record = json.loads(RECORD.read_text())
    except (OSError, json.JSONDecodeError):
        return {}
    return record if isinstance(record, dict) else {}


def conflicts(config: dict) -> list[str]:
    """Config values that contradict each other, one sentence per contradiction.

    Distinct from `map_health`, which reports the map against the FILESYSTEM.
    These are wrong before any file is looked at.

    Only one so far, and it is the one a v3 project migrates straight into.
    `groups()` discovers by rglob over `active`, so a `working` tree nested
    inside `active` turns every scratch checkpoint into a durable group: the
    build's own mid-phase runs then attribute to real groups and bank as if they
    described the suite, which is the single guarantee the working/active split
    exists to make. It has to be caught here rather than pruned quietly in
    `groups()`, because pruning would still leave a bare run COLLECTING those
    tests — it would hide the misconfiguration without fixing what it costs.
    """
    found = []
    active, working = PurePosixPath(config["active"]), PurePosixPath(config["working"])
    if active == working or working.is_relative_to(active):
        found.append(
            f"`working` ({working}) is inside `active` ({active}): every test a "
            "build writes would be discovered as a durable group. Put them in "
            "sibling directories — e.g. active `tests/active`, working `tests/tmp`."
        )
    return found


def map_health(project: Path, config: dict) -> dict[str, list[str]]:
    """Where the map and the tree disagree, keyed by kind.

    Three ways the two drift apart, each with its own cost:

    - `unmapped_groups` — discovered but absent from the map, so re-run on every
      invocation. Safe and slow, and this list is the ONLY signal that it is
      happening: nothing charges the rest of the suite for it any more, so an
      unmapped group is quietly expensive for itself alone until someone reads
      this.
    - `unknown_groups` — an entry naming no discovered file, left behind by a
      rename or a deletion. It claims files for a group that can never run, so
      those files are covered by nobody while the map looks complete.
    - `missing_paths` — a mapped dependency that no longer exists. The group
      keeps satisfying its digest check while the file it exercises moves
      underneath it. This is the silent direction.
    - `declares_no_dependencies` — an entry that is present and empty. Not a
      fault: `[]` is a CLAIM, saying the group depends on nothing outside its own
      test file, and the key's presence is what stops the group always running.
      It is reported because the three lists above are all blind to it — the key
      exists, so it is not unmapped; the group exists, so it is not unknown; and
      `missing_paths` iterates mapped paths, of which it has none. A claim no
      detector could see is one nobody checks, which is how five such entries in
      this project sat unexamined while the code they cover changed.

    Reporting the claim is deliberately not judging it. `--audit-map` is what
    decides whether an empty claim is TRUE, by reading what the test file
    actually names; a health key that only listed FALSE ones would have to make
    that judgement, and would then be silent about the rest.

    An entry mapped to an empty list therefore stays out of `unmapped_groups`.
    Reporting it there would tell a reader to add dependencies the group does not
    have.
    """
    mapped = config.get("test_groups", {})
    discovered = groups(project, config)
    return {
        "unmapped_groups": [name for name in discovered if name not in mapped],
        "unknown_groups": sorted(set(mapped) - set(discovered)),
        "missing_paths": sorted(
            {
                dependency
                for paths in mapped.values()
                for dependency in paths
                if not (project / dependency).exists()
            }
        ),
        "declares_no_dependencies": [
            name for name in discovered if name in mapped and not mapped[name]
        ],
    }


def explicit_targets(project: Path, passthrough: list[str]) -> list[str]:
    """Pass-through arguments that name an existing path.

    A caller who names a path is asking for that path to run — most often to
    watch a checkpoint go red — so selection steps aside and the record never
    answers on its behalf. The run is still banked: per-group merging replaces
    only the groups that produced results, so a targeted run says nothing about
    the groups it did not touch. Whether it says the whole truth about the ones
    it DID touch is a separate question, and `narrowed_run` below answers it —
    naming a path selects whole groups, but a `-k` alongside it does not.

    A flag, or a flag's value, is not a target: `-k test_alpha` names no path.
    That distinction is what keeps the wrapper's long-standing pytest
    pass-through working.
    """
    return [
        arg for arg in passthrough if not arg.startswith("-") and (project / arg).exists()
    ]


def narrowed_run(summary: dict[str, int], passthrough: list[str]) -> bool:
    """Whether this run selected WITHIN a group rather than across whole groups.

    Such a run reported on a FRACTION of every group it touched, so what it
    produced cannot stand alone for those groups: `merge_groups` merges its results
    over what the record already held rather than replacing them.

    That is the whole of what this decides. It does NOT hold the digest back — a
    fingerprint answers whether the code moved, which no selection changes.

    pytest's own deselected count is the evidence, which is direct rather than
    inferred and covers `-k` and `--deselect` alike, including selectors this has
    not been taught by name. But the count cannot say WHO deselected: `TIERS` makes
    every run pass an `-m`, so a bare `--tier fast` against a tree holding one
    integration-marked test reports a deselected count with no caller selector
    involved at all. Charging that to the caller is what defeated fingerprinting
    entirely — every bare run banked a held-back digest and stayed stale for ever.

    So the count is consulted only once the CALLER has passed something that could
    deselect, which is any OPTION. The tier's `-m` is added by this script and never
    reaches `passthrough`, so keying on passthrough is what separates the two
    sources. A bare path is not an option and selects whole groups by definition.

    A `::` node id is checked first and separately: it is the one narrowing shape
    that collects less WITHOUT deselecting anything, and it is not an option either,
    so neither test below would see it.

    Per RUN, not per group: the count says a filter ran, not which groups it
    thinned, so every group the run touched is merged. That errs toward keeping
    outcomes, which is the direction every other guard here errs in.

    `-x` and `--maxfail` are deliberately not here. Early exit fires only on a
    failure, that group banks red, and `stale_reason` re-runs anything whose last
    result was not green, so they are already safe by an older path.

    rat-tail: an option that deselects nothing still consults the count, so at a
    filtering tier `--collect-only` or `-p no:randomly` reads as narrowed and the
    run merges where it could have replaced. That costs a deleted test one extra
    run before it leaves the record. Name the flags if that ever matters.
    """
    if any("::" in arg for arg in passthrough):
        return True
    if not any(arg.startswith("-") for arg in passthrough):
        return False
    # The counts SUMMED across every lane, not read once off the concatenation.
    # `parse_summary` searches from the end and returns the first match it finds, so
    # against N pytest sessions it would answer for whichever lane was last.
    return bool(summary.get("deselected"))


# Flags this script used to carry, and what to reach for instead. They are refused
# BY NAME rather than left to fall through to pytest: `parse_known_args` forwards an
# unknown argument, so `--tail 20` would reach pytest, fail there with pytest's own
# wording and an exit code of 4, and tell a reader nothing about where the output
# went. Every one of them asked the caller to guess a size, or to filter output that
# is now a file — so the message names the replacement rather than only the refusal.
RETIRED = {
    "--tail": "stdout carries a summary; the whole output is in last_test_output.txt",
    "--head": "stdout carries a summary; the whole output is in last_test_output.txt",
    "--failures": "read last_test_output.txt, or --failures-by-cause for the causes",
    "--json": "the record and last_test_output.txt already hold all of it",
    "--grep": "grep last_test_output.txt",
    "--grep-v": "grep last_test_output.txt",
    "--ignore-case": "grep last_test_output.txt",
    "--context": "grep last_test_output.txt",
    "-i": "grep last_test_output.txt",
    "-C": "grep last_test_output.txt",
}


def retired_flag(passthrough: list[str]) -> str | None:
    """Why this invocation names a flag that no longer exists, or None.

    Long options are split on `=` and short ones matched on their first two
    characters, because pytest accepts a value attached to either (`-C2`,
    `--grep=passed`) and comparing whole arguments would refuse the spaced form
    while passing the attached one.
    """
    for arg in passthrough:
        name = arg.split("=", 1)[0] if arg.startswith("--") else arg[:2]
        if name in RETIRED:
            return f"{name} is retired: {RETIRED[name]}"
    return None


def selector_conflict(passthrough: list[str]) -> str | None:
    """Why this invocation contradicts itself, or None.

    `-m` alone. The tier's own marker — `TIERS[...]` or `EVERY_TIER` — is appended
    AFTER the caller's and pytest takes the last one, so a caller's `-m` is
    silently inert whatever the tier. Refusing it says so.

    A within-group selector is no longer a conflict at any tier. It was refused
    alongside `--tier all` because that pairing banked an authoritative digest off
    a partial run; a test group that runs green banks its fingerprint under any
    selection now, deliberately, so there is nothing left for that rule to protect.
    `-k` and a `::` node id are how a build watches one checkpoint go red, and
    `harvest.md` Step 6 verifies each moved test with exactly that shape.

    A PATH was never a selector either. It picks whole test groups, which the
    record describes exactly, and `explicit_targets` already treats it as the
    caller taking over selection.
    """
    for arg in passthrough:
        if arg[:2] == "-m" and not arg.startswith("--"):
            return f"{arg}: the tier already sets -m, and pytest takes the last one"
    return None


def stale_reason(record: dict, name: str, digest: str | None,
                 mapped: bool = True) -> str | None:
    """Why this group must run, or None when the record still describes it.

    Ordered so the reason reported is the most informative one. Each clause is a
    way the entry could be about something else: a group nobody has validated, a
    group whose dependencies nothing records, a tree that moved, or a result that
    was not green.

    `mapped` is load-bearing. An unmapped group digests over its own test file
    alone, so it would go green once and then skip for ever while the production
    code it exercises moved underneath it — a silent false pass. A group with no
    map entry therefore ALWAYS runs. `map_health` reports it; this is what makes
    it safe meanwhile.

    The tier is not consulted, and no clause here can be. Every test file and
    every file it depends on is fingerprinted, so a digest that still matches
    means the group was validated against exactly this code — which is the whole
    question. Which tests a caller chose to select is that caller's business, and
    a workflow that wants a particular tier names it there.

    Nor is the banked exit code, any more. Only a GREEN test group banks a
    fingerprint, so a red one has nothing to match and the digest comparison
    already re-runs it. A separate clause asking whether the last result was green
    would be asking a question the digest has answered.
    """
    entry = (record.get("groups") or {}).get(name)
    if not entry:
        return "no record"
    if not mapped:
        return "no map entry"
    if digest is None:
        return "nothing to fingerprint"
    if entry.get("digest") is not None and entry.get("exit_code") != 0:
        # A fingerprint beside a red exit code cannot be produced by this version,
        # because a red test group banks none. The entry was written BEFORE that
        # rule, and trusting its digest would skip a test group last seen failing —
        # the one outcome this whole mechanism exists to prevent. This is not the
        # deleted exit-code clause returning under another name: that clause judged
        # a coherent entry, this one refuses an incoherent one.
        return "no record"
    if entry.get("digest") != digest:
        # A red test group banks no digest, so a banked None beside a real computed
        # one is what "was red" looks like from here. Reported as itself, because
        # "changed" would be untrue and the reason is the only thing this returns
        # that a human reads.
        return "not green" if entry.get("digest") is None else "changed"
    return None


def select(
    project: Path, config: dict, record: dict
) -> tuple[list[str], dict[str, str | None], dict[str, str | None]]:
    """Which groups must run and why. -> (stale, reasons, digests)

    Candidates are the discovered groups, plus UNATTRIBUTED when the record
    carries it — a pseudo-group with no directory, considered only once a run
    has actually produced results that matched no group. UNATTRIBUTED is
    unmapped by construction, so it always runs.
    """
    recorded = tuple(record.get("groups") or ())
    digests = group_digests(project, config, extra=recorded)
    mapped = config.get("test_groups", {})
    candidates = set(groups(project, config))
    if UNATTRIBUTED in recorded:
        candidates.add(UNATTRIBUTED)
    reasons = {
        name: stale_reason(record, name, digests.get(name), name in mapped)
        for name in sorted(candidates)
    }
    return [name for name, reason in reasons.items() if reason], reasons, digests


def stale_files(config: dict, stale: list[str]) -> list[str]:
    """The test-group files to hand pytest, one per stale test group.

    Every case, with no branch. This used to hand pytest the `active` DIRECTORY
    when every test group was stale, so that a test file discovery had missed was
    still collected — landing under UNATTRIBUTED, which always runs, which meant
    the directory was handed over again next time and the arrangement sustained
    itself. That is gone: selection identifies test groups, and the arguments
    pytest receives are those test groups. A file that is not a test group has no
    fingerprint and no entry, so it was never tracked and running it was the
    anomaly.

    Removing the branch is also what lets every run batch the same way. A
    directory cannot be split into lanes, so while it existed the widest run — the
    one with the most to gain — was the one case that could not be parallelised.

    UNATTRIBUTED names no file and contributes nothing here. It needs no special
    handling: a bare run drops it from the record entirely, since `merge_groups`
    keeps it only for a targeted run.
    """
    return [str(Path(config["active"]) / name) for name in stale if name != UNATTRIBUTED]


def attribute(config: dict, names: list[str], tests: list[dict]) -> dict[str, list[dict]]:
    """Group junit outcomes by the test file they came from.

    junit reports `classname` as the dotted module path relative to pytest's
    rootdir and carries no `file` attribute (checked against pytest 9.1.1). A
    group is one test FILE, so that dotted path identifies it exactly: the
    lookup is built by dotting each known group's path, and matching is
    equality. No prefix test, and so no way for a result to be filed under a
    group that merely shares a name prefix with its own.

    A result matching nothing splits two ways, because two unrelated things
    reach this point and only one of them is a fault.

    A result from INSIDE `active` that matched no group is a failure of
    attribution — a rootdir that is not what this assumed, or a file discovery
    missed. It lands under UNATTRIBUTED, which claims no file, digests to None
    and always runs: attribution breaking degrades the mechanism to always-run
    rather than to a silent skip.

    A result from OUTSIDE `active` is not a fault and is DROPPED. `dev_flow.md`
    tells every build to run its checkpoints out of the `working` tree, so those
    results are expected rather than anomalous — and `working` is deliberately
    unmapped, on the bootstrap's own argument that a scratch test about to be
    merged or deleted should cost nobody a map entry. Filing them under
    UNATTRIBUTED made one prescribed checkpoint run poison the record for every
    later run: the entry always re-runs, and its red exit code propagates to the
    suite through `aggregate`. A record that describes `active` has nowhere to put
    a result that is not part of it.
    """
    base = Path(config["active"])
    known = by_module(config, names)
    # Dotted, to compare against junit's dotted `classname` — `tests/active`
    # becomes `tests.active.`, which `tests.tmp.test_x` does not start with.
    inside_active = str(base).replace(os.sep, ".") + "."
    out: dict[str, list[dict]] = {}
    for test in tests:
        module = test["id"].split("::")[0]
        group = known.get(module)
        if group is None:
            if not module.startswith(inside_active):
                continue
            group = UNATTRIBUTED
        out.setdefault(group, []).append(test)
    return out


def group_entry(tests: list[dict], digest: str | None, stamped: str,
                duration: float) -> dict:
    """One group's line in the record.

    `exit_code` is derived from the group's OWN outcomes. The process exit code
    cannot say which group failed, and without that a single red test anywhere
    would either re-run everything forever or let a genuinely broken group be
    skipped behind someone else's green.

    Both fields describe exactly the list handed in, which is what makes the merge
    in `merge_groups` sufficient: pass the whole group and the entry describes the
    whole group. A `None` digest reaches here only from a group nothing could
    fingerprint.

    ONLY A GREEN TEST GROUP BANKS A FINGERPRINT. A red one has nothing to match,
    so `stale_reason`'s digest comparison already re-runs it — which is why that
    function needs no clause about an exit code, and why `digest` now means exactly
    one thing: this test group was green against this code. A digest stamped on a
    red result meant the other thing as well, and the second clause existed only to
    undo it.

    No tier. A tier is a SELECTION the caller made, not a property of a result:
    every test file and every file it depends on is fingerprinted, so a digest
    already answers whether a group must run and a tier adds nothing to it. A
    workflow that needs a particular tier names it in the workflow.
    """
    summary: dict[str, int] = {}
    for test in tests:
        summary[test["outcome"]] = summary.get(test["outcome"], 0) + 1
    red = bool(summary.get("failed") or summary.get("error"))
    return {
        "digest": None if red else digest,
        "timestamp": stamped,
        "exit_code": 1 if red else 0,
        "summary": summary,
        # The measured time of the run that produced these results, passed in rather
        # than derived from `tests`, so a CARRIED entry keeps the figure it was banked
        # with. It orders lanes and nothing else, so a narrowed run under-reporting it
        # costs at most one wave of packing, corrected by the next run that executes
        # the whole test group.
        #
        # A RED test group records it too. It banks no fingerprint, so it is the one
        # most likely to run again — scheduling it last for want of a figure is the
        # worst available order.
        "duration_s": round(duration, 1),
    }


def merge_groups(
    project: Path,
    config: dict,
    previous: dict,
    fresh: dict[str, list[dict]],
    digests: dict[str, str | None],
    stamped: str,
    durations: dict[str, float],
    targeted: bool = False,
    narrowed: bool = False,
) -> tuple[dict[str, dict], list[dict]]:
    """Carry the groups that did not run, replace those that did, drop those gone.

    A carried group's per-test outcomes are recovered by RE-ATTRIBUTING the
    previous record's flat `tests` list rather than being stored a second time
    under each group. Attribution is a pure function of the test id, so the flat
    list stays the only copy and the record does not double in size.

    Only groups that actually produced results are replaced. A group that ran
    and reported nothing keeps whatever entry it had, and gains none if it had
    none: the run learned nothing about it. That rule is what lets every run
    bank unconditionally — without it, one `-k something` or one run aimed at a
    single file would file every group it filtered out as validated on zero
    tests, which is the whole record corrupted by a narrow run.

    That covers the ALL-OR-NOTHING case and not the PARTIAL one, which is what
    `narrowed` is for. A group that produced SOME results reported on a fraction
    of itself: replacing wholesale dropped the outcomes it did not re-run, while
    still stamping a current digest, so the next run skipped a group the record
    only partly described. Such a group is MERGED over what was carried and has
    its digest held back instead — see the loop below.

    UNATTRIBUTED is the one entry that rule cannot keep. It holds results from
    inside `active` that matched no test group — attribution broken — and it claims
    no file, so it is always stale and contributes no lane. Carried by the same rule
    as a real test group it would never leave. `targeted` is what distinguishes the
    two cases: a selection run dispatches a lane per known test group, so if
    attribution now succeeds the entry produces no results and its silence is proof
    it is spent rather than proof the run missed it.

    Out-of-tree results no longer reach here at all — `attribute` drops them — so
    a checkpoint run out of the WORKING tree can no longer create this entry.
    """
    names = groups(project, config)
    alive = set(names) | ({UNATTRIBUTED} if targeted else set())
    carried = attribute(config, names, previous.get("tests") or [])

    entries = {n: e for n, e in (previous.get("groups") or {}).items() if n in alive}
    per_group = {n: carried.get(n, []) for n in entries}

    for name, results in fresh.items():
        if not results:
            continue
        # A run that narrowed a group from within reported on a FRACTION of it, so
        # its results are MERGED over what the record carried, keyed by test id. The
        # entry then still describes the whole group: `group_entry` derives `summary`
        # and `exit_code` from the list it is handed, and `delta` reads the flat list
        # on the documented premise that every group is carried forward whole. An id
        # the record has not seen is additive — that is how a newly harvested test
        # first enters, since `harvest.md` Step 6 verifies each one with a `-k` run.
        #
        # REPLACEMENT is what an un-narrowed run does instead: it reported on the
        # whole group by definition, so what it did not report is gone. Merging
        # unconditionally would restore a deleted test from the carried list on every
        # later run and it would never leave. That is the whole of what `narrowed`
        # decides.
        #
        # The DIGEST is not part of it. A group that produced results is stamped with
        # the digest computed over its own files, whatever selection the caller made
        # to reach it — a fingerprint answers whether the code moved, which is the
        # only question `stale_reason` asks of it. Holding it back for a narrowed run
        # is what made the fast tier's own `-m` defeat fingerprinting entirely: the
        # deselected count it produces is indistinguishable from a caller's, so every
        # bare run banked `None` and every group stayed stale for ever.
        #
        # What keeps a partial run honest is elsewhere and stays there: a test group
        # that runs green banks a fingerprint under ANY selection, deliberately, and
        # a red one banks none at all — so a partial run that went red re-runs on
        # the digest comparison, and one that went green is green.
        banked = results
        if narrowed:
            merged = {test["id"]: test for test in carried.get(name, [])}
            merged.update({test["id"]: test for test in results})
            banked = sorted(merged.values(), key=lambda test: test["id"])
        entries[name] = group_entry(
            banked, digests.get(name), stamped, durations.get(name, 0.0)
        )
        per_group[name] = banked

    tests = sorted(
        (test for results in per_group.values() for test in results),
        key=lambda test: test["id"],
    )
    return entries, tests


class Lane(NamedTuple):
    """One test group's whole run: what it printed, how it exited, what it produced."""
    name: str
    lines: list[str]
    code: int
    timed_out: bool
    tests: list[dict]
    durations: dict[str, float]


def lane_order(record: dict, stale: list[str]) -> list[str]:
    """Stale test groups, longest banked duration first; never-timed ones last.

    With five lanes over more test groups than that, an alphabetical dispatch can
    put the two slowest in the final wave and the batch then waits on both. Order
    is the whole reason a duration is banked.

    A test group with no banked duration sorts to zero and goes last: it costs one
    run to learn, and guessing it is slow would displace one known to be. `sorted`
    is stable, so those keep the order they arrived in — which is `select`'s, and
    therefore alphabetical — rather than an arbitrary one that differs per run.
    """
    entries = record.get("groups") or {}
    return sorted(
        stale, key=lambda name: -(entries.get(name, {}).get("duration_s") or 0.0)
    )


def lane_code(codes: list[int]) -> int:
    """One exit code for the batch, keeping pytest's own meanings.

    Zero only when every lane passed. A usage or internal error OUTRANKS a test
    failure, because `main` branches on `code in (0, 1)` to decide whether the run
    described the tests at all — reporting a dead lane as a plain failure would let
    a partial batch bank as authoritative on results it never produced.

    Exit 5 folds to green: it means a lane collected nothing, which is what a filter
    matching nothing produces and is not a failure. No lanes at all is green for the
    same reason — nothing ran, so nothing failed.
    """
    hard = [code for code in codes if code not in (0, 1, 5)]
    if hard:
        return hard[0]
    return 1 if 1 in codes else 0


def sum_summaries(summaries: list[dict[str, int]]) -> dict[str, int]:
    """Counts across every lane.

    `parse_summary` searches from the END of the lines it is given and returns the
    first match, so calling it once on a concatenation of N pytest sessions reports
    ONE lane's counts as the whole run. Called per lane and summed here instead,
    which leaves `parse_summary` doing one job with one behaviour.
    """
    total: dict[str, int] = {}
    for summary in summaries:
        for kind, count in summary.items():
            total[kind] = total.get(kind, 0) + count
    return total


def run_lane(name: str, build_argv, deadline: float, config: dict,
             names: list[str]) -> Lane:
    """Run one lane to completion, retried once if it CRASHED.

    Crashed means it produced no junit at all AND exited outside (0, 1, 5) AND did
    not time out — the interpreter died, rather than tests failing. A test that
    merely failed is never retried, because a retry that turns a red green hides a
    flake instead of finding it. A timeout is never retried, because doing so would
    spend the batch's budget twice.

    `deadline` bounds the BATCH, not this lane: each lane is given what remains of
    it, so a lane starting in a later wave gets the remainder rather than a fresh
    allowance, and one with nothing left is not started at all. That last case
    reports as timed out, which is what it would have been.
    """
    for attempt in (1, 2):
        remaining = deadline - time.time()
        if remaining <= 0:
            return Lane(name, [], 1, True, [], {})
        with tempfile.TemporaryDirectory() as tmp:
            junit = Path(tmp) / "report.xml"
            code, lines, timed_out = stream(build_argv(junit), remaining)
            tests = parse_junit(junit)
            durations = group_durations(config, names, junit)
        if attempt == 2 or tests or timed_out or code in (0, 1, 5):
            return Lane(name, lines, code, timed_out, tests, durations)


def aggregate(entries: dict[str, dict]) -> tuple[int, dict[str, int]]:
    """The whole-suite view, summed over every group entry — carried and fresh.

    Not taken from the run that just finished. Once groups start being skipped
    those two diverge, and a `summary` describing only what ran would shrink
    out from under a baseline taken before the build.

    The exit code answers about the SUITE, so a carried red keeps it non-zero
    even when the run itself passed — and a run that failed on tests the record
    does not describe leaves it green, which is the same rule read the other
    way. The process code is not an input at all: it answers about the run, and
    a working-tree checkpoint exits non-zero over a green suite as a matter of
    course. The process still RETURNS pytest's own code to the caller.

    Empty entries are not green. `all()` over nothing is True, and a record
    describing no group has validated nothing — reporting that as a pass is the
    one answer this could give that is worse than the stamp it replaces.
    """
    summary: dict[str, int] = {}
    for entry in entries.values():
        for outcome, count in entry["summary"].items():
            summary[outcome] = summary.get(outcome, 0) + count
    green = bool(entries) and all(entry["exit_code"] == 0 for entry in entries.values())
    return (0 if green else 1), summary


def phrase(summary: dict[str, int]) -> str:
    """Counts as pytest phrased them, so a deliberate exclusion stays visible."""
    return ", ".join(f"{n} {kind}" for kind, n in summary.items()) or "no tests"


def report_lanes(lanes: list[Lane], totals: dict[str, int], elapsed: float) -> None:
    """One row per test group that RAN, then a total.

    This is what stdout carries instead of raw pytest output. A slice of N
    concatenated pytest sessions shows whichever lane came last and says nothing
    about the others, and the per-test-group shape is what a batched run actually
    has to report.

    Only lanes that ran appear — a test group carried forward on its fingerprint
    executed nothing, so a row for it would describe the record rather than the run.

    Counts come from pytest's own summary line rather than from the junit outcomes,
    so a deliberate exclusion stays visible: `deselected` has no per-test record at
    all and would vanish from a count derived from the tests.
    """
    if not lanes:
        return
    width = max(len(lane.name) for lane in lanes)
    for lane in lanes:
        counts = phrase(parse_summary(lane.lines))
        # Summed over the lane's own mapping: a lane runs ONE test group, so this is
        # that test group's figure, and a targeted lane's is the whole of what it ran.
        held = sum(lane.durations.values())
        print(f"  {lane.name:<{width}}  {counts:<34}{held:>8.1f}s")
    print(f"  {'-' * width}")
    plural = "" if len(lanes) == 1 else "s"
    print(f"  {'total':<{width}}  {phrase(totals):<34}{elapsed:>8.1f}s wall, "
          f"{len(lanes)} lane{plural}")


def summarise(record: dict) -> str:
    """Counts as pytest phrased them, so a deliberate exclusion stays visible.

    A fast track reporting only "green" would read as broader than it is: the
    fast tier deselects the integration suite on purpose, and that has to travel
    with the result rather than be dropped from it.
    """
    summary = record.get("summary", {})
    return phrase(summary) if summary else "no summary recorded"


def stream(argv: list[str], timeout: float) -> tuple[int, list[str], bool]:
    """Run argv under a timeout. Returns (exit code, captured lines, timed out).

    Captures every line and prints none of them: what reaches stdout is decided
    by the caller, so exactly one place answers that question. Splitting capture
    from display is what lets a summary reach stdout while the whole output goes to
    a file, instead of a caller guessing how much of it to print.

    Nothing is echoed as it arrives, and nothing raw reaches stdout at all. An echo
    here would be output no post-processor could filter, and several concurrent
    lanes cannot share one: interleaved lines from parallel workers are unreadable.
    Every line is captured, held, and written to the output file when the batch
    finishes, ANSI already stripped — see `output_path`.
    """
    lines: list[str] = []
    expired: list[bool] = []
    proc = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    assert proc.stdout is not None

    def expire() -> None:
        expired.append(True)
        proc.kill()

    watchdog = threading.Timer(timeout, expire)
    watchdog.start()
    try:
        for line in proc.stdout:
            lines.append(ANSI_RE.sub("", line.rstrip("\n")))
        code = proc.wait()
    finally:
        watchdog.cancel()

    if expired:
        print(f"\ntimed out after {timeout}s", file=sys.stderr)
    return code, lines, bool(expired)


def cases(path: Path) -> list[ET.Element]:
    """Every `<testcase>` in a junit report, or none if there is no report.

    One parse for both readers below, so a report is walked once rather than once
    for outcomes and again for time.
    """
    if not path.is_file():
        return []
    try:
        return list(ET.parse(path).getroot().iter("testcase"))
    except ET.ParseError:
        # A lane killed mid-write leaves truncated XML, and one killed before its
        # first write leaves an empty file. Reading either as no results is already
        # a handled case — the test group produces nothing, keeps the entry it had,
        # banks no fingerprint and runs again. An exception raised here instead
        # propagates out of a pool worker and ends the whole batch, losing every
        # other lane's results to one lane's death.
        return []


def by_module(config: dict, names: list[str]) -> dict[str, str]:
    """junit's dotted `classname` -> the test group it belongs to.

    junit reports `classname` as the dotted module path relative to pytest's
    rootdir and carries no `file` attribute (checked against pytest 9.1.1). A test
    group is one test FILE, so that dotted path identifies it exactly and the
    lookup is an equality — no prefix test, and so no way for a result to be filed
    under a test group that merely shares a name prefix with its own.

    Shared by the two readers that need it, `attribute` and `group_durations`, so
    the convention is written down once. Two copies would agree until pytest
    changed it, and then disagree about which test group a result belonged to.
    """
    base = Path(config["active"])
    return {
        str((base / name).with_suffix("")).replace(os.sep, "."): name for name in names
    }


def group_durations(config: dict, names: list[str], path: Path) -> dict[str, float]:
    """How long each test group's own tests took, from one junit report.

    Summed from the CASES rather than read off the `<testsuite>` element, which
    also charges collection: a per-report cost that says nothing about how long the
    tests took, and one that varies with how a batch was scheduled.

    Keyed per test group rather than totalled per report, because the two shapes
    this has to answer are the same question. A serial run writes ONE report
    holding every test group — a whole-report total would hand the run's figure to
    each of them, which is the exact defect the figure exists to avoid — and a lane
    writes one holding a single test group. Keying by `classname` makes them one
    case, so nothing here is recomputed when lanes arrive.

    A test group the report never mentions gets NO entry, rather than zero. The
    caller reads this for the test groups that produced results, and a zero would
    be indistinguishable from a real instant run while quietly resetting a figure
    that should have been carried.
    """
    known = by_module(config, names)
    durations: dict[str, float] = {}
    for case in cases(path):
        group = known.get(case.get("classname") or "")
        if group is not None:
            durations[group] = durations.get(group, 0.0) + float(case.get("time") or 0)
    return durations


def parse_junit(path: Path) -> list[dict[str, str]]:
    """Per-test outcomes from a junit-xml report, with the cause of each failure.

    A failing case also carries `message` — junit's failure/error attribute,
    which pytest fills with the crash's short repr (`AssertionError: unknown key
    'method'`). That is what a sweep gets bucketed by, and parsing it here is
    what lets the buckets describe groups this run never re-executed.

    Only failing cases carry it, so the record grows by the failure count rather
    than by the suite size: a green suite banks exactly what it banked before.
    """
    outcome_of = {"failure": "failed", "error": "error", "skipped": "skipped"}
    tests = []
    for case in cases(path):
        node = next((c for c in case if c.tag in outcome_of), None)
        outcome = outcome_of.get(node.tag if node is not None else "", "passed")
        test = {
            "id": f"{case.get('classname')}::{case.get('name')}",
            "outcome": outcome,
        }
        if outcome in RED:
            test["message"] = (node.get("message") or "").strip()
        tests.append(test)
    return tests


def cause(test: dict) -> str:
    """The bucket a failing test falls in: the first line of its message.

    Whitespace-collapsed, so a wrapped message and its single-line form land
    together. Matched exactly on that line, with no attempt to normalise values
    embedded in it: a cause carrying a varying id or path then splits into
    several buckets, which is visible and fixable, where an over-eager
    normaliser would silently merge two genuinely different causes and report a
    sweep as tidier than it is.
    """
    message = (test.get("message") or "").strip()
    return " ".join(message.splitlines()[0].split()) if message else NO_MESSAGE


def failures_by_cause(tests: list[dict]) -> list[tuple[str, int, str]]:
    """Failing tests bucketed by cause -> [(cause, count, example id)], commonest first."""
    buckets: dict[str, list[str]] = {}
    for test in tests:
        if test["outcome"] in RED:
            buckets.setdefault(cause(test), []).append(test["id"])
    return sorted(
        ((name, len(ids), min(ids)) for name, ids in buckets.items()),
        key=lambda row: (-row[1], row[0]),
    )


def report_causes(tests: list[dict]) -> None:
    """The shape of a sweep in one screen: how many distinct reasons, and which.

    The question a mechanical sweep actually poses is not which tests failed but
    how many different reasons there are and whether any is a surprise. An
    example id per bucket is what makes each one openable without a second run.
    """
    rows = failures_by_cause(tests)
    if not rows:
        print("\nno failing tests")
        return
    total = sum(count for _, count, _ in rows)
    print(f"\nfailures by cause — {len(rows)} causes across {total} failing tests:")
    for name, count, example in rows:
        print(f"  {count:>5}  {name}")
        print(f"         e.g. {example}")
    stale = next((count for name, count, _ in rows if name == NO_MESSAGE), 0)
    if stale:
        print(
            f"\n  {stale} of those were carried forward from a record banked before "
            f"causes were captured; re-running their groups fills them in."
        )


def delta(previous: list[dict], current: list[dict]) -> dict[str, list[str]]:
    """What moved between two test lists, keyed by kind.

    Compared by test id over the record's FLAT test list, which carries every
    group forward — so this is a whole-suite delta even when the run selected a
    handful of groups. A group that did not run keeps its previous outcome and
    therefore compares equal, dropping out with no special case.

    A test that is newly present AND red is reported as a new red rather than as
    an appearance: what matters is that it is red now and was not before, which
    is the same question whether or not the id existed last time.
    """
    was = {test["id"]: test["outcome"] for test in previous}
    now = {test["id"]: test["outcome"] for test in current}
    return {
        "new red": sorted(i for i, o in now.items() if o in RED and was.get(i, "") not in RED),
        "no longer red": sorted(
            i for i, o in now.items() if o not in RED and was.get(i, "") in RED
        ),
        "appeared": sorted(i for i, o in now.items() if i not in was and o not in RED),
        "gone": sorted(i for i in was if i not in now),
    }


def report_delta(previous: list[dict], current: list[dict]) -> None:
    """Only what moved. Silence here is the answer, not the absence of one.

    This is the comparison a baseline gate actually wants, and the tool is the
    only thing able to make it: it carries unselected groups forward, so it holds
    a whole-suite picture that a hand comparison against transcribed counts
    cannot — those describe only the groups that happened to run.
    """
    if not previous:
        print("\nno prior record to compare against — every result is new")
        return
    moved = delta(previous, current)
    if not any(moved.values()):
        print("\nnothing moved against the previous record")
        return
    print("\nmoved against the previous record:")
    for kind, ids in moved.items():
        for test_id in ids:
            print(f"  {kind:>13}  {test_id}")


def parse_summary(lines: list[str]) -> dict[str, int]:
    """Counts from pytest's final summary line, searching from the end."""
    for line in reversed(lines):
        found = SUMMARY_RE.findall(line)
        if found:
            return {
                ("error" if kind.startswith("error") else kind): int(count)
                for count, kind in found
            }
    return {}

def file_index(project: Path) -> dict[str, list[str]]:
    """Every project file, keyed by basename -> the paths sharing that name.

    Built once per invocation and passed down, so an audit over 38 groups walks
    the tree once rather than once per group.

    A basename map rather than a path map because that is the form a reference
    arrives in: a test names `"check_acceptance.py"`, not the path it lives at.
    Keeping the collision LIST rather than a single winner is what lets
    `resolve` refuse to guess.
    """
    index: dict[str, list[str]] = {}
    for dirpath, dirnames, filenames in os.walk(project):
        dirnames[:] = [d for d in dirnames if d not in INDEX_PRUNE]
        for name in filenames:
            index.setdefault(name, []).append(
                (Path(dirpath) / name).relative_to(project).as_posix())
    return index


def referenced_names(path: Path) -> set[str]:
    """The basenames one file NAMES, from the two forms that are not guesses.

    A string literal whose basename carries an extension, and an absolute
    import's module name plus `.py`. An import is not a heuristic: `import
    helper` names `helper.py` as certainly as the literal does.

    Docstrings are stripped, so prose describing a file is not a use of it.

    A bare stem in an arbitrary literal is deliberately NOT collected, and that
    single decision is what separates this rule from the looser one measured
    against it. `record.get("evidence_block")` is a dict key; counting it would
    demand `evidence_block.py` of 25 test files, none of which import the module.

    A file that will not parse yields nothing rather than raising. One bad file
    must cost its own group's derivation, never the whole audit.
    """
    try:
        tree = ast.parse(path.read_text(encoding="utf-8", errors="replace"))
    except (OSError, SyntaxError, ValueError):
        return set()

    docstrings = set()
    for node in ast.walk(tree):
        body = getattr(node, "body", None)
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef,
                             ast.ClassDef)) and body \
                and isinstance(body[0], ast.Expr) \
                and isinstance(body[0].value, ast.Constant) \
                and isinstance(body[0].value.value, str):
            docstrings.add(id(body[0].value))

    names: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Constant) and isinstance(node.value, str) \
                and id(node) not in docstrings:
            base = PurePosixPath(node.value.replace(os.sep, "/")).name
            if "." in base:
                names.add(base)
        elif isinstance(node, ast.Import):
            names.update(alias.name.split(".")[0] + ".py" for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module and node.level == 0:
            names.add(node.module.split(".")[0] + ".py")
    return names


def resolve(names: set[str], index: dict[str, list[str]]) -> tuple[set[str], set[str]]:
    """Basenames -> (resolved paths, ambiguous basenames).

    A basename identifying exactly ONE project file is a reference. One matching
    several is returned for reporting and never claimed: `verdict.json` matches
    95 files in this project, all of them run artifacts written BY the code under
    test, so claiming them all would bury every real finding and picking one
    would be a guess.

    A basename matching nothing is DROPPED, not reported — it is a stdlib module,
    a third-party package, or a string that merely looks like a filename, and
    reporting those would make the ambiguous set noise instead of a signal.
    """
    resolved, ambiguous = set(), set()
    for base in names:
        hits = index.get(base)
        if not hits:
            continue
        if len(hits) == 1:
            resolved.add(hits[0])
        else:
            ambiguous.add(base)
    return resolved, ambiguous


def proposable(config: dict, group: str, relative: str) -> bool:
    """Whether a resolved path may be proposed as one of `group`'s dependencies.

    Three exclusions, each for its own reason:

    - The group's OWN test file. Already digested; claiming it again is a
      dependency on itself.
    - The run RECORD. Written by the run, so a group claiming it would move its
      own digest on every invocation and nothing would ever be skipped again —
      the mechanism the map serves, disabled by the map.
    - `conftest.py` and `_`-prefixed names, but ONLY inside the configured test
      trees, matching `claimed()`'s rule that no test-tree helper is
      fingerprinted.

    That last qualifier is load-bearing rather than incidental.
    `.claude/skills/osint-claude/scripts/_env.py` is production code with a
    leading underscore, and a rule keyed on the NAME alone would drop a real
    dependency of four groups while looking like tidy hygiene.
    """
    if relative == record_path(config).as_posix():
        return False
    if relative == (Path(config["active"]) / group).as_posix():
        return False
    inside = any(
        tree and (relative == tree or relative.startswith(tree.rstrip("/") + "/"))
        for tree in (config.get("active", ""), config.get("working", ""))
    )
    name = PurePosixPath(relative).name
    return not (inside and (name == "conftest.py" or name.startswith("_")))


def derived(
    project: Path, config: dict, group: str, index: dict[str, list[str]]
) -> tuple[set[str], set[str]]:
    """What one group's test file references -> (paths, ambiguous basenames).

    Depth 0 — the group's own test file, and no walk of what that file imports.
    Following resolved imports was measured on this project and recovers 39 more
    real dependencies at five times the noise (636 surplus paths against 116),
    and `--suggest-map` output nobody can prune by hand is output nobody uses.

    rat-tail: depth 0. Walk the import graph if suggestions start missing
    dependencies more often than reviewers can supply them by reading.
    """
    resolved, ambiguous = resolve(
        referenced_names(project / config["active"] / group), index)
    return {r for r in resolved if proposable(config, group, r)}, ambiguous


def suggest_map(project: Path, config: dict) -> dict[str, list[str]]:
    """A proposed `test_groups`, one entry per DISCOVERED group.

    Discovered rather than read from the existing map, because the case this
    exists for is a project whose map is empty — iterating `test_groups` there
    would emit nothing at all, which is precisely when a suggestion is worth
    having.

    The caller PRINTS this. Nothing here writes `config.json`, and that is a
    design decision rather than an omission: a map entry asserts that a test
    exercises a file, which is a human judgement, and a tool that wrote it would
    be making that judgement on the operator's behalf.
    """
    index = file_index(project)
    return {
        group: sorted(derived(project, config, group, index)[0])
        for group in groups(project, config)
    }


def audit_map(project: Path, config: dict) -> dict[str, list[tuple[str, str]]]:
    """Each group's entry against what its test file names, bucketed by class.

    Only classes with findings appear, so an empty result means the map accounts
    for everything the rule can see.

    A group with NO entry can reach neither class that judges an entry —
    UNCLAIMED nor MISSING — though the advisory UNRESOLVABLE and BARREN still
    describe it, since those are about what its test file names rather than about
    what it claims. An absent entry is honest: it says the group is not mapped
    yet, `stale_reason` already makes an unmapped group ALWAYS run, so nothing is
    silently skipped, and `map_health` reports it. Failing on it would exit
    non-zero on every group of a project that has just adopted the skill, which
    is the state `--suggest-map` exists to move a project out of.

    An ambiguous reference counts toward UNCLAIMED exactly as a resolved one
    does. Resolvability decides whether the tool can SUGGEST the repair; it does
    not decide whether the claim is false. Requiring a resolved path let
    `simulation_tooling/test_shipped_stage_snapshots.py` — which names only
    `STAGE.json`, a basename six files share — sit in advisory BARREN while its
    `[]` entry was as false as the four this caught.
    """
    index = file_index(project)
    mapped = config.get("test_groups", {})
    findings: dict[str, list[tuple[str, str]]] = {
        UNCLAIMED: [], MISSING: [], UNRESOLVABLE: [], BARREN: []}

    for group in groups(project, config):
        references, ambiguous = derived(project, config, group, index)
        if ambiguous:
            findings[UNRESOLVABLE].append((group, ", ".join(sorted(ambiguous))))
        if not references and not ambiguous:
            findings[BARREN].append((group, "names no project file"))
            continue
        if group not in mapped:
            continue
        entry = mapped[group]
        if not entry:
            named = len(references) + len(ambiguous)
            findings[UNCLAIMED].append(
                (group, f"names {named} project file(s), claims none"))
            continue
        omitted = sorted(references - set(entry))
        if omitted:
            findings[MISSING].append((group, ", ".join(omitted)))

    return {name: rows for name, rows in findings.items() if rows}


def report_map_audit(findings: dict[str, list[tuple[str, str]]]) -> None:
    """The audit as an operator reads it, failures first.

    Each class is headed by its COUNT rather than by its name, so a header can
    never be mistaken for a finding by anything parsing the rows — and every row
    repeats its class, so a line stays readable on its own once the output is
    scrolled past its header.

    Advisory classes say so on the header. A reader who cannot tell which
    findings block the run will either treat all of them as blocking, and stop
    running the audit, or none of them, and stop reading it.
    """
    if not findings:
        print("map audit: every group's entry accounts for what its test file names")
        return
    for name in (UNCLAIMED, MISSING, UNRESOLVABLE, BARREN):
        rows = findings.get(name)
        if not rows:
            continue
        gate = "fails the audit" if name == UNCLAIMED else "advisory"
        print(f"\n{len(rows)} {name} ({gate}):")
        for group, detail in rows:
            print(f"  {name}  {group}  {detail}")


def main() -> int:
    parser = argparse.ArgumentParser(
        description=__doc__.splitlines()[0],
        epilog=TRIAGE_HELP,
        # Raw, so the epilog's grouping and line breaks survive; the default
        # formatter reflows it into one paragraph and the grouping is the point.
        formatter_class=argparse.RawDescriptionHelpFormatter,
        # No prefix matching. argparse would otherwise read `--failures` as an
        # abbreviation of `--failures-by-cause`, so a workflow still naming the
        # retired flag would silently get a bucket report with its N read as a test
        # path — which is worse than either honouring it or refusing it. Off, so an
        # unknown option reaches `passthrough` and `retired_flag` can name it.
        allow_abbrev=False,
    )
    # No default value: naming no tier means every tier, and `EVERY_TIER` is not a
    # choice because it is not a subset a caller picks. `None` is what tells the
    # two apart at the resolution below.
    parser.add_argument(
        "--tier",
        choices=sorted(TIERS),
        help="run only this tier; omit to run every test in every tier",
    )
    parser.add_argument(
        "--show-config", action="store_true", help="print the resolved config and exit"
    )
    parser.add_argument(
        "--suggest-map",
        action="store_true",
        help="print a proposed test_groups, derived from what each test file "
        "references; never writes config.json",
    )
    parser.add_argument(
        "--audit-map",
        action="store_true",
        help="check each group's test_groups entry against what its test file "
        "references; exits 1 on UNCLAIMED, other findings are advisory",
    )
    parser.add_argument(
        "--timeout",
        type=float,
        default=DEFAULT_TIMEOUT_S,
        help=f"seconds before the whole batch is killed, not each lane "
        f"(default {DEFAULT_TIMEOUT_S:g})",
    )
    parser.add_argument(
        "--failures-by-cause",
        action="store_true",
        help="bucket failing tests by the first line of their failure message and print counts",
    )
    parser.add_argument(
        "--compare",
        action="store_true",
        help="print only what moved against the record as it was at startup",
    )
    # SUPPRESS, not removed: forcing a run past a still-valid record is the operator's
    # call, and hiding it from `--help` is what stops an agent reaching for it.
    parser.add_argument("--force", action="store_true", help=argparse.SUPPRESS)
    # parse_known_args, not a REMAINDER positional: REMAINDER only starts
    # collecting at the first non-option argument, so `--tier fast --collect-only`
    # would die on the flag instead of forwarding it.
    args, passthrough = parser.parse_known_args()

    # Before the config is resolved and before anything touches the filesystem, so a
    # refused invocation cannot leave a record behind. `parser.error` exits 2 with
    # usage, which is what every other argument mistake here does.
    conflict = retired_flag(passthrough) or selector_conflict(passthrough)
    if conflict:
        parser.error(conflict)

    # The marker this run passes pytest. A named tier is a subset; naming none is
    # every test, which is the default.
    marker = TIERS[args.tier] if args.tier else EVERY_TIER

    config = load_config()
    project = Path.cwd()
    if args.show_config:
        print(json.dumps(
            {
                "source": str(CONFIG) if CONFIG.is_file() else None,
                # Where this skill is actually installed, so the workflows can
                # spell a shell command without assuming `.claude/skills/`.
                # Anchored to this file, so it is right under a project install,
                # a user-level install and a plugin alike — and it is reported
                # even when no config.json exists, which `source` is not.
                "skill_dir": str(Path(__file__).resolve().parents[1]),
                **config,
                "record": RECORD.as_posix(),
                # Where the whole captured output lands, every run. Derived beside
                # `record`, and reported for the same reason: a workflow that wants
                # the detail should not hardcode a path that is wrong for every
                # project whose `active` tree does not sit under `tests/`.
                "output": OUTPUT.as_posix(),
                # Empty means the config answers for itself and the bootstrap
                # has nothing to ask; anything listed still carries a guess.
                "defaulted": defaulted(),
                "groups": groups(project, config),
                # Config against itself, before any file is consulted. The
                # bootstrap gate requires this empty; nothing else does, so a
                # migration that ignores it degrades quietly.
                "conflicts": conflicts(config),
                # `unmapped_groups` is the cost signal: a group listed here
                # re-runs on every invocation until its entry exists.
                "map_health": map_health(project, config),
            },
            indent=2,
        ))
        return 0

    # Printed rather than written, and returning here rather than falling
    # through: a suggestion is something an operator reads and prunes, so it has
    # no business invoking pytest or touching the record on the way.
    if args.suggest_map:
        print(json.dumps(suggest_map(project, config), indent=2))
        return 0

    # Answers about the MAP, not about the tests, so it invokes no pytest and
    # banks nothing. Only UNCLAIMED reaches the exit code — see `audit_map`.
    if args.audit_map:
        findings = audit_map(project, config)
        report_map_audit(findings)
        return 1 if findings.get(UNCLAIMED) else 0

    wanted = target(config, passthrough)
    targeted = explicit_targets(project, passthrough)

    record = load_record()
    digests: dict[str, str | None] = {}
    reasons: dict[str, str | None] = {}
    # What pytest is actually handed. When the caller named a path, that is
    # their whole request verbatim; otherwise selection chooses the paths and
    # the pass-through arguments are carried through in front of them. Only the
    # PATHS are selected — dropping a `-k` here would silently widen the run.
    run_args, skip = list(passthrough) if targeted else [], False

    if not targeted:
        stale, reasons, digests = select(project, config, record)
        if args.force:
            stale = list(reasons)
        if reasons and not stale:
            skip = True
        else:
            # No fallback to the `active` directory when nothing is stale and
            # nothing is discovered: an empty list means pytest is handed no path,
            # collects nothing, and exits 5 — which is the honest answer for a tree
            # holding no test group at all.
            run_args = list(passthrough) + stale_files(config, stale)
            if reasons and len(stale) < len(reasons):
                print(f"selected {len(stale)} of {len(reasons)} test groups "
                      f"({len(reasons) - len(stale)} unchanged):")
                for name in stale:
                    print(f"  {name} — {reasons[name]}")

    # A skip runs nothing, but it still falls through to the writer: a group
    # whose test file was deleted has to leave the record, and deleting that
    # file moves no surviving group's digest — a group is digested over its own
    # files and its mapped files, and the deleted file was in neither — so a
    # full skip is exactly the shape in which that happens.
    if skip:
        # No tier here, because the record no longer carries one. What a skip has
        # to say is that every group's fingerprint still matches, which is the
        # whole of why nothing ran.
        print(f"unchanged since {record['timestamp']} — every fingerprint still holds")
        print(f"  {summarise(record)} ({record['duration_s']}s)")

    argv: list[str] = []
    code, lines, timed_out, elapsed, tests = 0, [], False, 0.0, []
    durations: dict[str, float] = {}
    run_summary: dict[str, int] = {}
    barren = False
    if not skip:
        names = groups(project, config)
        # Probed ONCE and closed over. `runner` runs `shutil.which` and a manifest
        # check on every call, which thirty lanes would pay thirty times over.
        run_cmd = runner(project)

        def build_argv(target: list[str]):
            return lambda junit: run_cmd + marker + [f"--junit-xml={junit}"] + target

        # A TARGETED run is the caller's whole request verbatim, so it goes down one
        # lane rather than being split: naming a path is the caller taking over
        # selection, and there is no test-group mapping to divide it by.
        if targeted:
            # Named for what the caller asked for, so its summary row says something.
            # A lane's name is otherwise its test group, and a targeted run has none.
            work = [(" ".join(targeted), build_argv(list(passthrough)))]
        else:
            work = [
                (name, build_argv(list(passthrough)
                                  + [str(Path(config["active"]) / name)]))
                for name in lane_order(record, stale)
            ]

        started = time.time()
        deadline = started + args.timeout
        with ThreadPoolExecutor(max_workers=MAX_LANES) as pool:
            ran = list(pool.map(
                lambda item: run_lane(item[0], item[1], deadline, config, names),
                work,
            ))
        elapsed = round(time.time() - started, 1)

        # Dispatched longest-first, consolidated in NAME order. Dispatch order is a
        # scheduling decision and completion order is a race; neither should decide
        # what the captured output looks like, and only name order is the same on
        # every run.
        lanes = sorted(ran, key=lambda lane: lane.name)
        argv = build_argv([])(Path("<per-lane>"))
        lines = [line for lane in lanes for line in lane.lines]
        timed_out = any(lane.timed_out for lane in lanes)
        code = lane_code([lane.code for lane in lanes])
        run_summary = sum_summaries([parse_summary(lane.lines) for lane in lanes])

        # "Described the tests" is decided PER LANE, not for the batch. Only exit 0
        # and exit 1 mean a lane reported on its test group; a usage error, an
        # internal error or a timeout means it did not. Asking the question of the
        # batch instead would let one dead lane discard every healthy lane's
        # results — `lane_code` deliberately lets a hard error outrank a failure, so
        # a single crash would make the whole run undescribed and bank nothing.
        #
        # A lane that described nothing simply contributes nothing: its test group
        # produces no results, keeps whatever entry it had, banks no fingerprint and
        # runs again. That is the same rule a test group nobody selected already
        # travels under.
        for lane in lanes:
            if lane.code in (0, 1) and not lane.timed_out:
                tests.extend(lane.tests)
                durations.update(lane.durations)

        # A failing run that produced no per-test outcomes at all — pytest could
        # not start, a collection error, a usage mistake. There is nothing to
        # bucket or compare, and the triage reporters would answer "no failing
        # tests", which reads as success on a run that failed. So they stand
        # down and the raw output is shown even though a triage flag asked for
        # it to be replaced: replacing output with a summary only makes sense
        # when there is something to summarise.
        #
        # Exit 5 is excluded deliberately: it means pytest collected nothing,
        # which is what a `-k` filter that deselects everything produces. That
        # run is fine and its record still describes the whole suite — it is the
        # one shape in which red groups are carried forward rather than re-run.
        barren = not tests and code not in (0, 5)

        # A barren run is the one carve-out. It produced no per-test results, so
        # there is nothing to summarise, and answering it with a file path alone
        # would be worse than the raw output it replaced. Printed whole rather than
        # sliced: such a run died before collecting and printed little.
        # rat-tail: if a timeout ever floods this, print the path alone.
        if barren:
            print("\n".join(lines))
        else:
            report_lanes(lanes, run_summary, elapsed)

    # Re-fingerprinted AFTER the run, not reusing the digests selection was
    # decided on. A suite that writes anything under a root would otherwise be
    # recorded against a pre-run digest that no later invocation could match,
    # and nothing would ever be skipped again.
    digests = group_digests(project, config, extra=(UNATTRIBUTED,))
    stamped = datetime.now().astimezone().isoformat(timespec="seconds")

    # `tests` already holds only what a lane that DESCRIBED its test group produced
    # — the filter is applied per lane above, where each lane's own exit code is
    # still in hand. A lane that died contributed nothing, so its test group's
    # previously banked entry stands and it is re-run rather than being credited
    # with a result the run never produced.
    entries, banked_tests = merge_groups(
        project,
        config,
        record,
        attribute(config, groups(project, config), tests),
        digests,
        stamped,
        durations,
        bool(targeted),
        narrowed_run(run_summary, passthrough),
    )

    # Reported off the MERGED record rather than off this run's junit, so every
    # reporter answers about the suite — the choice `aggregate` already makes for
    # `summary`. It also puts these above the skip return below, which is what
    # makes `--failures-by-cause` on an unchanged tree an instant triage view of
    # what is already banked, invoking pytest not at all.
    if barren:
        print(
            "\nthe run produced no per-test results, so there is nothing to bucket "
            "or compare — its output above says why"
        )
    if args.failures_by_cause and not barren:
        report_causes(banked_tests)
    if args.compare and not barren:
        report_delta(record.get("tests") or [], banked_tests)
    if not (args.failures_by_cause or args.compare or barren):
        # Naming each failing test is what the buckets replace, so it happens
        # only when no bucketing was asked for. Empty on a collection error,
        # where there are no per-test outcomes and the raw output is all there is.
        failed = [test["id"] for test in banked_tests if test["outcome"] in RED]
        if failed:
            print("\nfailed tests:")
            print("\n".join(f"  {test_id}" for test_id in failed))

    # A skip that pruned nothing has nothing to say the record does not already
    # say, and rewriting it would restamp a validation onto a run that never
    # happened — the next skip would then report itself as "unchanged since"
    # a moment ago, hiding how long ago the suite was actually green.
    if skip and entries == (record.get("groups") or {}):
        return 0

    suite_code, suite_summary = aggregate(entries)

    # Two kinds of field, grouped rather than interleaved. A reader who cannot
    # tell them apart is the reader this record misled: a header describing the
    # last invocation sat next to a body describing the suite, with nothing
    # marking which question either answered.
    banked = {
        # What THIS INVOCATION did. Carried forward unchanged by a skip, which
        # performed no run to describe — see RUN_FIELDS.
        "timestamp": stamped,
        "argv": argv,
        "target": wanted,
        "timed_out": timed_out,
        "duration_s": elapsed,
        # This run's own counts, kept apart from the suite aggregate.
        # `deselected` has no per-test junit record at all, so it can only ever
        # be a property of a run.
        "run_summary": run_summary,
        "output_tail": lines[-50:],
        # What the SUITE is. Every one of these is computed over the group
        # entries below and none of them from this invocation, so the header and
        # the body cannot disagree.
        "exit_code": suite_code,
        "summary": suite_summary,
        "groups": entries,
        "tests": banked_tests,
    }
    # RUN_FIELDS describe an invocation of pytest. A skip performed none, so it
    # keeps what the record already said about the last one rather than
    # claiming this one's argv and zero duration; only the group entries
    # and the aggregates taken over them are a skip's to move.
    if skip:
        banked.update({key: record.get(key) for key in RUN_FIELDS})

    RECORD.write_text(json.dumps(banked, indent=2) + "\n")
    if skip:
        # Nothing ran, so calling this "recorded" would read as a validation.
        gone = sorted(set(record.get("groups") or ()) - set(entries))
        print(f"pruned from {RECORD}: {', '.join(gone)}", file=sys.stderr)
    else:
        print(f"\nrecorded: {RECORD} (exit {code})", file=sys.stderr)

    # Every run, unconditionally. A flag would reproduce exactly the failure the
    # removed `--tail` and `--head` produced: a caller who did not know they would
    # need the detail pays a second whole run to get it. A SKIP writes nothing —
    # it captured nothing, and an empty file would destroy the last real run's
    # output, which is the run a reader is looking for.
    #
    # Written AFTER the record, and a failure here costs the artifact rather than
    # the run: the result is already banked, the exit code still describes the
    # tests, and an unwritable convenience should not take the run down with it.
    if not skip:
        try:
            OUTPUT.write_text("\n".join(lines) + "\n")
            print(f"wrote {OUTPUT}", file=sys.stderr)
        except OSError as exc:
            print(f"could not write {OUTPUT}: {exc}", file=sys.stderr)

    return code


if __name__ == "__main__":
    sys.exit(main())
