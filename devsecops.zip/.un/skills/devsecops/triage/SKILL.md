---
name: triage
description: Moves issues through a state machine of triage roles, categorises them, verifies the claim against the codebase, asks what is missing, and writes agent-ready briefs.
---

<objective>
Move issues on the project issue tracker through a small state machine of triage roles, and leave each one either briefed for an agent, waiting on a named answer, or closed with its reason recorded.
</objective>

<quick_start>
The maintainer invokes `/devsecops:triage` and describes what they want in natural language. Interpret the request and act. Examples:

- "Show me anything that needs my attention" → `<show_what_needs_attention>`
- "Let's look at 03-cache-invalidation" → `<triage_an_issue>`
- "Move it to ready-for-agent" → `<quick_state_override>`
- "What's ready for agents to pick up?" → `<show_what_needs_attention>`

Read `<roles>` first; everything else reads against that vocabulary.
</quick_start>

<reference_docs>
- [AGENT-BRIEF.md](AGENT-BRIEF.md): how to write durable agent briefs
- [OUT-OF-SCOPE.md](OUT-OF-SCOPE.md): how the `docs/project/rejected/` knowledge base works
</reference_docs>

<roles>
Two **category** roles:

- `bug`: something is broken
- `enhancement`: new feature or improvement

Six **state** roles:

- `needs-triage`: maintainer needs to evaluate
- `needs-info`: waiting on reporter for more information
- `ready-for-agent`: fully specified, ready for an AFK agent
- `ready-for-human`: needs human implementation
- `wontfix`: will not be actioned
- `complete`: completed and archived

Every triaged issue must carry exactly one category role and one state role. If state roles conflict, flag it and ask the maintainer before doing anything else.

State transitions: an unlabeled issue normally goes to `needs-triage` first; from there it moves to `needs-info`, `ready-for-agent`, `ready-for-human`, or `wontfix`. `needs-info` returns to `needs-triage` once the reporter replies. The maintainer can override at any time; flag transitions that look unusual and ask before proceeding.
</roles>

<show_what_needs_attention>
Query the issue tracker and present three buckets, oldest first:

1. **Unlabeled**: never triaged.
2. **`needs-triage`**: evaluation in progress.
3. **`needs-info` with reporter activity since the last triage notes**: needs re-evaluation.

Show counts and a one-line summary per item. Let the maintainer pick.
</show_what_needs_attention>

<triage_an_issue>
1. **Gather context.** Read the full issue (body, comments, labels, author, dates). Parse any prior triage notes so you don't re-ask resolved questions. Explore the codebase using the project's domain glossary, respecting ADRs in the area. Run two checks against the codebase: (a) **redundancy**: search for an existing implementation of the requested behavior by domain concept (not just the request's wording), and report where you looked. If found, it's an already-implemented `wontfix` (step 5). (b) **prior rejection**: read `docs/project/rejected/*.md` and surface any that resembles this request.

2. **Recommend.** Tell the maintainer your category and state recommendation with reasoning, plus a brief codebase summary relevant to the request (including whether it's already implemented). Wait for direction.

3. **Verify the claim.** Before asking any questions, check that the claim holds up. For a bug, reproduce it from the reporter's steps. Report what happened: confirmed (with code path), failed, or insufficient detail (a strong `needs-info` signal). A confirmed verification makes a much stronger agent brief.

4. **Ask (if needed).** Where the request needs fleshing out, ASK THE MAINTAINER, one round of questions at a time, until it is specific enough to brief. Where it turns out to be bigger than one agent session can hold, stop asking and say so: that is a feature, planned with `/devsecops:plan`, not a brief. Sharpen domain terms as you go and update `CONTEXT.md` and the ADRs inline as decisions land. Questions are specific and answerable — "does a cancelled order keep its reservation?" — never "please provide more detail".

5. **Apply the outcome:**
   - `ready-for-agent`: post an agent brief comment ([AGENT-BRIEF.md](AGENT-BRIEF.md)).
   - `ready-for-human`: same structure as an agent brief, but note why it can't be delegated (judgment calls, external access, design decisions, manual testing).
   - `needs-info`: post triage notes (`<needs_info_template>`).
   - For `wontfix`, close the issue, with the comment depending on *why*:
     - **Already implemented**: the change already exists in the codebase. Point to where it lives; do **not** write to `docs/project/rejected/` (that KB is for *rejected* requests, not built ones).
     - **Rejected (bug)**: give a polite explanation, then close.
     - **Rejected (enhancement)**: write to `docs/project/rejected/`, link to it from a comment, then close ([OUT-OF-SCOPE.md](OUT-OF-SCOPE.md)).
   - `needs-triage`: apply the role. Optional comment if there's partial progress.

   **Confirm the write landed before reporting done.** Re-read the issue file: the `Status:` line reads the role you applied, and any comment, brief or `docs/project/rejected/` file you wrote is on disk. Report the outcome to the maintainer with the path.
</triage_an_issue>

<quick_state_override>
If the maintainer says "move it to ready-for-agent", trust them and apply the role directly. Confirm what you're about to do (role changes, comment, close), then act, then re-read the `Status:` line to confirm it changed. Skip the question round. If moving to `ready-for-agent` without one, ask whether they want an agent brief written.
</quick_state_override>

<needs_info_template>
```markdown
## Triage Notes

**What we've established so far:**

- point 1
- point 2

**What we still need from you (@reporter):**

- question 1
- question 2
```

Capture everything the question round resolved under "established so far" so the work isn't lost. Questions must be specific and actionable, not "please provide more info".
</needs_info_template>

<resuming>
If prior triage notes exist on the issue, read them, check whether the reporter has answered any outstanding questions, and present an updated picture before continuing. Don't re-ask resolved questions.
</resuming>

<success_criteria>
An issue is triaged when:

- It carries exactly one category role and one state role, and its `Status:` line on disk reads them.
- The outcome its state calls for exists: a brief for `ready-for-agent`, a brief plus the reason it can't be delegated for `ready-for-human`, triage notes for `needs-info`, the right closing comment for `wontfix`, and an `docs/project/rejected/` entry for a rejected enhancement only.
- Nothing was re-asked that prior triage notes had already resolved.
- The maintainer has been told what changed and where.

Triage does not build, and does not own `docs/project/plans/` — a request bigger than one agent session goes to `/devsecops:plan`.
</success_criteria>
