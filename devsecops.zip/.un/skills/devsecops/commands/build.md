---
description: Run a build under the DevSecOps flow, driven by the dev_flow workflow against the skill's code and testing rules. Writes a working file, edits code, and dispatches auditor subagents in parallel per test and per document type.
---

**Argument:** what to build. Optional — the workflow gathers requirements when it is empty.

<objective>
Execute a development task under the DevSecOps flow: $ARGUMENTS

Follows `workflows/dev_flow.md`, written against `rules/code.md` (smallest working solution) and `rules/testing.md` (what a good test is, which seam it sits at). Use when the user wants a structured, test-first, minimal-scope build with explicit requirements capture and phase checkpoints.
</objective>

<process>
1. Invoke the `devsecops` skill and follow its `<intake>`.
2. Follow `workflows/dev_flow.md` end-to-end, from Step 0's bootstrap gate through the harvest that closes it. It is the authority for every step, and names the rules each step reads.
3. Every step of the workflow ends on a `**Gate.**`. Clear each one on the record before starting the next; none is optional.
4. Honor consistency: match existing code style, arg names, CLI shape, variable names. Backwards compatibility is NOT a requirement unless the user asks for it.
</process>

<success_criteria>
- `workflows/dev_flow.md` was followed and every gate cleared on the record.
- Its `<success_criteria>` are met.
- Code style is consistent with the surrounding codebase (args, CLI, naming).
</success_criteria>
