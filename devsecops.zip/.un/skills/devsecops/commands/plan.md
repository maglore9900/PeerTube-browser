---
description: Explore an idea with the operator until the requirements are confirmed and a high-level plan is approved, then write both as a feature file under docs/project/plans/ for a build to start from.
---

**Argument:** the idea to explore, or the slug of one already under way in `.scratch/<slug>/notes.md`. Optional — empty asks what the idea is.

Read `.un/skills/devsecops/plan/SKILL.md` and follow it for: $ARGUMENTS

Read the file rather than reaching for the Skill tool: un registers a skill only one level below `.un/skills/`, and this one sits inside `devsecops/`, so `Skill(plan)` resolves to nothing.

**This is planning.** Ask the operator one question at a time, verify every premise about current code against the source, list the routes and let the operator set the scope. Once the requirements are confirmed and the plan approved, write `docs/project/plans/<NN>-<slug>.md` in the shape of `.un/skills/devsecops/templates/plan_template.md` — Requirements and High-level plan only — and hand it off as `/workflows:dev-flow docs/project/plans/<NN>-<slug>.md`.

Writes the feature file, `.scratch/<slug>/` notes and prototypes, and `CONTEXT.md` or an ADR when a decision lands. Edits no source file or test.

Example: `/devsecops:plan move session records off jsonl onto sqlite`
