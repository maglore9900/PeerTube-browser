---
description: Scan the codebase for deepening opportunities, present them as a markdown report under .scratch/, then work through whichever one the operator picks. May edit CONTEXT.md and add an ADR as decisions land.
---

**Argument:** a direction — a module, a subsystem, or a pain point. Optional — empty makes the skill infer hot spots from the commit history.

Read `.un/skills/devsecops/improve-codebase-architecture/SKILL.md` and follow it, for: $ARGUMENTS

Read the file rather than reaching for the Skill tool: un registers a skill only one level below `.un/skills/`, and this one sits inside `devsecops/`, so `Skill(improve-codebase-architecture)` resolves to nothing.

`<question_loop>` is a loop you run yourself: one question at a time, waiting for the answer, until the module's interface is decided. It ends at a decision to build, not at a build. A deepening too big for one session goes to `/devsecops:plan` instead.

Writes one markdown report to `.scratch/architecture-review-<timestamp>.md`, in the shape of `.un/skills/devsecops/improve-codebase-architecture/architecture_report.md`, and tells the operator the path. Any edit to `CONTEXT.md` or a new ADR happens only as a decision crystallises, with the operator in the loop, and is reported by path.

Example: `/devsecops:improve-architecture the plugin registry`
