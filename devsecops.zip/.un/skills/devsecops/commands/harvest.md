---
description: Move tests with lasting value out of the working test tree into the durable suite, retire what they replace, update the group map, and clear the remainder to ./delete_me/. Temporarily mutates production code to verify each moved test, restoring it before completion.
---

**Argument:** test files or a plan file. Optional — empty harvests every test file in the working tree.

<objective>
Harvest the working test tree: $ARGUMENTS

A build writes every test it authors into the `working` tree, which is unmapped and outside the durable suite. This pass decides, one test function at a time, which of them the suite should keep — moving those into the subject file named for the production script they drive, retiring any durable test they replace, and clearing the rest.

Use after a build closes, or against the accumulated tree when several have closed without one.
</objective>

<process>
1. Invoke the `devsecops` skill, then read its `workflows/harvest.md` and follow it end-to-end, from "Resolve the trees and the harvest scope" through "Run the suite and bank".

   *By name, not by path. This command is COPIED out of the skill by `SKILL.md <install_step>` and is not rewritten on the way, so a path baked in here would be wrong the moment the skill is installed anywhere but `.un/skills/devsecops/`.*
2. Treat `$ARGUMENTS` as the scope the workflow resolves at "Resolve the trees and the harvest scope".
3. Do not skip the plan approval gate at "Agree the harvest plan" — it is the last point before files move and `test_groups` changes.
4. Do not substitute a green re-run for the mutation procedure at "Verify every moved assertion by mutation". Coverage that already passed elsewhere proves nothing about its new home.
</process>

<output>
- HARVEST_FILE, the harvest record, at the path agreed in the workflow's first step.
- Test files added or extended under the `active` tree, one per production script.
- Test files moved into the configured `archive`, for durable tests the harvest replaces.
- `test_groups` in the skill's `config.json`, edited for files created, retired, or newly claiming a production file.
- Every file in scope moved out of `working` and into the configured `delete_me`, which the workflow reports at the close. Nothing is removed — that stays the user's decision.
- The banked run record, rewritten by the closing run.
</output>

<success_criteria>
Every criterion in the skill's `workflows/harvest.md` `<success_criteria>` is met — the harvest record, the user's approval before anything moved, the placement and retirement rules, a clean `--audit-map`, a recorded mutation per moved test, an emptied scope, and a banked suite.
</success_criteria>
