---
description: A quick request to pause development and resume in a new session.
---
After this, pause and update the plan so we can pick this up in a new session.
