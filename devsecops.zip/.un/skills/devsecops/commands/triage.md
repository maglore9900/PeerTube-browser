---
description: Move an issue through the triage roles — categorise it, verify the claim against the codebase, ask what is missing, and write the agent brief. Edits issue files under docs/project/issues/, and may record a rejected enhancement in .out-of-scope/.
---

**Argument:** what you want done, in plain words — "show me anything that needs attention", "let's look at 03-cache-invalidation", "move it to ready-for-agent". Optional — empty presents the three attention buckets and waits.

Read `.un/skills/devsecops/triage/SKILL.md` and follow it, with `AGENT-BRIEF.md` and `OUT-OF-SCOPE.md` beside it, for: $ARGUMENTS

Read the file rather than reaching for the Skill tool: un registers a skill only one level below `.un/skills/`, and this one sits inside `devsecops/`, so `Skill(triage)` resolves to nothing.

**The tracker is markdown in this repo, so read the skill's tracker verbs against `docs/project/issue-tracker.md`:**

- An issue is a file at `docs/project/issues/<NN>-<slug>.md`. "Issue #42" means the file numbered `42`; ask which one when the argument names an issue you cannot resolve to a path. A planned build is a FEATURE and lives at `docs/project/plans/<NN>-<slug>.md` — triage does not own those, so say so rather than filing one as an issue.
- "Apply the role" means edit the `Status:` line near the top of the file. One category role and one state role, per the skill.
- "Post a comment" and "post the agent brief" mean append to the bottom of the file, under `## Comments` and `## Agent Brief`.
- "Close the issue" means set `Status: wontfix`. Nothing moves and nothing is deleted; the file stays where it is and stays readable.
- "Query the tracker" means walk `docs/project/issues/*.md` and read the `Status:` lines.
- `.out-of-scope/` does not exist in this repo yet. Create it at the repo root the first time a rejected enhancement needs recording, per `OUT-OF-SCOPE.md`, and only for a rejection — never for something already built.

Step 4 is a question round you run yourself: ask the maintainer one thing at a time until the request is specific enough to brief, and update `CONTEXT.md` and `docs/project/adr/` inline as decisions land.

Edits the one issue file the run is about, and `CONTEXT.md` or an ADR when a decision lands. Writes `.out-of-scope/<concept>.md` only on a rejected enhancement. Never edits code.

Example: `/devsecops:triage show me anything that needs my attention`
