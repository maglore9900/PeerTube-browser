---
description: Configure this repo for the engineering skills — issue tracker, triage label vocabulary, and domain doc layout. Writes docs under docs/project/ and edits CLAUDE.md or AGENTS.md. Run once before first use of the other engineering skills.
---

**Argument:** a direction to start from, such as "issues go under .scratch/, one directory per feature". Optional — empty runs the skill's own exploration and asks.

Read `.un/skills/devsecops/setup/SKILL.md` and follow it end to end, using its seed templates beside it (`issue-tracker.md`, `triage-labels.md`, `domain.md`), for: $ARGUMENTS

Read the file rather than reaching for the Skill tool: un registers a skill only one level below `.un/skills/`, and this one sits inside `devsecops/`, so `Skill(setup-devsecops)` resolves to nothing.

The skill is prompt-driven, not a script. Its three sections — issue tracker, triage labels, domain docs — each get explored, proposed, and confirmed with the operator before anything is written. Do not write on the strength of the defaults alone.

**This repo already answers all three questions**, and both `AGENTS.md` and `CLAUDE.md` carry the `## Agent skills` block naming the answers: `.scratch/<feature-slug>/` for issues, the five canonical labels, `CONTEXT.md` at the root plus `docs/project/adr/` for the domain docs, with the three docs themselves at `docs/project/`. Treat that as the current state to reconcile against, not as a blank slate, and show the operator the difference rather than a fresh draft.

Writes `docs/project/*.md` and edits whichever of `CLAUDE.md` / `AGENTS.md` exists — both here, which the skill's step 4 covers — never creating one when the other is absent.

Example: `/devsecops:setup`
