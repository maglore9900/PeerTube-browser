# Issue tracker: Local Markdown

Work is tracked as markdown in this repo, split by kind. **An issue is something wrong or something asked for; a feature is something planned and built.** They live in different directories because they have different lifecycles: an issue moves through the triage roles and ends, a feature accumulates a plan and a build record.

| Kind | Lives at | Owned by |
|---|---|---|
| **Issue** — a bug, a defect, a small request | `docs/project/issues/<NN>-<slug>.md` | the `triage` skill |
| **Feature** — a planned, phased build | `docs/project/plans/<NN>-<slug>.md` | the devsecops build workflow |

Neither lives in `.scratch/`. That directory is working space for a session's own artifacts, not tracked work.

## Issues

- One file per issue at `docs/project/issues/<NN>-<slug>.md`, numbered from `01`, never a combined tickets file.
- Triage state is a `Status:` line near the top, carrying one category role and one state role. See `triage-labels.md` for the strings.
- Comments and conversation history append to the bottom under a `## Comments` heading.
- An agent brief appends under `## Agent Brief` when the issue reaches `ready-for-agent`.
- A closed issue keeps its file and its number. `Status: wontfix` is how it closes; nothing is moved or deleted.

## Features

- One file per feature at `docs/project/plans/<NN>-<slug>.md`, numbered in the sequence that directory already uses.
- The plan file IS the working file the build workflow writes: requirements, approved plan, impact inventory, per-phase checkpoint outcomes. It is created when the build starts, not when it finishes.
- A delivered feature moves to `docs/project/plans/archive/`, which is what keeps the top of `plans/` to work that is live.

## When a skill says "publish to the issue tracker"

Create the file under `docs/project/issues/`, taking the next free number (accounting for archive). Where the work is a planned build rather than a defect, it is a feature: create it under `docs/project/plans/` instead, and say which you chose.

## When a skill says "fetch the relevant ticket"

Read the file at the referenced path. The caller normally passes the path or the number directly; a bare number means `docs/project/issues/`.
