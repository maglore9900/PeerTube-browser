# {change name}

_Working-file template for the dev-flow workflow. Rename this heading with a short slug for the build (e.g. "Add direct-query support to source manifest"). Fill each section in the step it belongs to; do not skip ahead — later steps depend on earlier sections being current._

_**Structure convention**: use markdown subheaders (`###`, `####`) for every repeated item — one per phase, one per test, one per impacted file. Do NOT use tables for these lists. Tables scan poorly in a header-outline view (a reader looking for "the test that gates Phase 4" will jump the outline, not skim a compact grid) and don't grow well as each item accretes notes across Steps 7-9._

## Requirements
_Filled in Step 1. User-confirmed before Step 2 begins. Cover:_
- _What the user asked for (verbatim if useful for later reference)._
- _The underlying purpose — the why. If the ask is X but the goal is Y, capture Y._
- _Acceptance criteria the user has confirmed._
- _In scope / out of scope._
- _Consistency constraints (must match existing code style, args, CLI shape). Backwards compatibility is NOT required unless the user explicitly asks._
- _Conflicts — any requirement contradicting another or the tree, naming both sides, and how the user resolved it._
- _Test trees for this build — the resolved `active` and `working` from the skill's `config.json`, read at Step 0 via `--show-config`. This build authors every test into `working`; `workflows/harvest.md` moves what lasts into `active` after it closes._
- _Baseline suite state — the pre-build result Step 8 compares against: pass/fail counts, timestamp, and whether it was reused from the banked record (the `record` path `--show-config` reports) or freshly run. If RED, the `<baseline_variant>` failure set and the user's approval to substitute the success criterion belong here too._

## High-level plan
_Filled in Step 2. Prose only, no code. User-approved before Step 3 begins. Cover:_
- _Overall approach and how it satisfies each requirement above._
- _Alternatives considered and why the chosen one won._
- _Gotchas, risks, current + future limitations._
- _Tradeoffs the user has accepted._

## Impacts
_Filled in Step 3, one element at a time (do not defer to subagents). Every file / function / module / doc the high-level plan will touch or potentially affect. One `###` entry per element, each carrying the `path` it concerns, with a short impact analysis: what changes, what depends on it, risk of regression. Checked against the files and extended in Step 4's reassessment loop; feeds Step 9's doc updates._

### Highest risk
_The three elements considered highest risk, each with the reason._

### Reassessment
_Filled in Step 4, once per pass: the answers to its four questions, any entry the file did not bear out, new impacts added above, and the user-approved recommendations._

### Documentation to update
_Subset of the above — docs that require an explicit update in Step 9. Kept as a checklist so Step 9 has a concrete close-out; Step 9.1 marks each entry update / no update with a reason and adds any document it finds:_
- _[ ] `path/to/doc.md` — what changes._

## Implementation plan
_Draft filled in Step 5 against the rat-tail ladder; phases filled in Step 6. First draft of the actual code / structural changes: module map, signatures with invariants, tables and constants with their real contents, seams, and the decisions behind them._

### Phases
_Filled in Step 6 and user-approved there. One `#### Phase N — <name>` subsection per phase, at most four. Each phase carries:_
- _Kind — `code` or `prose` (text an agent acts on: skills, agent files, commands, rules, disciplines, workflows — never documentation, which is not a phase)._
- _Files touched (with distinction: NEW / EDITED / DELETED)._
- _**Intent (post-phase state)** — REQUIRED for every phase, code and prose alike, and written BEFORE the checkpoint is designed (`dev_flow.md` Step 6). One statement of what must be true after the phase lands, written so an outside reader could verify without further context. Anchors to specific files, sections, and structural elements. States what a caller or reader can do afterwards, never what the test asserts or what was pasted in._
- _**Clauses** — `C1` and at most `C2`, the Intent cut into atomic observable facts per `dev_flow.md <clause_form>`. For a code phase these are the checkpoint's `must_prove`._
- _**Checkpoint and seam** — for a code phase: what will be asserted, and the boundary it enters, naming the existing harness where there is one. For a prose phase: the Intent IS the check, verified by a full read and the document-type auditors per `dev_flow.md <prose_verification>`; name the auditor, or write `no matching auditor` and say which file._
- _**Clauses true today** — prose phases only, filled at Step 7.0: per clause, true or false against the tree before the phase runs, with the evidence, and the reason any clause already true stays._
- _**Self-check** — code phases, filled at Step 7.2 before dispatch and again after every BLOCK: one row per clause (id — assertion at `file:line` — expected — the wrong implementation and what the observable reads under it), any user-approved exemption quoted, the ten answers, and the red with its reason._
- _**Checkpoint audit** — code phases, filled at Step 7.3 in the format `rules/gates.md <outcome_format>` defines: both verdicts, shape first, with the predicted failure mode. Then Step 7.4's remediation: each UNCARRIED ledger row fixed or justified, and one line per numbered finding saying what was done._
- _**Changes** — what changed, file by file, and any file touched that the files list does not name. Step 9 is written from this._
- _**Checkpoint outcome** — filled during Step 7. Code: the passing re-run after implementation. Prose: the Criticals still standing and why, the recommendations applied and deferred, and what the audit and the read established. If it failed, capture what the check caught and how it was resolved before proceeding to the next phase._

## Inner unit tests
_Filled in Steps 7-8. An inner unit test is the EXCEPTION, not the rule: each one records why its phase's checkpoint could not express the behavior (`rules/gates.md <the_grain>`). A build with none is the normal case, and saying so explicitly is better than leaving the section empty. Checkpoint tests are NOT captured here — they live under each `#### Phase N` subsection above. One `### <test-file-or-name>` subsection per test — no tables:_
- _Location (path to the test file / test id)._
- _What it asserts, and the behavior its checkpoint could not express._
- _Inline review — filled at Step 8 against `rules/testing.md` and `rules/shape.md`._

## Close
_Filled in Step 8:_
- _Refactors made, left out with why, and anything that needed a fresh red instead._
- _Clause accounting — every `P<n>C<m>` resolved by its phase or carrying its exemption._
- _`--compare` result, and for any red: the cause, whether the test or the implementation was at fault, any checkpoint gap naming its phase, and any durable test retired with where it went._
