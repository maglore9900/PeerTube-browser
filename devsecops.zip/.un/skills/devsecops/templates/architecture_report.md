# Architecture review — {date}

_Report template for `improve-codebase-architecture`. One `##` section per candidate, then the top recommendation. Delete this line and every italic prompt below as you fill it in._

_**Vocabulary is fixed**: module, interface, depth, seam, adapter, leverage, locality. Use the domain nouns from `CONTEXT.md` for what the code is about. Do not drift into "component", "service", "API", or "boundary"._

## Scope

_What was scanned and why — the direction the user named, or the hot spots the commit history pointed at. Name the paths. A reader who disagrees with the scope should be able to see the choice that produced it._

## Candidate: {name}

**Strength**: `Strong` | `Worth exploring` | `Speculative`

**Files**: _the modules involved, by path._

**Problem**: _why the current architecture causes friction. Name the friction you hit while reading, not a rule it violates._

**Deletion test**: _would deleting this module concentrate complexity, or just move it? Answer it, don't assert it._

**Solution**: _plain English, what would change._

**Benefits**: _in terms of locality and leverage, and what becomes testable that is not testable now._

**Before**

```mermaid
graph TD
  %% the shallow shape: interface nearly as complex as the implementation
```

**After**

```mermaid
graph TD
  %% the deepened shape: what the interface now hides
```

_Where a graph does not communicate the change, cut the diagrams and describe the shape in two sentences. An empty diagram is worse than no diagram._

**Contradicts an ADR?** _Only when the friction is real enough to warrant reopening it. Name the ADR and say why it is worth reopening. Omit this line otherwise; do not list every refactor an ADR forbids._

## Top recommendation

_Which candidate to tackle first, and why. One paragraph._
