<good_test>
A test verifies behaviour through a public interface. The code can change entirely and the test stands, which is what makes it survive a refactor: it does not care about internal structure.

It reads like a specification. "user can checkout with valid cart" names exactly what capability exists, and the failure output tells a reader what broke without opening the file.
</good_test>

<seams>
A seam is the public boundary a test is written at: the interface where behaviour is observed without reaching inside. Tests live at seams.

**No test is written at an unconfirmed seam.** The seams under test are written down and agreed before any test exists. You cannot test everything, and agreeing the seams up front is how the effort lands on the critical paths and the complex logic instead of on every edge case.

**Before choosing a seam, look for the harness that already enters it.** The existing suite usually holds one, and the precedent is both the cheapest route and the argument for the seam. Where the seam genuinely cannot be entered in-process, say so in the phase's `<checkpoint>`, with what the test would cover instead, rather than working around it silently.

Where the shape of the interface is itself in question, `improve-codebase-architecture/SKILL.md <vocabulary>` defines module, interface, depth, adapter, leverage and locality.
</seams>

<coupling>
The author's call at the self-check, and not an auditor criterion: a checkpoint legitimately shims a severed layer, so a shape that would be a defect at a real endpoint is sanctioned at a checkpoint's seam.

A test is implementation-coupled when it mocks an internal collaborator, names a private method, asserts on a call count or an ordering, or verifies through a side channel — querying the store directly instead of reading back through the interface. The tell: it breaks on a refactor that changed no behaviour. It pins the route rather than the result, so it also passes a rewrite that broke one.

**The line is ownership: stand in for what you do not control, never for your own modules.** An external API, a clock, a random source, the model behind a provider service is legitimately stood in for, because the test cannot reach it and its behaviour is not what is under test. Prefer injecting the dependency over patching a module global, so the test supplies it by the same route production does.
</coupling>

<surfaces>
Two surfaces co-exist in a devsecops build. There is no outer acceptance test: the build closes when every Step 6 clause is resolved and the full suite is green (`gates.md <clause_accounting>`).

| Surface | Purpose | Level | Lifetime | Alter policy |
|---|---|---|---|---|
| **Checkpoint** | Prove one phase's slice landed and behaves correctly, clause by clause | Functional integration at the seam the phase's `<checkpoint>` names at Step 6: the lowest changed layer, then the highest reachable layer via shims | The life of the build. Shims inside a checkpoint that fake severed higher layers are removed once those layers exist | Only with recorded user approval |
| **Inner unit** | Verify a behaviour the phase's checkpoint cannot express — written by exception (`gates.md <the_grain>`) | Class or function; stand in only at system boundaries (`<coupling>`) | Permanent | Rename, extract and dedup freely at the Step 8 review; behaviour changes need user approval |

**A phase whose clause is about the real boundary says so in its `<checkpoint>`**, and that checkpoint then enters it: the real CLI, the pty, the live endpoint. Nothing else requires one.

The legitimate shims are on the far side of the boundary the checkpoint enters: a fake provider, a pty the test drives, a temporary project root, a captured stream. The test enters through the front door of its seam and observes what comes out of it.
</surfaces>

<checkpoint_definition>
A checkpoint is an executable functional test with real assertions against the phase's actual output — not a lint run, not a grep for a symbol, not a bare test-runner invocation with no functional assertion. If the phase's true output cannot be exercised in-process, the shim goes on the severed layer being simulated, not on the assertion being made.

A prose phase has no checkpoint; it runs `workflows/dev_flow.md <prose_verification>`. A phase uses one method or the other for an invariant, never both.
</checkpoint_definition>

<principle name="whole-claim">
Every clause of the test's name, its docstring, and its `must_prove` gets its own assertion. Count the clauses, count the assertions, and for each one name the wrong implementation it excludes. A claim of the form "X per Y" needs a second Y or it proves only X. A claim naming a set of fields asserts every member of the set. A claim with a positive and a negative half asserts both — "the disarm did not clear the line" does not establish "the next press arms afresh". A claim that a message names four things asserts four things.

The failure this catches is a test that asserts the EASIER half of what it claims, while its docstring claims all of it. Nothing in a green run distinguishes the two, and the docstring is what a later reader trusts.
</principle>

<principle name="bounds">
Test the edges of accepted input — empty, zero, one, max, one-past-max, null, malformed — not only the happy value.
</principle>

<principle name="normal-and-abnormal-paths">
Every behaviour gets at least one test for success and one for the expected failure mode. A suite that only proves "it works when nothing goes wrong" is not a test suite.
</principle>

<principle name="independence">
No test depends on state left behind by another. Any test runs in isolation and in any order.
</principle>

<principle name="name-as-sentence">
Test names read as a sentence describing what should happen and when — "returns user when valid ID provided", "raises ValueError when email is malformed". The runner's failure output tells a reader what broke without opening the file.
</principle>
