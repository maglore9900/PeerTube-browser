<pruning>
Every line of a document is paid for on every turn that loads it. Three tests, applied line by line.

**No-ops.** Information the reader already has says nothing. If the content stands without the sentence, comment or aside, delete it.

**Duplication.** Information already in the target is said once.

**Relevance.** Does the line still bear on what the document does? A line loses relevance by never bearing on the task — mere exposition, or a branch that belongs in another file. Without this discipline a document's default fate is sediment.
</pruning>

<phrasing>
**Prompt the positive.** State the target behaviour, so the unwanted one is never spoken. Steering by prohibition drags the forbidden behaviour into context and makes it more available: the negation is a weak modifier that the strongly-activated concept overruns, and the ban half-reads as an instruction to do the thing. Where a hard guardrail genuinely cannot be phrased positively, pair it with the positive target so attention lands on what to do.

**Clarity.** The reader can tell what is being said. Jargon and nebulous riddles take away from the content rather than add to it.
</phrasing>

<structure>
**The ladder.** Material sits at one of three tiers, ranked by how immediately the reader needs it: the in-file step (what the reader does, in order), the in-file reference (consulted on demand), and the disclosed reference (pushed into another file behind a pointer, loaded only when that pointer fires). Push too little down and the top bloats; push too much and material the reader needs is hidden. Branching is the cleanest test: inline what every branch needs, disclose what only some branches reach. Where a document has steps, in-file reference that should have been disclosed buries them.

**Co-location.** Where the ladder decides how far down a piece sits, co-location decides what sits beside it. A concept's definition, its rules and its caveats go under one heading, so reading one part brings its neighbours with it. Scattering fragments one meaning across many places — a different fault from duplication, which repeats one meaning in two.

**Sprawl.** A document can be too long while every line in it is live and unique. Attention thins across the excess, and every extra line is one more to keep relevant. The cure is the ladder rather than tighter sentences: disclose the reference, and split by branch or sequence so each path carries only what it needs.

**A heading's wording decides whether it is read**, not its target. A weakly named heading is material the reader will not reach. State what the material is, and name the distinct cases that should send the reader to it — one trigger per case, with no synonyms renaming a single case twice.
</structure>
