<ladder>
**Understand before you cut.** Read every file the change touches and trace the real flow end to end, and only then pick a rung. The ladder shortens the solution, never the reading. A small diff bought by skipping comprehension is a confident wrong fix.

Then climb, and stop at the first rung that holds.

1. **Does this need to exist at all?** Speculative need: skip it, and say so in one line.
2. **Already in this codebase?** A helper, util, type or pattern that already lives here is reused. Look before you write — re-implementing what sits a few files over is the most common slop.
3. **Stdlib does it?** Use it.
4. **A native platform feature covers it?** A DB constraint over app code, CSS over JS.
5. **An already-installed dependency solves it?** Use it. A new dependency is never added for what a few lines do.
6. **Can it be one line?** One line.
7. **Only then:** the minimum code that works.

The ladder is a reflex, not a research project. Two rungs work: take the higher one and move on.
</ladder>

<rules>
- Write the concrete thing. An interface arrives with its second implementation, a factory with its second product, a config key with its second value.
- Fewest files. The shortest working diff wins, and deletion beats addition.
- Boring beats clever, because clever is what someone decodes at 3am.
- Scaffolding waits for the code that needs it; later can scaffold for itself.
- A bug fix goes to the root cause. Before editing, find every caller of the function you are about to touch: one guard in the shared function is a smaller diff than a guard in every caller, and fixing only the path the report names leaves every sibling caller broken.
- Two options of the same size? Take the one that is correct on edge cases. The discipline is less code, not a flimsier algorithm.
- Mark a deliberate simplification with a `rat-tail:` comment, so simple reads as intent. Where the shortcut has a known ceiling — a global lock, an O(n²) scan, a naive heuristic — the comment names the ceiling and the upgrade path: `# rat-tail: global lock, per-account locks if throughput matters`.
- Outside a build, non-trivial logic (a branch, a loop, a parser, a money or security path) leaves one runnable check behind: an `assert`-based `__main__` self-check or one small `test_*.py`. Inside a build the phase checkpoint is that check, held to `testing.md`.
</rules>

<keep_in_full>
Five things are written at full size whatever the ladder says: input validation at trust boundaries, error handling that prevents data loss, security measures, accessibility basics, and anything explicitly requested. Where the operator insists on the full version, build it rather than re-arguing.

Every paragraph defending a simplification is complexity smuggled back in as prose. Where the explanation runs longer than the code, the code was not simple. Explanation that was asked for — a report, a walkthrough, per-phase notes — is given in full.
</keep_in_full>

<nothing_hollow>
Gated code is real code. A passing test does not make a shell an implementation.

- **No hollow implementation.** A function returning a value shaped to pass one specific test is not general. Triangulate: a second example forces the general form, and a function that does not yet take it is not done.
- **No stub return.** `return None`, `return []`, `return {}` or a bare `pass` as a body is a placeholder. The function has real logic producing the value, or it does not exist yet.
- **No swallowed error.** `except: pass`, `except Exception: return None` and their equivalents hide failure modes the checkpoint cannot see. An error is logged, re-raised, or converted to a documented result.
- **No TODO in checkpoint-gated code.** A phase closing with a TODO inside the code its checkpoint proves means the checkpoint tests the wrong thing or the phase is not done. Fix one.
</nothing_hollow>

<step_sizing>
- **Obvious implementation** — write the real thing. The default.
- **Fake it** — return a constant to reach green only when the shape is genuinely unknown, and generalize before the phase's checkpoint is accepted.
- **Triangulate** — when one example does not force the general form, require a second before generalizing.

On an unexpected red, shrink the step and run the tests more often. A red you did not predict means your model of the code is wrong, and a bigger step compounds that.
</step_sizing>
