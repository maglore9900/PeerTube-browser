<ladder>
Pick the highest rung the invariant supports. Higher rungs test behaviour directly and fail pointing at the broken code; lower rungs test artifacts and fail for many possible reasons.

**Rung 1 — Direct behaviour invocation.**
Call the function, method or class directly; assert on returned values or observable side effects.

```python
assert independence.origin_of({"platform_id": "linkedin",
                               "request": {"url": "https://linkedin.com/in/x"}}) == "platform:linkedin"
```

Use when the code under test is functional or cheap to fixture, and you want the failure to point at the exact function whose behaviour regressed.

---

**Rung 2 — CLI subprocess.**
Invoke the tool as a subprocess with real args; assert on stdout, stderr and exit code.

```python
result = subprocess.run([sys.executable, "-m", "pytest", "--collect-only", "tests/"],
                        capture_output=True, text=True)
assert result.returncode == 0
```

Use when the code IS a CLI or has a subprocess boundary, and the invocation shape agents and operators use is what matters.

---

**Rung 3 — Filesystem or config side effects.**
Assert on files written, JSON parsed, database rows created, log entries emitted.

```python
assert (VAULT_ROOT / "reports" / "X.md").exists()
data = json.loads((VAULT_ROOT / "reports" / "X.manifest.json").read_text())
assert data["target_id"] == "X"
```

Use when the code's real output is a side effect on disk or state, and the artifact's shape is the invariant.

---

**Rung 4 — Structured content parse and membership.**
Parse a YAML, JSON or frontmatter block; assert on typed values, not raw text.

```python
fm = yaml.safe_load(agent_md.split("---", 2)[1])
assert "WebFetch" not in fm["tools"]
```

Use when the spec being verified is a structured document consumed by code: agent frontmatter, a config file, a JSON schema.

---

**Rung 5 — Substring in a structured section (last resort).**
Extract a bounded section; assert a token appears within it.

```python
section = extract_section(doc, "<contract>", "</contract>")
assert "field_name" in section
```

Use when nothing at rungs 1-4 fits AND the invariant genuinely is "this word must appear here". If it is really writer word-choice, delete the test — see `section-scoped-substring-grep` below.

---

**Anti-rung (never used): substring in prose.**
`assert "some_word" in whole_file.read_text()` against a prose file is `doc-lint-grep` below. A prose change is verified by `workflows/dev_flow.md <prose_verification>`, never by a test.
</ladder>

<matching_rule>
Match the invariant to the rung; don't force a higher rung than the invariant supports. A behavioural invariant tested at rung 4 asserts on the config shape when what matters is the behaviour the config drives. A structural invariant tested at rung 1 needs synthetic fixtures that hide what actually breaks in production.

The right rung is the one where the assertion reads most naturally AND its failure message sends the maintainer to the right file first.
</matching_rule>

<downshift_rule>
When higher rungs are impractical for THIS invariant (no direct entry point, no CLI, no structured artifact), downshift, and leave a comment on the test naming the reason:
```python
# rung 5: no structured contract for this section yet, revisit if X gets schematized
```

When the reason is resolved (a schema is added, a CLI wraps the function), the test moves up to the higher rung and the comment goes.
</downshift_rule>

<anti_pattern name="doc-lint-grep">
<summary>Assert a substring appears in a markdown file.</summary>

<example_bad>
```python
assert "submit_finding.py" in (ROOT / ".claude/agents/osint-collector.md").read_text()
```
</example_bad>

<why_bad>

- Tests whether a writer used a specific word — not whether code behaves correctly.
- Silently rots: docs mentioning a field long after that field is renamed still pass. Docs updated to a new term without touching the test still fail with no code cause.
- Breaks on documentation restructuring / renaming that leaves code untouched.
- The failure mode is asymmetric: false-negatives (real regression missed because the token still appears) AND false-positives (working code broken by test on doc reword) both happen.
</why_bad>

<how_to_spot>

- Test reads a `.md` file via `path.read_text()` then asserts substring presence.
- No structured parse (YAML frontmatter parse, section extraction, JSON schema validation) between read and assertion.
- The "correct behavior" being verified is a writer's word choice, not a code path.
- The test asserts on a `.md` file whose primary reader is a human, not a machine.
</how_to_spot>

<alternatives>

- If the doc drives config: parse it as YAML/JSON; assert on structured values.
- If the doc drives a subagent's behavior: the subagent's behavior IS what to test, via subprocess or agent-invocation.
- If nothing behavioral hinges on the specific word: no test at all. Text an agent acts on is verified by `workflows/dev_flow.md <prose_verification>`; documentation is not verified.
</alternatives>
</anti_pattern>

<anti_pattern name="hardcoded-spec-mirror">
<summary>Assert a code constant equals a hardcoded literal spec inline in the test.</summary>

<example_bad>
```python
assert set(mod.RECORD_VALUES) == {
    "court", "property", "campaign-finance", "record:username-lookup", ...
}
```
</example_bad>

<why_bad>

- Any spec update requires touching the test AND the code in lockstep — two files move together forever.
- Test drift: someone updates the code, forgets the test, and it fails on unrelated changes. Attribution is confusing.
- Says nothing about the constant's ROLE in the system — just that it matches the writer's expectation at test-authoring time.
- The test is essentially a copy of the code with `assert` prepended. If the copy diverges from the original, it's the copy that's wrong 99% of the time — but the failure output implies it might be the code.
</why_bad>

<how_to_spot>

- Test asserts equality between a code constant (set, list, dict, enum) and a hardcoded literal.
- Expected values are inline literals in the test file, not derived from another source.
- The test name is something like `test_X_matches_schema` or `test_X_has_expected_values`.
- When the code constant changes, the test file MUST change to keep tests green.
</how_to_spot>

<alternatives>

- Test the constant's USE: assert callers behave correctly given a value from it. "When RECORD_VALUES contains 'court', the filter includes court records" is a behavior test.
- If the spec must not silently drop values, source-of-truth them ONCE (e.g., a JSON file) and read from that in both code + test. Then the test verifies the loading, not the values themselves.
- If the spec is fundamentally arbitrary (a taxonomy that just IS a set of strings), consider whether the test is asking the right question at all. Sometimes the answer is "no test needed — the code IS the spec."
</alternatives>
</anti_pattern>

<anti_pattern name="section-scoped-substring-grep">
<summary>Extract a section from a doc then grep it for tokens.</summary>

<example_bad>
```python
ic = _extract_section(REPLAY_VERIFIER, "<input_contract>", "</input_contract>")
for token in ("scoped_scratchpad_dir", "request_ids_under_review", "claim"):
    assert token in ic
```
</example_bad>

<why_bad>

- Narrower than a whole-file grep, but same failure mode: passes if writer used the words; doesn't verify code actually sends/receives those fields.
- Feels structural because of the section extraction — but the section extraction is a red herring. The assertion is still substring-in-string.
- Common failure: a doc's section gets renamed or reworded during a legitimate documentation refresh; test fails; test gets "fixed" by adding more tokens to the accept-list; test loses whatever narrow signal it had.
</why_bad>

<how_to_spot>

- Test extracts a section (XML block, markdown heading range, YAML frontmatter) then loops asserting tokens are IN the section text.
- No parse of the section as structured content — the extraction just narrows the substring search.
- Test name mentions a section or contract by name; assertion body iterates tokens.
</how_to_spot>

<alternatives>

- If the section IS structured (YAML frontmatter, JSON schema): parse it and assert on typed values.
- If the section defines a contract used by code: test the contract end-to-end (call the code, verify behavior).
- If the section is documentation for a human reader: don't test it. Text an agent acts on is verified by `workflows/dev_flow.md <prose_verification>`.
</alternatives>
</anti_pattern>

<anti_pattern name="whole-file-source-name-grep">
<summary>Assert a CLI, script, or library name appears somewhere in a doc.</summary>

<example_bad>
```python
assert "submit_finding.py" in (ROOT / ".claude/agents/osint-collector.md").read_text()
```
</example_bad>

<why_bad>

- Renames of `submit_finding.py` break the test with no code cause.
- Says nothing about whether the agent actually USES `submit_finding.py`. The word appearing in the doc is orthogonal to any runtime behavior.
- Ties the test to a specific word in prose rather than to a behavior. Prose evolves; behavior is what needs protecting.
</why_bad>

<how_to_spot>

- Test asserts a specific filename / CLI name / library name / import path appears somewhere in a `.md` file.
- No verification that anything USES the named artifact at runtime.
- The test's justification is often "make sure the docs stay in sync with the code" — but the sync it enforces is word-level, not semantic.
</how_to_spot>

<alternatives>

- Test that the agent invokes the CLI: subprocess-invoke it or check settings.local.json's allow rules parse correctly and reference the expected script.
- If the goal is discoverability (a reader can find the CLI via the doc), that's a doc concern, not a test concern. Use intent-based verification when the doc changes.
</alternatives>
</anti_pattern>

<anti_pattern name="tautological-assertion">
<summary>Derive the expected value the way the code derives it, so the test passes by construction.</summary>

<example_bad>
```python
def test_total_sums_the_line_items():
    items = [{"price": 10}, {"price": 5}]
    expected = sum(i["price"] for i in items)   # the implementation, retyped
    assert total(items) == expected
```
</example_bad>

<why_bad>

- It cannot disagree with the code. Both sides compute the same thing, so the assertion holds for a correct implementation and for a wrong one that is wrong in the same way.
- It reads as coverage and is measured as coverage, which is worse than no test: the line is exercised, the behavior is unverified, and the gap is invisible in a report.
- The subtle form is worse than the obvious one — a helper shared between test and implementation, a fixture built by calling the code under test, a snapshot regenerated from current output whenever it fails.
- A test asserting `variants(kind) == {k.split(":")[1]: v for k, v in REGISTRY.items() if ...}` is this shape even though nothing is literally copied: it re-derives rather than states.
</why_bad>

<how_to_spot>

- The expected value is computed in the test body rather than written down.
- The test imports, or reimplements, the function it is testing to build its expectation.
- A snapshot is refreshed by running the code whenever the snapshot fails.
- Ask: if the implementation were wrong, where would the wrongness show? If the answer is "both sides would move together", it is this.
</how_to_spot>

<alternatives>

- State the expected value as an independent literal: `assert total([{"price": 10}, {"price": 5}]) == 15`.
- Take it from an independent source of truth — a worked example, the spec, a known-good fixture recorded deliberately rather than regenerated.
- When the value genuinely cannot be written down (it is large or generated), assert PROPERTIES that an independent reader can state: length, ordering, membership, an invariant relating input to output.
</alternatives>
</anti_pattern>

<anti_pattern name="absence-only-assertion">
<summary>Assert only that something did not happen, when the code under test being absent produces the same result.</summary>

<example_bad>
```python
def test_a_recall_of_a_name_that_names_no_memory_records_nothing(tmp_path):
    fire("ToolEnd", name="Recall", args={"name": "no-such-memory"})
    assert _records(tmp_path) == {}, "a read of a memory that does not exist was recorded"
```
</example_bad>

<why_bad>

- The assertion holds for "the listener correctly declined", for "the listener recorded nothing for anything", and for "no listener exists". It cannot separate them, so it is green before the phase is written and stays green against any wrong implementation that never runs.
- It is the shape most likely to survive the whole build unnoticed, because a negative assertion reads as rigorous and its passing costs nothing.
- The same defect wearing other clothes: `assert not path.exists()`, `assert "enable" not in log`, `assert result == []`, `with pytest.raises(Exception)` where the stub's own `NotImplementedError` satisfies it.
</why_bad>

<how_to_spot>

- Every assertion in the test is negative — a `not in`, a `not ... exists()`, an empty collection, a bare `pytest.raises(Exception)`.
- Ask: delete the code under test entirely. Does the test still pass? If yes, it is this.
- The test's evidence that the path ran at all comes from OTHER tests in the file rather than from itself.
- An exception assertion names a base class broad enough to catch the stub body the phase will land.
</how_to_spot>

<alternatives>

- Pair the negative with a positive control in the same test: a second input that MUST produce the record, asserted before the absence claim, so the absence means "declined" rather than "never ran".
- Assert the exception's specific type and pin it to its cause — the status, the message, the field that produced it — never the base class.
- When the claim genuinely is "nothing happened", assert what DID happen instead: the call returned, the other branch fired, the file kept its previous bytes.
</alternatives>
</anti_pattern>

<anti_pattern name="echoed-literal">
<summary>Feed a value into the test and assert the same value comes back, with no production code between the two.</summary>

<example_bad>
```python
assert "c-b" in NO_RECORD.format(key="c-b")
assert "Ctrl-T" not in NO_RECORD.format(key="c-b")
```
</example_bad>

<why_bad>

- The test performs the substitution the production code is supposed to perform, so the assertion is a property of `str.format` and the test's own input. No path through the code under test is reached.
- The wiring this exists to gate — the call site that decides WHICH key is formatted in — can be absent or wrong and the test stays green while the operator sees the literal `{key}` on screen.
- Distinct from `tautological-assertion`: nothing is computed and nothing is re-derived. The expected value simply IS the input value, handed back.
- Its other form is a config test that writes one value and asserts that value at the far end, with no assertion that the far end read the file rather than moving its own default.
</why_bad>

<how_to_spot>

- The expected string or value appears earlier in the same test as an input.
- The test calls the transformation itself — `.format()`, the constructor, the parser, the encoder — rather than a symbol from the code under test.
- Nothing between the input and the assertion belongs to the module being gated.
- Ask: which production line, if deleted, turns this red? If the answer is "none", it is this.
</how_to_spot>

<alternatives>

- Drive the production call site that performs the substitution, and read the result off what it emitted — the rendered row, the returned object, the written file.
- Choose an expected value that differs from every default the code already ships, so a build that ignored the input fails.
- Where only the constant's text is in question and no wiring is, assert the constant's USE per `hardcoded-spec-mirror <alternatives>` rather than its shape.
</alternatives>
</anti_pattern>

<anti_pattern name="single-value-pin">
<summary>Read the observable at one input only, so no assertion separates the mechanism from a default that moved.</summary>

<example_bad>
```python
_project(tmp_path, '[keys]\nexpand = "c-e"\n')
main(["chat"])
assert _handler(table, Keys.ControlE) is _expand
```
</example_bad>

<why_bad>

- One input in, one input out, and both are literals in the test file. Nothing asserts the second follows from the first. An implementation that hard-codes the new value, or moves the shipped default to it, passes.
- The same collapse appears as two observables that always agree: both sides are produced by one source, so a wrong implementation moves both and the equality holds. "Any number they agree on is correct" is the recorded reason a test cannot disagree with the code.
- It is the standard defect in tests for anything configurable, derived, or width-computing, where the point is that the OUTPUT TRACKS THE INPUT.
</why_bad>

<how_to_spot>

- The test exercises the feature at exactly one value, and that value is the only one in the file.
- An equality between two readings, where a single shared source produces both — the fourth question in `tautological-assertion <how_to_spot>` answers "both sides would move together".
- A fixture whose two relevant values coincide, so the assertion cannot tell `max(a, b)` from `a`.
- The expected result equals the shipped default, so returning the default unchanged passes.
- The input is already in the function's canonical form, so the function is identity on it and the assertion cannot tell the real helper from `lambda x: x`. A normalise-on-the-way-in, spell-back-out-for-display pair is where this lands: production canonicalises before storage, so a fixture built from stored state already holds the value the assertion expects.
- Overlapping with `tautological-assertion`, which asks the same question in its fourth bullet: a test that re-derives its expected value the way the code does is `tautological-assertion` however many inputs it runs; a test whose expectation is independent but which runs one input is this. A test doing both is named here, since adding the second input is what fixes it.
</how_to_spot>

<alternatives>

- Run the observable twice, at two inputs that must produce different readings, and assert the DELTA: the skinned render against the unskinned one, the configured key against the shipped one.
- Where one run is genuinely all that is available, pin the reading to a value only the correct derivation produces, not to one any shared width or any default also satisfies.
- Choose the second input so the two candidate implementations disagree on it — an asymmetric fixture where `max(a, b) != a`, a config value no default already carries.
- Where the function normalises what it is given, take the input from what a user or a config file would actually contain (`c-b`, `C-B`, `Ctrl+B`) rather than from what the assertion expects back. One input is enough in that case, provided it is not a fixed point.
</alternatives>
</anti_pattern>
