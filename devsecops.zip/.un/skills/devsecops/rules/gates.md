<the_grain>
**One grain: the phase.** A phase is one vertical slice: checkpoint red, implement, checkpoint green. A second, finer per-behaviour cycle underneath it slows integration without adding safety, because the checkpoint already asserts the behaviour the inner test would restate. Work one slice at a time; writing every test first and every implementation after tests imagined behaviour rather than what the last slice taught you.

An inner unit test is written **by exception** — when the phase's checkpoint cannot express the behaviour — and the plan records why.

- Earns a test: "dict equality cannot see ordering, and `/help` renders straight from this order." The checkpoint asserts the mapping; no mapping assertion can fail on order.
- Does not: an assertion the checkpoint already makes, restated one layer down.

**A phase with no inner unit tests is the normal case.** The few tests that exist are audited for being real rather than trusted because there are many of them.
</the_grain>

<red_for_the_right_reason>
Every gating test is watched failing before the code satisfying it exists, and the failure is ARTICULATED: what failed, and why that is the absence of the feature rather than a broken harness. A failed control assertion is always a broken harness: the test never reached the assertions that judge the code.

A red reading `ImportError`, `AttributeError` or `TypeError` on a symbol the phase itself creates is a WEAK red — it proves the symbol is missing, not that the assertion would catch the behaviour being wrong. Two ways out:

- Land the phase's signature alone first, so the red is absent behaviour. Prefer `raise NotImplementedError` over a stub return, which may return exactly what a correct implementation returns in some case.
- Shape the assertion so it fails on behaviour even against a bare stub.

A test GREEN before the phase is built gates nothing: find what it asserts that is already true, and assert the phase's own claim instead.

A prose phase has no test to fail. Its counterpart is read before any phase is built: at least one of the prose phases' clauses is false of the tree as it stands, and a clause already true records why it stays.
</red_for_the_right_reason>

<audit>
A test is a gate only if it would fail when the thing it guards breaks, and nothing in a green run says whether that is true. So every checkpoint is read by two auditors before it counts as a gate, in this order: authored, self-checked, **seen red for the right reason**, then audited, then implemented. The auditors read; they do not run. A test red on a typo or an unarmable fixture would be cleared on its merits, so the red comes first.

- `devsecops-test-shape-auditor` holds `shape.md`, and alone emits the predicted failure mode.
- `devsecops-test-claim-auditor` holds `testing.md`, and emits the CLAUSE MAP: one row per clause of the test's name, docstring and `must_prove`, each against the assertion carrying it, the wrong implementation that assertion excludes, and `CARRIED`, `UNCARRIED` or `EXEMPT`.

Both are dispatched concurrently with the same fields — `test_path`, `surface`, `must_prove` quoted from the plan, `code_under_test`, `fixtures_path` — and nothing else: not the plan, not the author's reasoning. A verdict anchored on the author's justification is the author's verdict under a second name. The gate needs both verdicts; one that fails to return is re-dispatched, and the other's PASS does not stand for the pair.

Inner unit tests are not audited. They are reviewed inline at the Step 8 refactor pass.

Coupling is no auditor's criterion: it is the author's call at the self-check (`testing.md <coupling>`).
</audit>

<the_loop>
The gate is a LEDGER loop, not a count of blocks.

1. **Round one's CLAUSE MAP is frozen** as the work list. `EXEMPT` is only for a `must_prove` clause the operator exempted, and is never a Critical.
2. **Every `UNCARRIED` row is an item**, fixed or justified on the record. A docstring or name row is usually justified by narrowing the sentence to what is asserted. A `must_prove` clause is never justified away; the operator exempting it is the only way it leaves the list.
3. **The claim re-audit is bounded to the frozen ledger.** A claim finding outside it is an OBSERVATION and does not block.
4. **The shape auditor is never frozen.** A claim remediation can introduce a shape defect, and a frozen shape auditor is blind to it.
5. **The gate clears on both PASS with no Critical and no `UNCARRIED` row.** A recommendation never blocks and never spends a round; it stays in the record.
6. **Three rounds unattended, then the operator, one round at a time:** accept as it stands, buy one more remediation and bounded re-audit, or stop. Both PASS with every `must_prove` row carried and only docstring or name rows open closes without asking, and the record says what was left open.
7. **Accepting is not available before an auditor has read the test.** It overrides findings, and at zero audit rounds there are none.

**Send-backs that never reach an auditor** — a test that does not collect, a self-check table missing a clause, a test green before the work — carry their own budget: one automatic retry, then the operator. A refused self-check table is waivable, and waiving sends the test ON to the auditors, who re-derive the table from the file. A test that does not collect, or is green before the work, is a fact about the file and cannot be waived.

**A fix answering a recorded audit finding before the test has gated is covered by that record.** Changing a test after it has gated needs recorded operator approval.
</the_loop>

<outcome_format>
Recorded under the phase, shape auditor first:

- `AUDIT: <auditor> — PASS. Predicted failure: <how the auditor expects it to fail>.`
- `AUDIT: <auditor> — BLOCK: <finding>. Fixed: <what changed in the test>. Re-audit: PASS.`
- `AUDIT: <auditor> — BLOCK: <finding>. Overruled by user: <their reason>.`
</outcome_format>

<clause_accounting>
There is no outer acceptance test. The build's acceptance criteria are cut at Step 6 into each phase's Intent and its one or two clauses; every clause belongs to exactly one phase, and that phase's checkpoint `must_prove` IS its clauses. A clause no phase can prove is cut or moved at Step 6, where it is cheap.

At the close, a mechanical check resolves every clause as exactly one of: **carried** or **exempt** in the last clean audit of its checkpoint, **prose-verified** by its phase, or **operator override** where the operator closed that gate over open findings. A clause resolved by none stops the build, named.

Beware assertions a build's own duplication would satisfy. Two copies of the same literal compare equal, which proves nothing about the value being written once. Move the source and assert every consumer followed.
</clause_accounting>

<done>
Done means every clause is resolved AND the full suite is green against the recorded pre-build baseline. A phase whose checkpoint passes while the suite is red is a fragment that satisfies its own assertion, not a finished phase. A build inheriting failures substitutes the criterion explicitly, with user approval (`dev_flow.md <baseline_variant>`).
</done>

<invariants>
- No production code exists without a checkpoint that was watched failing first.
- A test that gates something has been audited before it counts as a gate.
- Refactoring happens at Step 8 on a green suite, never inside a phase; a refactor that reddens the bar is reverted.
- No new behaviour during a refactor. New behaviour needs a fresh red.
</invariants>
