# devsecops

A test-first build flow with human-in-the-loop gates, packaged as an un skill. It captures requirements, plan and impact inventory to one working file,
implements in phases with an audited checkpoint test per phase, and closes by
harvesting the tests worth keeping into the durable suite.

**This file is for the person installing it.** The skill's own normative
contract — what every gate requires and why — lives in `SKILL.md`; the agent
reads that, not this. Where the two overlap, `SKILL.md` wins.

---

## What you get

| | |
|---|---|
| `/devsecops [what to build]` | one build, end to end, under the flow |
| `/harvest [files]` | move earned tests into the durable suite, clear the rest |
| 2 test auditor subagents | second reader on every gating test; prose changes go to the `meta` doc-type auditors |
| `scripts/validate_tests.py` | the pytest wrapper the flow runs everything through |

`validate_tests.py` is useful on its own even if you never run the flow: it
digests each test file plus the project files it depends on, re-runs only the
groups whose digest moved, and banks a per-group record so a later session can
skip what still holds.

## Requirements

- **Python 3.9+** (`Path.is_relative_to`). Developed and run against 3.11–3.14.
- **pytest**, with the JUnit XML reporter (bundled — no plugin needed).
- **pixi**, optional. If a `pixi.toml` or `pixienv/pixi.toml` is present *and*
  `pixi` is on `PATH`, runs go through `pixi run`; otherwise through the
  interpreter running the script. Nothing to configure either way.

No other dependencies. The script is stdlib-only and single-file.

## Install

```bash
# 1. copy the skill in. agents/ and commands/ ride along; config.json does NOT —
#    it is per-project state and describes the repo it came from.
cp -r <source>/.un/skills/devsecops <target>/.un/skills/
rm -f <target>/.un/skills/devsecops/config.json

# 2. seed the config
cd <target>
cp .un/skills/devsecops/config.example.json .un/skills/devsecops/config.json

# 3. hand it to the agent
#    /devsecops   — or, to see what it will ask first:
.un/skills/devsecops/scripts/validate_tests.py --show-config
```

Step 3 is the whole install. The seeded config reports `version: null`, which
opens the **bootstrap gate** in `SKILL.md`: it asks about each path once, writes
your answers back, and installs the agents and commands. A project that has
already been through it is never asked again.

### What the bootstrap writes outside this directory

Two things, both to paths you confirm first, and neither silently:

- `agents/*.md` → the configured `agents` path (default `.un/agents/`)
- `commands/*.md` → the configured `commands` path (default `.un/commands/`)

They are **copied, not symlinked, and never overwritten.** un does not discover
subagents or slash commands from inside a skill directory, so a skill
that only carried them would ship auditors nothing can invoke. If a file is
already there and differs from the vendored copy, the gate shows you the
difference and asks — a project that renamed an auditor or tightened its tool
list made a decision, and a bootstrap that reverts it breaks the flow at the
next audit.

### Host-project settings the flow assumes

Two entries in `pyproject.toml` (or your pytest config). Neither is created for
you:

```toml
[tool.pytest.ini_options]
# validate_tests.py splits runs into tiers with `-m`; unregistered, every run warns.
markers = ["integration: exercises a real boundary (subprocess, filesystem, network)"]

# `archive` holds tests a harvest retired — kept readable, never run. Left in the
# collection path they also collide on module basename with the active file they
# were cut from, which is a collection ERROR rather than a skip.
norecursedirs = ["archive", "*.egg", ".*", "_darcs", "build", "CVS", "dist",
                 "node_modules", "venv", "{arch}"]
```

The rest of `norecursedirs` is pytest's own default, which naming the key would
otherwise drop.

## Configuration

`config.json` sits beside `SKILL.md` and binds the skill to one project.
`DEVSECOPS_CONFIG` overrides its location, and setting it is an assertion: if it
names a file that is absent, or one that cannot be read as a JSON object, the
script exits non-zero naming that file instead of falling back to the defaults.
With the variable unset and no `config.json`, the defaults still answer.
`--show-config` prints everything resolved.

| key | default | what it is |
|---|---|---|
| `active` | `tests/active` | the durable suite. The only tree the group model describes |
| `working` | `tests/tmp` | what a build writes while it runs. **Must not be inside `active`** |
| `plans` | `docs/plans` | where the build's working file and harvest record are filed |
| `delete_me` | `delete_me` | disposal. Workflows move files here and tell you; nothing is removed |
| `archive` | `tests/archive` | where a harvest retires a durable test it replaced |
| `agents` | `.un/agents` | install target for the vendored auditors |
| `commands` | `.un/commands` | install target for the vendored slash commands |
| `project_dir` | `.` | absolute project root, substituted into printed commands |
| `test_groups` | `{}` | per-test-file dependency map. Hand-authored |
| `version` | `null` | the skill generation this config was reconciled against. Written, never asked |

`--show-config` also reports four derived fields: `skill_dir`, `skill_version`,
`record` (where runs bank), and `defaulted` (keys you have not set, so their
value is still a guess). Plus `conflicts` and `map_health` — see below.

`config.json` is **project state.** Do not carry an installed project's copy to
the next project: its `test_groups` describes a source tree that is not there
and its `project_dir` points at another machine. Copy `config.example.json`.

### `test_groups`

Says what each test file **depends on** — never what it is. Groups themselves
are discovered from the filesystem, so a new test file is a group the moment it
exists.

```json
"test_groups": {
  "test_shell.py": ["src/un/core.py", "src/un/plugins/shell.py"]
}
```

Starting at `{}` is safe, not broken: every group is then unmapped, and an
unmapped group **always runs**. That is the correct state for a project nobody
has mapped yet. Narrow it later:

```bash
validate_tests.py --suggest-map   # derives a fragment from what each test NAMES
validate_tests.py --audit-map     # checks the map; must exit 0
```

`--suggest-map` never writes the config — an entry asserts that a test exercises
a file, which is a judgement. Prune what it prints.

**An entry that under-lists costs a silent skip:** the group digests to less
than it depends on, so it is deselected while that code changes underneath it
and the record still reports green. `map_health` cannot see that — it compares
the map to the filesystem, never to what the tests reference. When a test starts
driving a new module, add it.

### Test tree layout

```
tests/
├── conftest.py                  ← shared; deliberately claimed by no group
├── last_test_validation.json    ← the banked record, at the tree ROOT
├── active/                      ← the durable suite, one file per production module
├── tmp/                         ← what a build writes while it runs
└── archive/                     ← what a harvest retired; readable, never run
```

`active` and `working` must be **siblings**. `groups()` discovers by rglob over
`active`, so a nested `working` turns every scratch checkpoint into a durable
group — and the build's own mid-phase runs then bank as though they described
the whole suite. `--show-config`'s `conflicts` names this in a sentence, and the
bootstrap gate will not close while it is non-empty.

## Daily use

```bash
validate_tests.py                      # fast tier, only the groups that moved
validate_tests.py                      # every tier (the default)
validate_tests.py --compare            # only what moved against the last record
validate_tests.py --failures-by-cause  # 242 failures collapsed to one line per cause
```

Every run banks, per group, with no flag to opt in. Only groups that produced
results are written, so a filtered run records what it exercised and leaves the
rest alone. Extra arguments pass through to pytest untouched.

It bounds the run and slices its own output — **do not wrap it in `timeout` or
`tail`.** stdout carries a summary; the whole captured output goes to
`last_test_output.txt` beside the record, every run. Run it from the project root; it resolves
paths from the working directory.

`--help` lists everything; the module docstring carries the mechanics.

## Migrating from v3

v3's config was a different schema, not a shorter one:

```json
{ "test_path": "tests", "fingerprint_roots": ["tests", "src"] }
```

Neither key exists in v4. `test_path` split into `active` + `working`, and
`fingerprint_roots` — one whole-tree fingerprint — became per-group digests
driven by `test_groups`. Unknown keys are ignored, so a v3 file loads, reports
`version: null`, and the gate opens on every key.

Three things are specific enough to plan for:

1. **v3's flat `tests/` cannot become `active` unchanged.** The `working`
   default nests inside it and `conflicts` will say so. Move the durable suite
   down to `tests/active/` (leaving `conftest.py` at the `tests/` root), or point
   `working` outside `tests/`. This is the one step that touches files.
2. **Start `test_groups` at `{}`.** `fingerprint_roots` does not convert — one
   said "re-run everything when src moves", the other says what a single test
   file depends on. An empty map reproduces v3's behaviour exactly. Narrow it
   afterwards.
3. **Drop `test_path` and `fingerprint_roots`** when writing the new file. They
   are inert, and an inert key naming a retired concept reads as configuration
   that is doing something.

## Uninstall

Everything the skill wrote lives in three places: this directory, the configured
`agents` path, and the configured `commands` path. Remove the two auditor files
and the command files by name — nothing else outside this directory is
touched, and `pyproject.toml`'s markers entry is worth keeping either way.

## Layout

```
devsecops/
├── README.md              ← this file
├── SKILL.md               ← the contract: bootstrap gate, indexes, success criteria
├── config.json            ← per-project; not carried between projects
├── config.example.json    ← the seed
├── agents/                ← the 2 test auditors, installed by the bootstrap
├── commands/              ← the /devsecops:* commands, installed by the bootstrap
├── rules/                 ← code, testing, shape, gates, writing; read at point of use
├── scripts/
│   └── validate_tests.py  ← the test runner
├── workflows/
│   ├── dev_flow.md        ← one build, end to end
│   ├── harvest.md         ← working → active, after a build closes
│   └── plan_template.md   ← shape of the working file a build builds up
└── setup/, triage/, plan/, improve-codebase-architecture/   ← bundled skills
```
