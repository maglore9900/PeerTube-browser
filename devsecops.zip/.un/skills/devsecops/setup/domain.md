# Domain Docs

How the engineering skills should consume this repo's domain documentation when exploring the codebase.

## Read these before exploring

- **`CONTEXT.md`** at the repo root: the glossary. Every domain term the project uses is defined here.
- **`docs/project/adr/`**: one architecture decision per file. Read the ADRs touching the area you are about to work in.

Where one of these does not exist yet, proceed without it and do not stop to scaffold it. They get created when a term or a decision actually needs recording, not upfront.

## File structure

```
/
├── CONTEXT.md
└── docs/
    └── project/
        ├── adr/
        │   ├── 0001-enforcement-fails-closed.md
        │   └── 0002-structural-bash-matching.md
        ├── issues/
        │   └── archive/          ← completed issues
        ├── plans/
        │   └── archive/          ← completed plans
        ├── rejected/             ← declined plans, issues, etc
        ├── security-audit/             ← security-audit findings
        ├── domain.md
        ├── issue-tracker.md
        └── triage-labels.md
```

Issues do not live here. They are in the tracker `issue-tracker.md` describes.

## Use the glossary's vocabulary

When your output names a domain concept — an issue title, a refactor proposal, a hypothesis, a test name — use the term as `CONTEXT.md` defines it. Do not drift to synonyms the glossary avoids.

A concept missing from the glossary is a signal: either you are inventing language the project does not use, which is a reason to reconsider, or there is a real gap worth naming.

## Flag ADR conflicts

Where your output contradicts an existing ADR, surface it rather than silently overriding:

> _Contradicts ADR-0007 (event-sourced orders), but worth reopening because…_
