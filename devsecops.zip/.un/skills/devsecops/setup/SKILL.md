---
name: setup
description: "Configures this repo for the engineering skills: its issue tracker, triage label vocabulary, and domain doc layout. Run once before first use of the other engineering skills."
---

<objective>
Scaffold the per-repo configuration the engineering skills assume:

- **Issue tracker**: where issues live, and how a skill publishes one or fetches one
- **Triage labels**: the strings this repo uses for the five canonical triage roles
- **Domain docs**: where the glossary and the ADRs live, and the rules for reading them

This is a prompt-driven skill, not a deterministic script. Explore, present what you found, confirm with the user, then write.
</objective>

<quick_start>
Read whichever of `CLAUDE.md` / `AGENTS.md` exists and its `## Agent skills` block, then work `<explore>` → `<decide>` → `<confirm>` → `<write>` in order.

**Re-running is normal.** A repo that already has these docs is the usual case, not an error. Read what is there first and propose the difference; never write over an answer the repo already gives.
</quick_start>

<explore>
Establish what this repo already does before proposing anything:

- Read whichever of `CLAUDE.md` / `AGENTS.md` exists, and its `## Agent skills` block if it has one.
- Look for the three docs at the paths that block names, and at `docs/project/`.
- List `.scratch/` and `docs/`. An existing convention outranks every default below.
</explore>

<decide>
**Section A: Issue tracker.**

> The "issue tracker" is where issues live for this repo. Skills like `triage` read from it and write to it, so they need a location and a file shape.

**Work is markdown in this repo, split by kind.** An ISSUE — a bug, a defect, a small request — is one file at `docs/project/issues/<NN>-<slug>.md`. A FEATURE — a planned, phased build — is one file at `docs/project/plans/<NN>-<slug>.md`, in the shape of `.un/skills/devsecops/templates/plan_template.md`. `/devsecops:plan` writes that file with its Requirements and High-level plan once the user has agreed them, and a build starts from it. Triage state is a `Status:` line near the top; comments append to the bottom under `## Comments`.

What to confirm with the user is the two DIRECTORIES, and whether an existing convention already differs. The method is settled: there is no external tracker to query and no pull-request process to fit into.

**Section B: Triage label vocabulary.**

The six canonical roles, each label string equal to its name: `needs-triage`, `needs-info`, `ready-for-agent`, `ready-for-human`, `wontfix`, `complete`. Write them as-is unless the user asks for different strings — with the state living in the issue file itself, there is nothing to reconcile them against.

**Section C: Domain docs.**

Default to **single-context**: one `CONTEXT.md` at the repo root as the glossary, and one ADR per file under `docs/project/adr/`. Where either already exists somewhere else, take the existing location — the docs are the thing being described, not the thing being moved.
</decide>

<confirm>
Show the user a draft of:

- The `## Agent skills` block, against the file selected in `<write>`.
- The contents of `docs/project/issue-tracker.md`, `docs/project/triage-labels.md`, and `docs/project/domain.md`.

Where the repo already has any of these, show the DIFFERENCE rather than the whole file, so what the run would change is what the user reads. Let them edit before anything is written.

**All three docs are written on every run, and all three sub-blocks go into the block.** `triage` lives inside this skill's own directory rather than being installed separately, so its label vocabulary is never conditional — a block naming a file this run did not write is the one failure `<write>` checks for, and dropping the condition is what removes it.
</confirm>

<write>
**Pick the file to edit:**

- If `CLAUDE.md` exists, edit it.
- If `AGENTS.md` exists, edit it.
- If both exist, edit both and keep the block identical in each.
- If neither exists, ask the user which one to create; don't pick for them.

Never create `AGENTS.md` when `CLAUDE.md` already exists, or the reverse.

If an `## Agent skills` block already exists in the chosen file, update its contents in place rather than appending a duplicate. Don't overwrite user edits to the surrounding sections.

The block:

```markdown
## Agent skills

### Issue tracker

[one-line summary of where issues are tracked]. See `docs/project/issue-tracker.md`.

### Triage labels

[one-line summary of the label vocabulary]. See `docs/project/triage-labels.md`.

### Domain docs

[one-line summary of layout]. See `docs/project/domain.md`.
```

Then write the docs themselves, using the seed templates beside this file as a starting point:

- `issue-tracker.md`: local-markdown issue tracker
- `triage-labels.md`: the label vocabulary `triage` reads
- `domain.md`: domain doc consumer rules and layout

**Every path written into the block must resolve when the run ends.** Check each one before reporting done: a block naming a file this run did not write is the failure mode this step exists to avoid.
</write>

<success_criteria>
The run is done when:

- The `## Agent skills` block is written into the chosen file, with all three sub-blocks present.
- `docs/project/issue-tracker.md`, `docs/project/triage-labels.md` and `docs/project/domain.md` all exist.
- Every path named in the block resolves on disk, checked one at a time.
- The user has been told which engineering skills now read from these files, that they can edit `docs/project/*.md` directly later, and that re-running is only needed to switch trackers or start over.
</success_criteria>
