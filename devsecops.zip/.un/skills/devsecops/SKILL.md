---
name: devsecops
description: Structured, test-first, minimal-scope build flow with human-in-the-loop confirmation gates, held to a smallest-working-solution code standard and an audited-checkpoint testing standard. A phased procedure captures requirements, plan, impact inventory, and per-phase checkpoint outcomes to a single working file, and the bundled sub-skills cover repo setup, issue triage, planning, and architecture review. Use when the user wants a disciplined build with explicit approval at every stage change — not for one-off edits, exploratory hacking, or research questions.
---

<objective>
Deliver one build under the dev-flow discipline: gather + confirm requirements, agree on a high-level plan, draft the implementation, inventory every affected file/function/doc, reassess the plan against those impacts (loop until stable), agree each phase's checkpoint and its seam, implement in phases with an audited checkpoint test per phase, account mechanically for every clause, refactor on green, run the full suite to green, and update the identified documentation. Every stage change passes through explicit user approval; every phase carries a checkpoint that must pass before the next phase begins. This skill exists to prevent scope drift, silent test alteration, tests that cannot fail, and half-finished implementations — the failure modes that a fast, unstructured build produces.
</objective>

<when_to_use>
Invoke when any of these hold:
- The user asks for a build under the "dev_flow" , or runs `/devsecops:build`.
- The task is a multi-step build large enough to benefit from explicit requirements capture, phased implementation, and per-phase checkpoint tests.
- The user wants confirmation gates between requirements, plan, implementation, and test execution.

Not for one-off edits, small refactors, single-file fixes, exploratory questions, research, code review, or a user who has asked to move fast without gates.
</when_to_use>

<layout>
```
devsecops/
├── SKILL.md, README.md              README is for the human installing the skill; this file wins where they overlap
├── config.json, config.example.json  see <bootstrap>
├── agents/                           the two test auditors, installed by <install_step>
├── commands/                         the slash commands, installed by <install_step>
├── scripts/validate_tests.py         the test runner; its module docstring is its contract
├── rules/
│   ├── code.md                       the smallest working solution, and nothing hollow in gated code
│   ├── testing.md                    what a good test is, its seam, its surface, what it must assert — the claim auditor's criteria
│   ├── shape.md                      the rung a test sits at, and how an assertion rots — the shape auditor's criteria
│   ├── gates.md                      the grain, the red, the audit loop, clause accounting, done
│   └── writing.md                    how text an agent reads is pruned, phrased and structured
├── workflows/
│   ├── dev_flow.md                   the build, Steps 0-10, including prose verification
│   ├── harvest.md                    working → active once a build closes
├── setup/                            bundled skills — see <bundled_skills>
├── templates
│   ├── architecture_report.md
│   ├── issue-tracker.md
│   ├── plan_template.md              the shape of the WORKING_FILE
│   └── triage-labels.md
├── triage/
├── plan/
└── improve-codebase-architecture/
```

Each rules file is read at the step that names it in `dev_flow.md`, not up front.
</layout>

<bootstrap>
`config.json` binds the skill to the project it is installed in. `scripts/validate_tests.py --show-config` prints the resolved values; both workflows run it at their first step.

- **`active`**: the durable suite. A bare `validate_tests.py` run targets it, and it is the only tree the group model describes.
- **`working`**: where a build writes its checkpoints and inner tests. Outside `active` and unmapped; `workflows/harvest.md` moves what lasts into `active` after the build closes.
- **`plans`**: where a build's WORKING_FILE and a harvest's HARVEST_FILE are filed.
- **`delete_me`**: disposal. A workflow finished with a file moves it here and tells the user rather than removing it.
- **`archive`**: where a harvest retires a durable test that a harvested one replaces. It stays readable.
- **`project_dir`**: the absolute project root. `validate_tests.py` resolves paths from the working directory, so every workflow runs it from the project root.
- **`agents`** / **`commands`**: where `<install_step>` copies `agents/` and `commands/`.
- **`test_groups`**: what each test file in `active` depends on — a map from its path to the project files it exercises.

`--show-config` also reports **`record`**, where runs bank, and **`defaulted`**, every key the project has not set.

<bootstrap_gate>
Both workflows clear this at their first step, before anything else:

1. Run `scripts/validate_tests.py --show-config`. **If there is no `config.json`**, copy `config.example.json` to `config.json` first.
2. **The gate fires when `defaulted` lists a key other than `version` and `test_groups`.** Otherwise say nothing and proceed.
3. Present every defaulted key ONCE, in one round — the key, its current default, and its line above — and ask the user to confirm or replace each.
4. Write every confirmed value into `config.json`, defaults accepted unchanged included, so `defaulted` stops listing them.
5. Run `<install_step>`, then re-run `--show-config` and confirm `conflicts` is empty and `defaulted` holds nothing but `test_groups`.

A value naming a directory that does not exist is treated as unset for `active` and `working`; the others are created on first use. `conflicts` must be empty before the gate closes: the one it reports today is `working` nested inside `active`, which would turn every scratch checkpoint into a durable group. A workflow never proceeds on an unresolved config and never creates a directory the user has not confirmed.

<install_step>
un discovers subagents from `.un/agents/` and slash commands from `.un/commands/`, never from inside a skill, so the gate installs them. For each file in `agents/` and `commands/`, against the configured target:

- **Absent** → copy it, and list what was installed.
- **Byte-identical** → nothing.
- **Different** → do not overwrite. Show the user the difference and ask: keep theirs, take the skill's, or merge.

Report what happened either way. The copy is plain: the vendored commands name the skill, never a path.
</install_step>
</bootstrap_gate>

A group is one test file in `active`, digested over its own file plus the files `test_groups` assigns it. A bare run executes only the groups the banked record cannot answer for. Read `validate_tests.py`'s module docstring when a group did or did not run unexpectedly, when the map is being repaired, or when `DEVSECOPS_CONFIG` is set.
</bootstrap>

<intake>
1. Clear `<bootstrap_gate>`.
2. Read `workflows/dev_flow.md` and follow it end to end. It names the rules each step reads.

`/workflows:dev-flow` runs the same build as a workflow, with Python holding every gate.
</intake>

<bundled_skills>
Four skills travel inside this one. Each is reached by Read at its path — un registers a skill only one level below `.un/skills/` — and each has a slash command that does the reading.

- `setup/SKILL.md` (`/devsecops:setup`) — binds a repo to these skills: where issues live, the triage label strings, and where the glossary and ADRs are. Writes `docs/project/*.md` from the seeds beside it. Run once per repo.
- `triage/SKILL.md` (`/devsecops:triage`) — moves an issue through the triage roles and writes the agent brief an AFK agent builds from.
- `plan/SKILL.md` (`/devsecops:plan`) — explores an idea with the user until the requirements are confirmed and a high-level plan approved, then writes a feature file in the `templates/plan_template.md` shape for a build to start from.
- `improve-codebase-architecture/SKILL.md` (`/devsecops:improve-architecture`) — finds deepening opportunities and reports them. It proposes builds; it does not perform them.

They hand off one way: `setup` binds the repo, `triage` and `improve-codebase-architecture` produce candidate work, `plan` reduces a large candidate to a feature file, and the build takes that file. None of them builds.
</bundled_skills>

<success_criteria>
A build is complete when `workflows/dev_flow.md <success_criteria>` is met. A run of a bundled skill is not a build; each states its own finish.
</success_criteria>
