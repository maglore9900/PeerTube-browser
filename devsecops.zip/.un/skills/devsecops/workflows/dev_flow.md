<purpose>
Test-first, minimal-scope build flow with user confirmation at every stage change, written against `rules/code.md` and `rules/testing.md`. Every requirements shift, plan change and test alteration passes through explicit user approval. There is no outer acceptance test: the build closes when every phase clause is resolved by its phase's checkpoint or prose verification and the full suite is green.
</purpose>

<inputs>
- The user's build request. May arrive verbatim as `$ARGUMENTS` from the `/build` slash command, or be gathered in Step 1 if empty or thin.
</inputs>

<required_reading>
Read before starting:
1. `templates/plan_template.md` — the required shape for WORKING_FILE.
2. `rules/gates.md` — the grain, the red, the audit gate, and what done means.

Each step names the other rules it needs, where it needs them.
</required_reading>

<verification_method>
The test surfaces are defined in `rules/testing.md <surfaces>`. Each checkpoint is authored in the step that owns it, never up-front.

- **CODE** → an executable functional checkpoint, run through `scripts/validate_tests.py` or whatever other code testing mechanism the project uses, such as pytest. Confirmed red and self-checked before it is audited, and audited before the phase is implemented.
- **PROSE** (text an agent acts on: skills, agent and subagent definitions, commands, rules, disciplines, workflows and their step files) → a full read of each touched file against the phase Intent, then the document-type auditors per `<prose_verification>`. Documentation — the wiki, how-tos, READMEs, ADRs, anything written for a human reader — is not prose here: it is never a phase, carries no clause and is not verified; Step 9 updates it. A build whose only prose is documentation has no prose phase.
- **MIXED** → split the phase and run both. Its outcome is a pass only when both have landed.

Steps 7 and 8 fork on this. Take one branch and skip the other's sub-steps rather than improvising an equivalent.
</verification_method>

<prose_verification>
How a prose phase is verified at 7.p, where a code phase would run a checkpoint. An assertion written against prose rots on the first legitimate reword while catching nothing, so **no test file is authored for a prose change**; the code suite's one job in a prose phase is to keep passing.

1. **The Intent is the one written at Step 6**, before the change. An Intent that names what was written rather than what must be true goes back to Step 6; it is not repaired here, because an Intent rewritten now has been shaped by the change it is supposed to judge.
2. **Read each touched file in full against the Intent**, naming the clause each observation bears on.
3. **Dispatch the auditor owning each touched document type**, by name, whatever the size of the change:
    - any `SKILL.md` → `skill-auditor`
    - `<skill>/workflows/*.md` → `workflow-auditor`
    - a subagent `.md` → `subagent-auditor`
    - a slash command `.md` → `slash-command-auditor`
   Prose no auditor owns is verified by the read alone, and the outcome says `no matching auditor`, naming the file. An auditor that fails to return is re-dispatched; another's report does not stand in for it.
4. **Critical findings block**: fixed and re-audited, or put to the user with the reason you believe the finding does not hold. Recommendations and Quick Fixes do not block: apply those inside this phase's scope, and record the rest as follow-on work rather than fixing them in passing.
5. **Record the outcome** in the phase's `Checkpoint outcome`: the verdict, every auditor by name, the Criticals and what became of them, the recommendations applied and deferred, and at least one line of what the read established.
</prose_verification>

<clause_form>
How a clause is written, everywhere one is written: the phase clauses at Step 6, quoted as `must_prove` at Step 7.

**One Intent, cut into clauses.** Every phase carries ONE Intent: a single statement of what is true once the phase lands that was not true before. The clauses are that Intent cut into separately observable pieces — not additional intents and not a summary of it. Derive them this way:
    1. Write the Intent as prose first.
    2. Read it back and find each independently observable fact in it. A sentence joined by "and", or one naming two files doing two different things, carries more than one.
    3. Make each clause atomic — one observable fact, no conjunction — in the Intent's own words.
    4. Check the other direction: every clause traces back to something the Intent actually says.

Example Intent: *"`_compose` places the instruction, then the content sections, then the response template, and `_source` inlines a named file under a fence longer than any backtick run inside it."* That is two facts about two functions, so it is two clauses — `C1` the ordering `_compose` produces, `C2` the fence `_source` chooses. One clause carrying both is a compound claim, and a test that passed half of it would look green.

**Universals are derived or they are not written.** "At every verb", "for all four policies" is permitted only where the test parametrizes over a set taken from production AT RUN TIME.

**Numbered, and bound to assertions.** Within a phase, clauses are `C1`, `C2`; the plan and the Step 8 accounting refer to the same clauses build-wide as `P1C1`, `P2C1`, ... Each assertion carrying a clause is marked with its id in a trailing comment (`# C2`). Not every assertion needs a clause: a positive control arming a negative assertion, or any other supporting assertion, carries no id.

**The test's name and docstring are written LAST, from the assertions.** Prose written first enlarges the claim past what was asserted, and the prose is what a later reader trusts.

**One or two clauses per phase.** An Intent that will not reduce to two clauses is the reliable early sign that a phase was drawn too wide: split it at Step 6, where splitting is cheap, rather than writing a vaguer Intent.
</clause_form>

<baseline_variant>
When the pre-build suite is RED on failures unrelated to this build, "full suite green" is unachievable and is substituted with "no new failures against the baseline set", with the user's approval recorded in WORKING_FILE Requirements.

Step 8 compares the post-build failure set against it: passing means the build introduced no NEW failures, and it may resolve baseline ones.
</baseline_variant>

<process>

<checklist>
Copy this checklist and update as steps complete. Do not proceed past a gate whose box is unchecked.

```
Task Progress:
- [ ] Step 0:  Clear the bootstrap gate, resolve the tree paths, establish the baseline
- [ ] Step 1:  Gather requirements
- [ ] Step 2:  Develop a solution
- [ ] Step 3:  Identify every file, function, doc affected
- [ ] Step 4:  Reassess the implementation plan
- [ ] Step 5:  Draft the initial implementation
- [ ] Step 6:  Design the phase breakdown, checkpoints and seams
- [ ] Step 7:  Implement the phases
- [ ] Step 8:  Close the build on green
- [ ] Step 9:  Update documentation
- [ ] Step 10: Harvest tests
```
</checklist>

<step_0>
### Clear the bootstrap gate, resolve the tree paths, establish the baseline

Run `scripts/validate_tests.py --show-config` and clear the bootstrap gate in `SKILL.md <bootstrap_gate>`. Take `active`, `working` and `plans` from the output and use them.

Then run `scripts/validate_tests.py` and record the pre-build baseline.

**If it comes back RED:** follow `<baseline_variant>` above before going further — the substituted criterion needs a whole run behind it and the user's approval.

**Gate.**
    1. `--show-config` reports `defaulted` empty apart from `test_groups`.
    2. The resolved `active`, `working` and `plans` paths are in hand.
    3. The baseline has been run and its result recorded.
    4. If it was RED, the user has approved the substituted criterion.
</step_0>

<step_1>
### Gather requirements

Even where the request appears to carry every requirement, work out the requirements behind it: the purpose, what it will do, and why. Put any questions to the user. If you already have the requirements, review them for gaps and self-conflict, and for conflicts with what you find in the tree. Do not move past this step with the requirements out of sync.

Present the consolidated requirements for confirmation, naming any conflict with both of its sides. On agreement write them to WORKING_FILE at `<plans>/<NN>-<slug>.md` — `<NN>` the next free number — in the shape of `templates/plan_template.md`, as markdown with `###` subheadings. Every later step works from them, so state each one once, in full, and abbreviate nothing a later reader would need. Record Step 0's output alongside: the resolved `active` and `working` paths under Requirements, the baseline under Requirements → Baseline suite state.

**If `/devsecops:plan` wrote this build's feature file, that file IS WORKING_FILE.** Adopt it and keep filling it. Never create a second file beside it.

**Every test this build authors goes into `working`** — checkpoints and inner tests. `workflows/harvest.md` moves what lasts into `active` after the build closes, which is why a build never edits `test_groups`.

Two standing requirements: new code matches existing style (args, CLI, variable names, internal structure); backwards compatibility is NOT a requirement unless the user asks for it.

**If this is a REWRITE / MIGRATION / SUITE-REPLACEMENT:** run a discovery pass first. Enumerate the functional areas, read the existing artifacts as intent inventory — capturing what SHOULD be verified without inheriting its mechanics — and fold the output into the requirements draft under "Discovered functionality".

**Gate.** WORKING_FILE exists under the resolved `plans` and holds the confirmed requirements, the resolved paths, and the baseline. The user has explicitly confirmed the requirements.
</step_1>

<step_2>
### Develop a solution

Develop a high-level plan for the confirmed requirements. **Narrative only, no code.** Cover, in prose:
    - The overall approach, and how it satisfies each requirement in turn.
    - The alternatives you considered and why the chosen one won. An approach with no rejected alternative was not chosen, it was assumed.
    - Gotchas, risks, and current and future limitations.
    - The tradeoffs the user is being asked to accept.

The requirements are settled. **If the plan cannot be accomplished without conflicting with one of them:** put the conflict to the user, naming the requirement and what it collides with, rather than bending either side.

Iterate until final, then append it to WORKING_FILE's plan section with `###` subheadings for approach, alternatives, risks and tradeoffs.

**Gate.** No conflict stands, or the user has accepted the limitation. The user has approved the plan and it is persisted in WORKING_FILE.
</step_2>

<step_3>
### Identify every file, function, doc affected

Identify EVERY thing the high-level plan will interact with, documentation included. Discovery is your job at this step: search the project with `Read`, `Grep`, `Glob` and `AstGrep`, in your own context rather than through subagents.

Each element gets its own entry under Impacts in WORKING_FILE: what changes about it, what depends on it, and the risk of regression. One element, one impact analysis.

**Every entry carries the `path` of the file it concerns**, even where the element is a function, a table or a section rather than the whole file. Step 4 opens those paths to check your analysis. Where an element genuinely spans several files, that is several entries.

Then record two derived lists beneath the inventory:
    - **Docs checklist** — the documentation subset, one entry per document with what changes about it. Empty if this build changes no documented behaviour.
    - **Highest risk** — the three elements you consider highest risk, each with the reason.

**Gate.** Every affected element is listed in WORKING_FILE with a path and an impact note, and the docs checklist and highest-risk list are recorded.
</step_3>

<step_4>
### Reassess the implementation plan

With the impacts captured, judge the high-level plan against them. Answer all four in WORKING_FILE:
    1. Will it still work as intended?
    2. What are the ramifications?
    3. What else must happen for existing functionality to continue working?
    4. In what way is the original functionality altered?

**Check the inventory, do not restate it.** Open the files at each entry's `path` and confirm the impact against what is actually there. Record every entry the file does not bear out, naming the entry and what the file shows.

**A new impact is one the inventory does not already carry.** Read the inventory before calling anything new: a restated impact reported as new sends the build back for nothing.

The requirements and the high-level plan are settled. A genuine conflict with either stops the loop and reopens that step with the user; it is not resolved by adjusting the plan.

Present the answers with recommendations. Each recommendation says what it changes and what it costs — the user is deciding whether to take it, not whether it sounds reasonable. On a user-approved way forward, record the approved changes, add every new impact to the inventory, and **return to Step 3**. Loop until a pass surfaces no new impact and no unconfirmed entry.

**If three consecutive passes still surface new impacts:** stop and ask whether the scope needs narrowing.

**Gate.** Steps 3-4 have converged with no new impacts and no unconfirmed entries, and the user has approved the way forward.
</step_4>

<step_5>
### Draft the initial implementation

**Required reading** — `rules/code.md <ladder>`: the draft is written against it.

1. Work out what functionality this build will need to test.
2. Draft the code as a first draft that would work in an ideal situation: module map, signatures with invariants, tables and constants with their real contents, seams, and the decisions behind them.
3. Capture it in WORKING_FILE under Implementation plan.

Then check the draft against the high-level plan and the requirements, adjusting on each miss. Repeat until correct, to a maximum of three passes. **If three passes do not converge:** stop and notify the user, and continue only once they accept the limitation.

**Gate.** The draft is captured in WORKING_FILE and aligned with the plan and the requirements, or the user has accepted the stated limitation.
</step_5>

<step_6>
### Design the phase breakdown, checkpoints and seams

**Required reading** — `rules/testing.md` (seams, surfaces, what any test must assert) and `rules/shape.md <ladder>` (pick the highest rung the invariant supports).

Decide how the Step 5 draft lands: a sequence of small, independently-verifiable slices. Each one is a phase, and each phase gates on one checkpoint. All builds are one or more phases.

**Rules.**
    - **At most 4 phases.** More effort splits across multiple plans, on the natural seam. A build needing more records the reason and the supporting information under the phase breakdown's rationale.
    - **One or two clauses per phase**, cut from one Intent per `<clause_form>`. A phase whose Intent cuts into three is two phases.
    - **A phase is `code` or `prose`.** `prose` means a change to text an agent acts on. **Documentation is never a phase** — Step 9 updates it from what the build delivered.

**Write each phase's Intent before designing its checkpoint — code phases included.** Intent is the post-phase state, anchored to specific files, functions and structural elements, with no shorthand only the author would recognise: what a CALLER or READER can do afterwards that they could not before. An Intent naming the assertions, or claiming the artifact contains what was written, is circular and verifies only that the author pasted what they meant to. Then cut it into clauses per `<clause_form>`.

**Each code phase's checkpoint IS its seam, and this step is where it is agreed.** Name the boundary the checkpoint enters and what it asserts there. Where the existing suite already tests at that boundary, name the harness: the precedent is the argument. A seam left vague here is a seam the checkpoint author picks alone.

Each checkpoint asserts the phase's real functional output; one that would pass on a stub or a hard-coded return is not a checkpoint. Every clause must be resolvable by its phase's checkpoint or prose verification — a clause no phase can prove is cut or moved here.

**Capture in WORKING_FILE:** a `#### Phase N — <name>` subsection per phase with its kind, Intent, clauses, checkpoint and seam, and the files it touches (each marked NEW or EDITED). Beneath the phases, record any phase needing user coordination (a credential, a live endpoint, a manual step), naming the phase and what it needs, and the rationale for the split.

**Present the plan to the user** — phases, checkpoints, seams, Intents, clauses and rationale, with any coordination you will need from them. Adjust on their input until they approve.

**Gate.**
    1. Every phase carries one Intent written before its checkpoint was designed, naming no assertions. Code phases included.
    2. Every clause is atomic, numbered, and traces to its Intent per `<clause_form>`, and no phase carries more than two.
    3. Every code phase has its checkpoint and seam defined in WORKING_FILE — a single-phase plan included — and every checkpoint would fail against a stub or a hard-coded return.
    4. No documentation is a phase.
    5. The plan is no more than 4 phases, or the reason for more is recorded.
    6. The user has approved the plan.
</step_6>

<step_7>
### Implement the phases

**Required reading** — `rules/gates.md` for the grain, the red and the audit gate.

With every prior step complete, confirm with the user, then implement phase by phase.

**Fork per phase, not per build** — a build may hold both kinds. **CODE → 7.1-7.5. PROSE → 7.0 once, then 7.p per phase. MIXED → both halves.**

7.0. **PROSE, before any phase: establish the prose phases' clauses are not already true.** Read the files the prose phases will touch, in full, AS THEY STAND. For each clause, record in WORKING_FILE whether it is TRUE of the tree today, with the evidence: what you read and where — file and heading, or file and line. A clause already true measures nothing: drop it, or record why it stays. **At least one clause must be false**, or the prose phases have nothing to do and the build stops here.

7.1. **Author the checkpoint.**
    **Required reading** — `rules/testing.md` and `rules/shape.md`.
   Write ONE test file in `working`: the checkpoint that gates this phase and no other, at the seam Step 6 agreed. Its `must_prove` is the phase's clauses, quoted from WORKING_FILE. Test the lowest changed layer first, then the highest reachable one.
   **Build it clause by clause.** Take one clause, write the assertion that carries it, mark it with the clause id (`# C1`), establish the value the observable takes under the wrong implementation, and only then move to the next. **The name and docstring are written LAST, from the assertions.**
   **A severed layer may be shimmed.** Where the phase's output needs a higher layer that does not exist yet, shim that layer only, and only while the remaining assertion still exercises real logic. Standing in for a genuine SYSTEM boundary — an external API, a clock, a random source — is allowed. Standing in for a module this project owns is not.
   If the phase introduces new symbols, either author the checkpoint after its first scaffolding edit lands, or shape the assertion to fail on behaviour against a bare stub. **If `<active>` holds a test that already does what you are reaching for, copy it into `<working>` and adjust it.**
   Validate it as you write:
    - **Would it fail** against a plausible wrong implementation — a stub, a hard-coded return, an off-by-one, the previous behaviour left unchanged?
    - **Does the assertion match the claim?** A test named for one behaviour asserting a different, easier one is the most common real finding and the number one reason a test is rejected. Its usual form is partial rather than wrong: the claim carries several clauses and the assertions cover all but the hardest. (`testing.md <whole-claim>`)
    - **Is the expected value independent?** Recomputing it the way the code computes it makes the test pass by construction. (`shape.md <tautological-assertion>`)
    - **Right rung?** (`shape.md <ladder>`, `<downshift_rule>`)
    - **Edge cases tested?** (`testing.md <bounds>`)
    - **Both positive and negative assertions?** (`testing.md <normal-and-abnormal-paths>`)
    - **Coupled to implementation?** (`testing.md <coupling>`)
    - **Independent?** Runnable alone, leaning on no state another test left behind.
   **If a clause cannot be asserted:** raise it with the user, provide a recommendation, and follow their instructions.

7.2. **Self-check it, and confirm the red.** Review the test as it now stands and answer seven questions:
    1. **Whole claim.** Does the checkpoint actually test each clause of `must_prove`, and each claim of its name and docstring?
    2. **Absence only.** Any negative assertion with no positive control proving the code path ran? Delete the code under test in your head — does it still pass? (`shape.md <absence-only-assertion>`)
    3. **Echoed literal.** Any assertion comparing a value to itself, or the test performing production's transformation? Name the production line whose deletion turns it red. (`shape.md <echoed-literal>`)
    4. **One value.** Any observable read at a single input, or pinned against a sibling from the same source? (`shape.md <single-value-pin>`)
    5. **The double.** Shimming a severed layer is allowed — but does any double stand in for a module this project OWNS? No auditor asks this; it stops here or not at all.
    6. **It collects.** Run `scripts/validate_tests.py <test-file> --collect-only -q` and read the node ids in `last_test_output.txt`. Every import resolves, every name binds, every helper's arguments exist on the real type, and the count matches what you wrote.
    7. **Observed, not predicted.** Every expected value for an output shape you had not already seen comes from a RUN: write a probe under `working`, run it, read what happened. A value or a premise reasoned out of source, a changelog or a tool's own documentation is a prediction.
   **Any yes is a rewrite, not a dispatch.** Correct the test and walk the seven again.
   Then run the checkpoint via `scripts/validate_tests.py <path>` and answer three more from what it printed:
    8. **Red, not green.** Does it FAIL against the code as it stands? A checkpoint green before the phase is built measures nothing: find what it asserts that is already true and assert the phase's own claim instead.
    9. **Red for the right reason.** Is it red because the phase is not implemented — or because of a typo, a missing import, a path that does not exist, or a harness that cannot do what the test assumes? Those four are defects in the test. **A failed CONTROL assertion is always this case**: the test never reached the assertions that judge the code. Name the assertion that failed, its line, and what it failed on.
    10. **Observed expected output.** Does each row's expected value say what the run showed, or what you thought it would show? Where the run disagreed with you, the run is right.
   A no to 8 or 9, or a row the run contradicted, is a rewrite: correct the test, run it again, and answer these three over the new output. Never settle a red by implementing the phase, and never by dropping a clause; a premise you cannot arm is rewritten to one you have SEEN work.
   **Record one row per `must_prove` clause** in WORKING_FILE under the phase, with four cells: the clause id copied exactly, the assertion at `file:line` and what it asserts, the value under the right implementation, and the plausible wrong implementation it excludes with what the observable reads under it. Where the last two values are equal the row carries no assertion and is rewritten. Supporting assertions get no row.
    - `C1 — test_filter.py:41, colon-named key absent — expected: absent — under a first-colon split: PRESENT`
   **A clause with no discriminating observable at this seam** is put to the user once. Record their answer, quoted, as that clause's exemption, with what is being conceded and who carries it instead.
   Write the ten answers beneath the rows, quoting the exit status and the failing assertion and line from the run, and put the rows and answers into the message as well.
   **Gate.**
    1. Every `must_prove` clause has a row or a user-approved exemption.
    2. Every row's two values differ.
    3. All ten questions are answered, anything they surfaced is rewritten, and the test is red for the right reason with that reason written down.
    4. The rows and answers are in WORKING_FILE under the phase.
   **DO NOT PROCEED IF THE GATE IS NOT SATISFIED**

7.3. **Dispatch both auditors in a single message so they run concurrently.** 
    - `devsecops-test-shape-auditor` owns `rules/shape.md`. Blocks on any anti-pattern entry, the anti-rung, a test that would pass against a stub.
    - `devsecops-test-claim-auditor` owns `rules/testing.md`. Blocks on the test not doing what its surface exists to prove, and emits the CLAUSE MAP.
   Both get the same three fields, every path absolute and confirmed to exist: `test_path`, `surface` (`checkpoint`), and `must_prove` — the clause list quoted from WORKING_FILE, never paraphrased or composed at dispatch. Never the WORKING_FILE, the plan, or your reasoning for why the test is right. The predicted failure mode comes from the shape auditor only.
   Record both verdicts under the phase in `gates.md <outcome_format>` shape, shape auditor first. **If one agent fails to return the gate is not satisfied** — re-dispatch it; the other's PASS does not stand for the pair.

7.4. **Remediate any open findings.** Work the LEDGER, row by row, and rewrite nothing it does not name.
   **The ledger is the CLAUSE MAP the claim auditor emitted on this test's FIRST audit, frozen.** It does not grow, and nothing in it is triaged out, except a row whose clause the user has exempted. For each UNCARRIED row record exactly one of:
    - **fixed** — the test changed so an assertion now carries that clause. Name the assertion and the wrong implementation it excludes.
    - **justified** — the clause correctly stands uncarried. For a DOCSTRING or NAME row this is usually the sentence narrowed to what the test asserts: make that edit. The only other two justifications are "another test already covers it" and "no phase delivers it", each naming the test or the phase.
   **A clause from `must_prove` is never justified away.** The user approved it at Step 6 and the phase is written to deliver it. Fix it or the gate does not close.
   The shape auditor is NOT bounded by the ledger: its findings are about the test as it stands now, and its commonest one is introduced by a remediation — an assertion written to carry a whole-claim finding that mirrors the production table it was meant to check. Read its verdict against what you are about to write.
   Address every numbered CRITICAL from both auditors, one line each in WORKING_FILE saying what you did. A recommendation does not block: take it if it improves the test, and record it either way.
   Before re-dispatch, walk 7.2's questions 2-7 again on the amended test, plus: **still red for its own reason?** After your edits, does it still fail because the phase has not been built, rather than on a typo, an unarmable fixture or an import you just broke? Rewrite the rows and write the new pass into WORKING_FILE. A fix is new surface: the previous pass describes a file that no longer exists. Then re-dispatch as at 7.3, resuming the same auditor turns with the frozen ledger. Either BLOCK is fixed or escalated.

7.5. **Implement the phase.**
    **Required reading** — `rules/code.md`, and `rules/testing.md <coupling>` before introducing any double.
   **The checkpoint is not yours to edit** — it has produced a gate verdict. Write the smallest production change that turns it green, each line at the highest rung of the ladder that solves the real problem. **Nothing hollow:** no stub return, no swallowed error, no TODO, no placeholder in gated code. Build for the test in front of you; refactoring waits for Step 8.
   Write an inner unit test only where the checkpoint cannot express a behaviour, recording why. A phase with no inner tests is the normal case.
   **Scope is this phase.** A file you had to change that the phase's files list does not name is a gap in the impact inventory: record it under the phase rather than absorbing it silently. New code matches the style of the file it lands in; comments are minimal and say WHY.
   Record what changed, file by file, under the phase — Step 9 is written from it. Then re-run the checkpoint and capture its outcome under the phase before starting the next. **If it FAILS:** stop, confirm the checkpoint tests what was intended, then troubleshoot the implementation until it passes.

7.p. **PROSE: make one phase's change, then verify it.** Change only this phase's files. Then **read each touched file IN FULL against the Intent**, naming which clause each observation bears on; that read is the phase's verification. Documentation describes the current state: not what it was, not what changed, not the journey. Do not softwrap. **Author no test file for a prose change** — not a substring check, not a section extract, not a "the file mentions X" test — and keep the code suite passing throughout. A file you had to change that the phase's files list does not name is recorded as an inventory gap.
   Then dispatch the document-type auditor for each touched type per `<prose_verification>`, handing it the files in full and the Intent as context only: the Intent is not a criterion and not a defence of the change. Triage what comes back:
    - **A Critical BLOCKS the phase.** Fix it, or state why you believe it does not hold — and put that to the user. You are the party already committed to the change being right, so a Critical you wave away alone is the one nobody else catches.
    - **Recommendations and Quick Fixes do not block.** Apply those inside this phase's scope; route the rest to follow-on work and record where. Never fix an out-of-scope finding in passing — a finding about a file a later phase owns is routed, not fixed.
   Record in the phase's `Checkpoint outcome` the Criticals still standing and why, the recommendations applied and deferred, and at least one line on what the audit and your read established. Re-audit until no Critical stands.

**Test alteration policy:** no checkpoint changes after it has gated without recorded user approval. If one needs changing, stop, say what you observed, and ask. Two carve-outs: a change answering a RECORDED audit finding before the test gated anything is covered by that record; inner unit tests may be renamed, extracted and de-duplicated at Step 8, though behaviour changes to one still need approval.

**Gate.**
    - **Both branches:** every phase ran its own branch, WORKING_FILE records the result per phase, every unlisted file is recorded as an inventory gap, and any test altered after it gated carries recorded user approval.
    - **CODE:** the self-check rows and answers, the red and its reason, both auditor verdicts PASS with the predicted failure mode, every UNCARRIED ledger row fixed or justified, a passing `Checkpoint outcome`, and a recorded reason for any inner unit test.
    - **PROSE:** 7.0's per-clause record with at least one clause false, the per-clause read, and no Critical standing. No red and no test-auditor verdict is expected, and their absence is not a hole in this gate.
</step_7>

<step_8>
### Close the build on green

**Required reading** — `rules/gates.md <done>` and `rules/code.md`, which the refactor pass is measured against.

**The refactor pass happens here, not inside a phase.** Every phase has landed and every checkpoint is green. Remove the duplication and hard-coding introduced getting to green (`code.md <step_sizing>`), clarify names, re-run after each small change. A refactor that reddens the bar is reverted, not fixed forward. **New behaviour is not a refactor** — it needs a fresh red back in a phase. Record every refactor made, every one left out and why, and anything that turned out to need new behaviour.

**Then review any inner unit tests** against `rules/testing.md` and `rules/shape.md` as an inline review; the auditors audit checkpoints only. Skip when the build wrote none, which is the normal case. An unusually large crop is worth a note: the phases were drawn too coarsely.

**Then account for every clause.** Each `P<n>C<m>` is resolved by its phase's checkpoint or prose verification, or carries its user-approved exemption.

**Then run `scripts/validate_tests.py --compare`.** For a large failure set, `--failures-by-cause` collapses it to one line per distinct cause.

**If any test is RED:**
    1. **Inspect the failing test first.** Was it architected properly? A test that was always wrong and is only now being run is a different problem from a regression.
    2. **Only then troubleshoot the implementation.** Where the fault is the implementation, answer both what is wrong and **why the checkpoints did not catch it**. A checkpoint gap is a finding — record it, naming the phase whose checkpoint should have caught it.
    3. **A durable test that conflicts with a confirmed requirement of this build is RETIRED** — not repointed, not quietly edited — including one still green that now passes vacuously. Record which and where it went.
    4. Do not weaken a test to make it pass, and do not touch any checkpoint. Fix, re-run the checkpoint of every phase the failing test targets, then re-run this step.

**If the suite is still red after three attempts:** stop and escalate. The Step 3-6 plan is likely wrong and the loop needs reopening.

**Gate.**
    - **Both branches:** every clause is resolved or exempted, `--compare` has been run and recorded, and the full suite is green — or, under the approved baseline variant, the post-build failure set is a subset of the baseline.
    - **CODE:** the refactor pass ran on green with any reddening refactor reverted; inner tests were reviewed inline or none were written; every red was diagnosed test-first and any checkpoint gap recorded.
    - **PROSE:** every clause 7.0 recorded false is now true, and no Critical is outstanding.
</step_8>

<step_9>
### Update documentation

Documentation is brought up to what actually landed — the per-phase change records in WORKING_FILE — not to the plan or the requirements.

9.1. **Decide which documents this build has made wrong.** Every element of the Step 3 docs checklist is recorded as one of two things, with no third state:
    - **update** — the build has made it wrong or incomplete; note what has to change and what in the delivered state makes it wrong, naming the sentence or section where you can.
    - **no update** — note why it turned out not to need one.
   Then check `docs/wiki/` for articles describing behaviour this build changed, and the ADRs under `docs/project/adr/` covering the area it touched. A document needing an update that the checklist does not name is added as **update** — it is a gap in the Step 3 inventory. Judge a document by what it CLAIMS: one that never mentions the changed behaviour is out of scope however close it sits to the files that moved; one whose single sentence on the subject is now false is in scope however far away it is.
   **If this build contradicts an ADR,** say so to the user rather than silently overriding it. An ADR amendment is their decision.

9.2. **Update each document on the list, one at a time.**
    - **Describe the current state.** Not what it was, not what changed, not the journey: no changelog entry, no "previously", no "now also supports".
    - **Point, never restate.** A fact another document on the list owns gets "For X see `path/to/other.md`".
    - **Verify before you write.** Every claim about the code is checked against the code, not inferred from the change record.
    - A document that does not exist yet is written. A file you had to touch that is not on the list is recorded, not absorbed silently.
    - Author no test file. Do not softwrap: one paragraph is one line.
   Record a one-line summary of each document's change in WORKING_FILE.

**Gate.** Every Step 3 docs checklist element, and every document found in 9.1, is marked updated or not needing an update with a reason. Any ADR conflict has been put to the user. A doc whose behaviour this build changed and left untouched fails this gate.
</step_9>

<step_10>
### Harvest tests

Run `workflows/harvest.md` end to end, scoped to the tests this build wrote in `working`. It is the authority for this step. At its Step 4, put the classification to the user and carry out only what they approve.

**Gate.** The harvest reached its own completion criteria: `--audit-map` exits 0, `working` holds none of the files in scope, everything with lasting value moved into `active`, what it replaced retired to `archive`, `test_groups` updated, each moved assertion verified by mutation, the remainder cleared to `./delete_me/`, and `--compare` shows appearances and departures matching the harvest and nothing else.
</step_10>

</process>

<success_criteria>
**Every build:**
    - [ ] WORKING_FILE exists, matches `templates/plan_template.md`, and holds the confirmed requirements, approved plan, impact inventory with paths, drafted implementation, phase breakdown with a per-phase Intent and clauses, and a recorded outcome per phase.
    - [ ] Every phase's verification passed on its own branch and its outcome was recorded.
    - [ ] Every clause is resolved by its phase's checkpoint or prose verification, or carries a user-approved exemption.
    - [ ] The full suite is green, or no worse than the approved Step 0 baseline.
    - [ ] Every documentation element identified in Step 3 or found in Step 9 matches what was delivered.
    - [ ] The harvest workflow completed.

**Every CODE phase:**
    - [ ] The seam was agreed with the user at Step 6 before any test was written at it.
    - [ ] The checkpoint is green, with every inner unit test green.
    - [ ] The checkpoint was self-checked and confirmed red for the right reason BEFORE it was audited, and audited by BOTH agents BEFORE the phase was implemented, both verdicts PASS with the predicted failure mode, every BLOCK fixed or overruled on the record. A gate carrying one verdict is not satisfied.
    - [ ] WORKING_FILE carries a self-check row per clause for every dispatch — the first one and every re-dispatch after a BLOCK — and every UNCARRIED ledger row is fixed or justified.
    - [ ] No checkpoint was altered after it gated without recorded user approval or a recorded pre-gate BLOCK.
    - [ ] Any inner unit test carries the reason its checkpoint could not express the behaviour.
    - [ ] Delivered code matches existing style.

**Every PROSE phase:**
    - [ ] Its clauses were recorded true or false against the tree before it ran, at least one false.
    - [ ] Every touched file was read in full against the Intent, and every touched document type's auditor was invoked, or `no matching auditor` recorded naming the file. No Critical outstanding.
    - [ ] Every clause recorded false is now true, and the code suite is no worse than the Step 0 baseline.

A build with no phase of one kind satisfies that kind's list vacuously. **Satisfying only the "Every build" list is not completion** — every phase belongs to one branch, so one of the other two lists always has items in play.
</success_criteria>
