<purpose>
Move what has lasting value out of the `working` test tree and into the durable suite, one test at a time, and clear the remainder. A build writes every test it authors into `working`, so without this pass that tree accumulates and the coverage a build earned is either lost or filed under a phase name in `active`.

Run it after a build closes, or against the accumulated tree when several have closed without one.
</purpose>

<inputs>
- `$ARGUMENTS`, optional: the files to harvest, or a plan file naming a build. Empty harvests the whole `working` tree.
</inputs>

<required_reading>
Read before starting:

1. `.un/skills/devsecops/rules/testing.md` `<surfaces>`: the test surfaces and what each is for. Every classification in this workflow turns on which surface a test belongs to.
2. `.un/skills/devsecops/SKILL.md` `<bootstrap_gate>`: the config resolution Step 1 clears before anything else.

**Placeholders.** `<PROJECT_DIR>`, `<active>`, `<working>`, `<plans>`, `<delete_me>`, `<archive>` and `<record>` throughout this workflow are the values Step 1 reads from `--show-config`, not literal paths. Substitute them; a project whose suite does not live under `tests/` gets a different value for most of them.

**Run every command from `<PROJECT_DIR>`.** `validate_tests.py` resolves its own paths from the working directory, so its group selection, its digests and where it banks are all read off the shell's cwd — which is why the invocations below are spelled `./...` rather than absolutely. `cp`/`mv`/`mkdir` keep the `<PROJECT_DIR>` prefix so a file operation still names its target unambiguously in the record.
</required_reading>

<classification>
The five verdicts a test can receive, and what each means. One test function gets one verdict — a file is harvested whole, in part, or not at all.

| Verdict | Means | Disposal |
|---|---|---|
| `COMBINE` | This test and an `active` test each assert something the other does not, so neither is worth keeping whole | Merged into one test in the subject file; the emptied one is retired |
| `DURABLE` | Asserts a behaviour of live production code that no test in `active` asserts | Moves into the subject file |
| `REPLACES` | Asserts what an `active` test asserts, from a better position — drives the real producer where the old one hand-built both sides, or the old one is now wrong | Moves in; the old test is retired |
| `REDUNDANT` | A test in `active` already asserts this behaviour | Stays out |
| `SPENT` | Names production code that no longer exists, or is scaffolding for a phase that has landed | Stays out |

**A checkpoint is not automatically spent.** Its lifetime is the life of its build, but an assertion no other surface covers moves into the surface it belongs to rather than going with the file. *The question is never which surface a test came from; it is whether the durable suite would still catch the regression once the file is gone.*
</classification>

<process>

Copy this checklist and update as steps complete. Do not proceed past a gate whose box is unchecked.
```
Task Progress:
- [ ] Step 1: Resolve the trees and the harvest scope
- [ ] Step 2: Inventory every test in scope
- [ ] Step 3: Classify each test against the durable suite
- [ ] Step 4: Agree the harvest plan
- [ ] Step 5: Apply the harvest
- [ ] Step 6: Verify every moved assertion by mutation
- [ ] Step 7: Dispose the spent working files
- [ ] Step 8: Run the suite and bank
```

**HARVEST_FILE** is the record this workflow builds up. Its path is chosen in Step 1 and named explicitly in every later step, so a resumed session reads it rather than re-deriving what was decided.

<step_1>
### Resolve the trees and the harvest scope

Read the config:

```
./.un/skills/devsecops/scripts/validate_tests.py --show-config
```

Clear the bootstrap gate in `SKILL.md <bootstrap_gate>` against that output: while `defaulted` lists a key, its value is the skill's guess about this project, and a harvest MOVES files — it is the wrong workflow to be guessing where they go. On an already-bootstrapped project this costs one command and no questions.

Then take `active`, `working`, `plans`, `delete_me`, `archive`, `project_dir` and `record` from the output and substitute them wherever this workflow writes a placeholder.

Then fix the scope from `$ARGUMENTS`:
    - **If it names test files:** those files are the scope.
    - **Else if it names a plan file:** read it and take the test paths it records under its own test sections.
    - **Else**: every `test_*.py` under `<working>`.

With everything confirmed, write HARVEST_FILE `<plans>/harvest-<scope-slug>-plan.md`. Write the resolved paths and the scope list to it, so a resumed session substitutes the same values rather than re-reading a config that may have moved on.

**Then snapshot the record, before anything else runs:**

```
cp <PROJECT_DIR>/<record> <PROJECT_DIR>/<record>.preharvest
```

**If `<record>` does not exist:** this project has never banked, so there is no pre-harvest state to hold. Record that in HARVEST_FILE, and Step 8 skips the restore.

Step 8 restores this snapshot and compares against it. `--compare` reads the record as it stands when its own invocation starts, so without the snapshot it measures the harvest against a record the harvest has already rewritten — and prints `nothing moved against the previous record`, character-for-character what a clean harvest prints. **A lost snapshot does not announce itself.**

It carries a second load. Step 6's mutation runs bank a stamped digest for the group they touch, so without the restore Step 8 would find that group current and green and carry it forward — never running the harvested tests together, which is the one thing Step 8 exists to do. Restoring puts back the group's PRE-HARVEST digest, which Step 5's edit to its test file has since moved, so the group runs whole.

*Taken here rather than at the step that consumes it because ordering is the only thing enforcing it: any later placement rests on nothing having banked against a real group yet, and a path-targeted spot check of the tests just placed banks whole groups.*

**Gate.**
    1. The bootstrap gate is clear.
    2. HARVEST_FILE exists and names every resolved path plus every file in scope.
    3. `<record>.preharvest` is on disk, or HARVEST_FILE records that `<record>` did not exist to snapshot.
</step_1>

<step_2>
### Inventory every test in scope

Read each file in scope IN FULL — the module docstring, every test function, and every helper and fixture they use. *A test's docstring is where its author recorded which rule it gates, and that is what Step 3 classifies against; a signature list cannot answer it.*

For each file, record in HARVEST_FILE under a `### <path>` subsection: the production script it drives, its test functions by name, and any module-level fixture or constant its tests depend on.

**If a file fails to import or collect:** record that and treat every test in it as unclassifiable until it does. Run it to find out:

```
./.un/skills/devsecops/scripts/validate_tests.py <path>
```

*A scratch file left by an older build often names a contract that has since moved, and a collection error is that signal arriving.*

**Gate.**
    1. Every file in scope has a `### <path>` subsection in HARVEST_FILE listing its tests.
    2. Any test that will not collect is marked as such.
</step_2>

<step_3>
### Classify each test against the durable suite

Work one test function at a time. For each, read the subject file in `active` for the production script that test drives — `<active>/test_<script>.py`, or every `<active>/test_<script>_<a|b|c>.py` part where the subject is split — and decide whether that file already asserts the same behaviour.

Assign one verdict per `<classification>` above and write it under the test's name in HARVEST_FILE with a one-line reason.

**If no subject file exists in `active` for that production script:** the verdict cannot be `REDUNDANT`. Record the subject file as one Step 5 must create.

**If the test drives a production script that no longer exists:** the verdict is `SPENT`.

**If two tests in scope assert the same behaviour:** keep the one that drives the real producer and mark the other `REDUNDANT`. *Two scratch files from different builds routinely cover one rule, and harvesting both files the subject twice.*

**Gate.**
    1. Every test function in scope carries a verdict and a reason in HARVEST_FILE.
    2. Every `REPLACES` names the `active` test it replaces.
</step_3>

<step_4>
### Agree the harvest plan

Present to the user, from HARVEST_FILE: how many tests carry each verdict, every `DURABLE`, `REPLACES` and `COMBINE` test with its destination file, every `active` test that would be retired, and every `test_groups` entry that would change. For a `COMBINE`, name the `active` test it merges with and which assertions come across.

Call out separately any subject file Step 5 would create, since a new file is a new group and a new map entry.

**If the user changes a verdict:** update HARVEST_FILE and re-present the affected rows.

**Progress Gate.** The user has approved the plan. *This step is the last point before files move and the map changes.*
</step_4>

<step_5>
### Apply the harvest

5.a. **Move the harvested tests into their subject files.**

For each `DURABLE` and `REPLACES` test, copy the function, plus any fixture or constant it depends on, into `<active>/test_<script>.py`.

**If the subject file exists:** add the test to it, reusing the fixtures already there rather than carrying a second copy of an equivalent one.

**Else**: create `<active>/test_<script>.py`, named for the production script and nothing else. *`active` is flat and binds both ways — one script, one test file — with only the directories the project's own layout rule names.*

**If the subject is SPLIT into `test_<script>_<a|b|c>.py` parts:** add the test to the part carrying the lowest `duration_s` in `<record>`, or to any part where the record cannot answer. The suffix is a lane, not a topic, so no part is the right home on subject matter; `duration_s` is just the least arbitrary tie-break available. Do NOT pick by counting test functions — seconds per test varies by an order of magnitude inside one subject, so the part with fewest tests is routinely not the fastest.

**Spend no more than that on the choice.** Balancing parts buys very little. A batch's wall clock is `max(slowest group, total / lanes)`, and a suite is normally bound by the second term, or by the CPU its lanes contend for — and a harvest's placement decision moves neither. Where a project's wall clock really is set by one group, that is a re-split to plan and measure on its own, not a decision to agonise over here.

**Never create a new part here.** A part is created by a deliberate re-split. Adding one during a harvest buys that same low-value rebalancing and charges a pytest start against every run from then on.

Keep each test's docstring. Where it names the build or phase it came from, rewrite it to state the rule the test gates.

**For each `COMBINE` test:** it and an `active` test each hold something worth keeping, so neither moves whole. Merge them into ONE test in the subject file — start from whichever carries more of the value, lift the assertions the other owns into it, and retire the emptied one to `<archive>/<topic>/` exactly as 5.b retires a `REPLACES`. Name the surviving test for everything it now asserts. *A `COMBINE` that is filed but never merged is the one verdict Step 7 disposes like a `REDUNDANT`: it moves to `<delete_me>/` with the rest of the scope, and the coverage it was kept for goes with it.*

5.b. **Retire what the harvest replaces.**

For each `REPLACES` verdict, move the `active` test it names into `<archive>/<topic>/`.

**If the whole file is replaced:** move the file, and drop its `test_groups` entry in Step 5.c.

**Else** (individual functions replaced): cut those functions into `<archive>/<topic>/<original-filename>`, leaving the rest of the file in place. **If that empties the original:** move it as above.

5.c. **Update the group map.**

Edit `test_groups` in `.un/skills/devsecops/config.json`: add an entry for every subject file 5.a created, drop the entry for every file 5.b moved out whole, and add to an existing entry any production file the harvested tests now exercise that it did not claim.

An entry names what the file TESTS, never what it imports or shells to build a fixture.

**One claimant per subject, which is not the same as "nothing under the test tree".** A shared helper — `conftest.py`, `_paths.py`, `_fixtures/` — is claimed by nobody: it is shared by everything importing it, so charging each importer would bill every one of them for a fixture edit, and a broken helper breaks loudly at collection time for all of them instead. But a test-tree file a group DRIVES is that group's subject and is named like any other dependency — a bundle's `check_acceptance.py`, `stage.py`, `preflight.py` or `stub_abrowser.py`. What separates the two is what the group does with the file, which no path prefix can express.

`validate_tests.py --suggest-map` prints a derived fragment to prune against that rule. Then run:

```
./.un/skills/devsecops/scripts/validate_tests.py --audit-map
```

**If it exits non-zero:** fix the entry it flags. **Else**: read its `MISSING` findings against the tests just moved before treating this as done — a clean exit does not make the tests-versus-fixture judgement for you.

**Gate.**
    1. Every approved test is in its subject file.
    2. Every retired test is under `<archive>/`.
    3. `--audit-map` exits 0.
</step_5>

<step_6>
### Verify every moved assertion by mutation

The coverage just moved already passed where it came from, so there is no red to observe and nothing yet shows it still discriminates in its new home.

**Confirm `<record>.preharvest` from Step 1 is still on disk before the first run below.** These are banking runs, and once one has landed the pre-harvest state is unrecoverable. **If it is gone:** say so now rather than at Step 8.

The restores below land in `<delete_me>/`, so make sure it exists before the loop starts — Step 7 creates it, and Step 7 runs after this:

```
mkdir -p <PROJECT_DIR>/<delete_me>
```

For each moved test, in turn:
1. Name the rule its assertion gates.
2. Copy the production file it drives, so the restore has something exact to come from:

```
cp <PROJECT_DIR>/<production_file> <PROJECT_DIR>/<production_file>.bak
```
3. Break that rule in the production file.
4. Run only that test and confirm THAT assertion fails, with the diagnostic naming the rule:

```
./.un/skills/devsecops/scripts/validate_tests.py <PROJECT_DIR>/<subject_test_file> -k <test_name>
```
5. Restore from the copy, confirm the restore is exact, and remove the copy:

```
cp <PROJECT_DIR>/<production_file>.bak <PROJECT_DIR>/<production_file>
diff <PROJECT_DIR>/<production_file>.bak <PROJECT_DIR>/<production_file>
mv <PROJECT_DIR>/<production_file>.bak <PROJECT_DIR>/<delete_me>/
```

*`<production_file>` and `<subject_test_file>` vary on every pass of this loop — one production script per moved test — so they are placeholders, not a worked example to copy. **If two moved tests drive the same production file:** the `.bak` name collides, so mutate them one at a time, or give each copy a distinct suffix.*
6. Re-run the same test and confirm it is green again. *`diff` proves the bytes came back; only the test passing proves the file is working code again.*

*Take the copy rather than reaching for git: undo may not be available, and an uncommitted change already in the file would read as the mutation surviving.*

Record each mutation and the assertion it felled in HARVEST_FILE under the test's name.

**If a mutation fells nothing, there are TWO causes and they need different fixes.** Separate them before touching anything, with this question: *name the wrong implementation the mutation just created, and ask what this test would READ under it.*
    - **A different value — the test lost its grip in the MOVE.** It could have failed where it came from and cannot here. Most often a fixture it depended on was left behind, or it now runs against a different path. Fix the move and re-run the mutation.
    - **The same value — the test never had grip, and the move is not what is wrong with it.** Its observable cannot differ across the thing it claims to bound, so it would have survived this mutation in `<working>` too. This is a test that has never been a gate and is about to be filed in `active` as though it were.

**A degenerate input is the usual cause of the second**, because it collapses the observable: an empty string slices to the same result at every index, a zero-length collection sorts the same in every order, a canonical writer reproduces its own output byte for byte. The test reads one of those and gets the same answer either way.

**Fix it by changing what the test READS, not by changing the mutation.** Either assert on a value that still varies across the bound — a different field, a cursor, a count, a fixture the producer would not reproduce — or, where a sibling test already covers that bound on an observable that does discriminate, reclassify this one `REDUNDANT` and take it back out of the subject file. Record which you did and why in HARVEST_FILE. *A mutation aimed at a real rule is evidence about the test; re-aiming it until something goes red only hides what it found.*

**If a mutation fells a DIFFERENT assertion than the one named:** record which, and treat the named one as unverified until a mutation reaches it.

**Escalation.** After three mutations that fell nothing for the same test, stop and ask the user. Say which of the two causes above you have ruled out, since the answer decides the question: a test that lost its grip is reporting something about the MOVE, and a test that never had grip is reporting something about ITSELF.

**Gate.**
    1. Every test still in a subject file has one recorded mutation that felled the assertion it was moved for, and is green again afterwards.
    2. Every test this step reclassified `REDUNDANT` is back out of the subject file, with its reason recorded.
    3. No `.bak` copy survives anywhere under the production tree.
    4. The Step 1 snapshot is still on disk for Step 8 to restore.
</step_6>

<step_7>
### Dispose the spent working files

Move every file in scope out of `<working>` and into `<delete_me>/`, whatever its tests were classified as — harvested whole, harvested in part, or neither.

**This is the opposite disposal from the one Step 5.b applies, and deliberately so.** A test retired there was part of the durable suite and gated something real, so it moves to `<archive>/` and stays readable. Nothing in `working` was ever durable: what was worth keeping has been copied into `active`, and what was not was judged `REDUNDANT` or `SPENT` and is covered elsewhere or covers nothing. *Leaving either kind in `working` means every run executes it while no map entry claims it.*

```
mkdir -p <PROJECT_DIR>/<delete_me>
mv <PROJECT_DIR>/<working>/<filename> <PROJECT_DIR>/<delete_me>/
```

**If a filename already exists in `<delete_me>/`:** move it to `<delete_me>/<subject>-<filename>` so neither is lost.

Record every moved file in HARVEST_FILE, and tell the user at the close that `<delete_me>/` is holding them. *Nothing here removes a file — the workflow moves it and the user decides. Where the project tracks `<delete_me>/` in git, the moves also stay visible in `git status` until then.*

**Gate.**
    1. Every file in scope is under `<delete_me>/`.
    2. `<working>` holds none of them.
</step_7>

<step_8>
### Run the suite and bank

**First, restore the snapshot Step 1 took.** The comparison has to be against the record as it stood before the harvest, not as Steps 2-7 left it:

```
mv <PROJECT_DIR>/<record>.preharvest <PROJECT_DIR>/<record>
```

Then run exactly this:

```
./.un/skills/devsecops/scripts/validate_tests.py --compare
```

`--compare` prints only what moved against the record the invocation started from — which, after the restore, is the pre-harvest one. That is the comparison this pass needs: a harvest adds tests to `active` and removes others, so the counts change by design while every pre-existing result must not.

**If the snapshot is missing, or a run banked before it was taken:** say so and state the delta by counting instead — tests added minus tests retired against the pre-harvest total —. Reporting `--compare`'s output here describes a different comparison under the gate's name.

Read its output against the harvest:
    - **New tests appearing** — expected, one per harvested test.
    - **Tests gone** — expected, one per retired test, and no others.
    - **New red** — a harvested test that does not hold in its new home, or a regression this pass caused. Fix before banking.
    - **No longer red** — account for it. *A red that went green because a test was weakened during the move is the failure mode this gate exists for.*

Record the final counts and the delta in HARVEST_FILE.

**Gate.**
    1. The suite is green, or every red is explained and accepted by the user.
    2. `--compare` shows appearances and departures matching the harvest and nothing else.
    3. The closing run named no tier, so it covered every group.
</step_8>

</process>

<success_criteria>
This workflow is complete when:

- [ ] The bootstrap gate was cleared before anything moved, and HARVEST_FILE records every resolved path, every file in scope, every test function, its verdict, and its reason.
- [ ] The user approved the plan before any file moved or the map changed.
- [ ] Every `DURABLE` and `REPLACES` test lives in the subject file named for the production script it drives, or in the lowest-`duration_s` part where that subject is split, and no new part was created.
- [ ] Every replaced `active` test is under `<archive>/`, and its `test_groups` entry is dropped where the whole file moved.
- [ ] `test_groups` has an entry for every subject file created, and `--audit-map` exits 0.
- [ ] Every test left in a subject file has a recorded mutation that felled the assertion it was moved for, and every mutated production file is `diff`-clean against its backup.
- [ ] Every test whose mutation felled nothing was diagnosed as lost-grip or as never-had-grip, and was fixed or reclassified `REDUNDANT` and removed accordingly, with the reason in HARVEST_FILE.
- [ ] Every file in scope is under `<delete_me>/` and `<working>` holds none of them, and the user was told what is waiting there.
- [ ] The pre-harvest snapshot was taken at Step 1, before any harvesting work ran, and restored before Step 8's run.
- [ ] `--compare` shows appearances and departures matching the harvest and nothing else, and the record is banked.
</success_criteria>
